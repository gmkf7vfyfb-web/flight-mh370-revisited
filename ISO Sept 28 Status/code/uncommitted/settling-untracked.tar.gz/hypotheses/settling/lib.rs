//! Settling: where each class of wreckage comes to rest on the seabed, given the point and
//! manner of first water contact.
//!
//! A transform, not evidence: it adds no likelihood and leaves the estimate unchanged. For each
//! impact sample it predicts, per element class, the mean and covariance of the resting offset
//! from the contact point and the depth at rest (`predict_contact`).
//!
//! Model (after the methodology Pete shared, sec. 7):
//!   r_rest = r_contact + carry + drift afloat + drift sinking + glide (+ seabed movement)
//! - carry: travel along the impact track after contact (breakup, skipping, sliding).
//! - drift afloat: surface current plus leeway times the 10 m wind, for the time an element
//!   floats before it sinks.
//! - drift sinking: a flooded element reaches its terminal speed w within metres, so it moves
//!   I / w, where I is the current integrated from the surface to the seabed (dt = dz / w).
//! - glide: motion through the water from gliding, fluttering or tumbling, as a speed G w whose
//!   heading loses its memory over a descent l; a straight glide when l exceeds the depth.
//! - seabed movement (sliding down slopes) is not modelled; the slope at the contact is
//!   reported instead.
//! The terms are independent, so their means and covariances add (physics.rs). Element classes
//! and breakup families, and the rule that picks a family from the impact, are in
//! breakup.toml.

mod breakup;
mod environment;
mod physics;

use breakup::{Breakup, FAMILIES};
use environment::{Bathymetry, Stack};
use hypothesis::{Hypothesis, ImpactView};
use physics::{Moments, Rng, Terms, Water};
use serde::Deserialize;
use std::path::{Path, PathBuf};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Params {
    /// ETOPO bathymetry (.i16 with a .toml sidecar), relative to the repository root.
    bathymetry: PathBuf,
    /// Currents by depth layer, and the 10 m wind (prepare/ocean.py), relative to the root.
    currents: PathBuf,
    wind: PathBuf,
    current_error: CurrentError,
    /// Terms of the offset: carry, float, current, glide. All of them for the estimate; the
    /// report turns them on one at a time.
    #[serde(default = "all_terms")]
    terms: Vec<String>,
}

fn all_terms() -> Vec<String> {
    ["carry", "float", "current", "glide"].map(String::from).to_vec()
}

/// Model error of the reanalysis currents, per east/north component.
#[derive(Debug, Clone, Copy, PartialEq, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CurrentError {
    /// Surface current (m/s).
    pub surface_mps: f64,
    /// Mean current over the upper layer (m/s)...
    pub upper_mps: f64,
    pub upper_depth_m: f64,
    /// ...and over the rest of the column (m/s), tides included.
    pub deep_mps: f64,
}

impl CurrentError {
    /// Error (m2/s) of the current integrated to `depth_m`: the two layers independent.
    pub fn integral_sd(&self, depth_m: f64) -> f64 {
        let upper = self.upper_mps * depth_m.min(self.upper_depth_m);
        let deep = self.deep_mps * (depth_m - self.upper_depth_m).max(0.0);
        upper.hypot(deep)
    }
}

/// First contact with the water.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Contact {
    /// The impact sample's parent trajectory (`usize::MAX` if not given); with the other fields
    /// it seeds the draws.
    pub parent: usize,
    pub unix_s: f64,
    pub latitude_deg: f64,
    pub longitude_deg: f64,
    /// East, north, up (m/s).
    pub velocity: [f64; 3],
}

pub struct Settling {
    breakup: Breakup,
    bathymetry: Bathymetry,
    currents: Stack,
    wind: Stack,
    error: CurrentError,
    terms: Terms,
}

/// Per class, in this order: the mean offset of a settled element from the contact point, its
/// spread, one offset drawn from the same distribution (seeded by the impact sample), the depth
/// at the mean resting point, and the share of the class's elements that settle.
const CLASS_COLUMNS: [&str; 9] = [
    "east (m)",
    "north (m)",
    "sd east (m)",
    "sd north (m)",
    "east-north correlation",
    "draw east (m)",
    "draw north (m)",
    "depth (m)",
    "settles (probability)",
];

pub fn new(params: &toml::Value) -> Result<Box<dyn Hypothesis>, String> {
    Ok(Box::new(Settling::from_params(params)?))
}

impl Settling {
    pub fn from_params(params: &toml::Value) -> Result<Settling, String> {
        let params: Params = params.clone().try_into().map_err(|e| format!("settling: {e}"))?;
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("..");
        let hint = "; build it with hypotheses/settling/prepare/ocean.py";
        let bathymetry = Bathymetry::load(&root.join(&params.bathymetry)).map_err(|e| format!("settling: {e}"))?;
        let currents = Stack::load(&root.join(&params.currents)).map_err(|e| format!("settling: {e}{hint}"))?;
        let wind = Stack::load(&root.join(&params.wind)).map_err(|e| format!("settling: {e}{hint}"))?;
        let breakup = Breakup::parse(include_str!("breakup.toml"))?;
        Settling::with(breakup, bathymetry, currents, wind, params.current_error, &params.terms)
    }

    fn with(breakup: Breakup, bathymetry: Bathymetry, currents: Stack, wind: Stack, error: CurrentError, terms: &[String]) -> Result<Settling, String> {
        let e = error;
        if ![e.surface_mps, e.upper_mps, e.upper_depth_m, e.deep_mps].iter().all(|x| *x >= 0.0) {
            return Err("settling: current_error values must be non-negative".into());
        }
        if let Some(t) = terms.iter().find(|t| !all_terms().contains(t)) {
            return Err(format!("settling: unknown term `{t}`; known: {:?}", all_terms()));
        }
        let has = |name: &str| terms.iter().any(|t| t == name);
        let terms = Terms { carry: has("carry"), float: has("float"), current: has("current"), glide: has("glide") };
        Ok(Settling { breakup, bathymetry, currents, wind, error, terms })
    }

    /// Names (with units) of the values `predict_contact` writes, in order.
    pub fn columns(&self) -> Vec<String> {
        let mut columns: Vec<String> = FAMILIES.iter().map(|f| format!("{f} probability")).collect();
        columns.extend(["contact depth (m)".to_string(), "contact slope (deg)".to_string()]);
        for class in &self.breakup.classes {
            columns.extend(CLASS_COLUMNS.iter().map(|c| format!("{class} {c}")));
        }
        columns
    }

    /// The water at a contact point, or None where a field has no data (land, outside a grid
    /// or its time span).
    fn water(&self, contact: &Contact) -> Option<Water> {
        let (t, lat, lon) = (contact.unix_s, contact.latitude_deg, contact.longitude_deg);
        let depth = self.bathymetry.depth(lat, lon)?;
        Some(Water {
            depth_m: depth,
            current_integral: self.currents.integral(t, lat, lon, depth)?,
            current_integral_sd: self.error.integral_sd(depth),
            surface_current: self.currents.surface(t, lat, lon)?,
            surface_current_sd: self.error.surface_mps,
            wind: self.wind.surface(t, lat, lon)?,
        })
    }

    /// Fill `out` (one value per column); NaN where not computed.
    pub fn predict_contact(&self, contact: &Contact, out: &mut [f64]) {
        out.fill(f64::NAN);
        let [east, north, up] = contact.velocity;
        let speed = (east * east + north * north + up * up).sqrt();
        let Some(families) = self.breakup.selection.probabilities(-up, speed) else { return };
        out[..3].copy_from_slice(&families);
        let Some(water) = self.water(contact) else { return };
        out[3] = water.depth_m;
        out[4] = self.bathymetry.slope_deg(contact.latitude_deg, contact.longitude_deg).unwrap_or(f64::NAN);
        let words = [contact.parent as u64, contact.unix_s.to_bits(), contact.latitude_deg.to_bits(), contact.longitude_deg.to_bits()];
        let mut rng = Rng::seeded(&[&words[..], &contact.velocity.map(f64::to_bits)[..]].concat());
        for (c, row) in out[5..].chunks_exact_mut(CLASS_COLUMNS.len()).enumerate() {
            // Settled elements of the class come from family f in proportion to P(f) x settles.
            let weights: Vec<f64> = (0..FAMILIES.len()).map(|f| families[f] * self.breakup.elements[f][c].settles()).collect();
            let settles: f64 = weights.iter().sum();
            row[8] = settles;
            if !(settles > 0.0) {
                continue;
            }
            let parts: Vec<(f64, Moments)> = (0..FAMILIES.len())
                .map(|f| {
                    let element = &self.breakup.elements[f][c];
                    (weights[f] / settles, element.offset(self.breakup.slowness[f][c], &water, [east, north], &self.terms))
                })
                .collect();
            let m = Moments::mixture(&parts);
            let (sd_east, sd_north, correlation) = m.spread();
            let pick = rng.uniform() * settles;
            let f = (0..FAMILIES.len()).scan(0.0, |sum, f| { *sum += weights[f]; Some((f, *sum)) }).find(|(_, sum)| pick < *sum).map_or(FAMILIES.len() - 1, |(f, _)| f);
            let draw = self.breakup.elements[f][c].draw(&water, [east, north], &self.terms, &mut rng);
            let (lat, lon) = offset_position(contact.latitude_deg, contact.longitude_deg, m.mean);
            let depth = self.bathymetry.depth(lat, lon).unwrap_or(f64::NAN);
            row[..8].copy_from_slice(&[m.mean[0], m.mean[1], sd_east, sd_north, correlation, draw[0], draw[1], depth]);
        }
    }
}

/// The position `offset` metres east and north of (lat, lon).
fn offset_position(lat: f64, lon: f64, offset: [f64; 2]) -> (f64, f64) {
    let (m, n) = geo::radii_of_curvature_km(lat);
    let north = (offset[1] / (m * 1000.0)).to_degrees();
    let east = (offset[0] / (n * 1000.0 * lat.to_radians().cos())).to_degrees();
    (lat + north, lon + east)
}

impl Hypothesis for Settling {
    fn prediction_columns(&self) -> Vec<String> {
        self.columns()
    }

    fn predict(&self, impact: &ImpactView, out: &mut [f64]) {
        let velocity = [impact.velocity_east_mps, impact.velocity_north_mps, impact.velocity_up_mps];
        let contact = Contact {
            parent: impact.parent,
            unix_s: impact.unix_s,
            latitude_deg: impact.latitude_deg,
            longitude_deg: impact.longitude_deg,
            velocity,
        };
        self.predict_contact(&contact, out);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use physics::{terminal_speed, Element, Range};

    /// A flat seabed at `depth_m` over 30-50 S, 80-100 E; a current that is `current` m/s at
    /// every depth in a column of three layers; a uniform wind.
    fn ocean(depth_m: f64, current: [f64; 2], wind: [f64; 2]) -> (Bathymetry, Stack, Stack) {
        let bathymetry = Bathymetry::new(-50.0, 80.0, 1.0, 1.0, 21, 21, vec![-depth_m as i16; 21 * 21]);
        let field = |v: [f64; 2], layers: usize| {
            let values = (0..2).flat_map(|c| std::iter::repeat((v[c] / 1e-4).round() as i16).take(2 * layers * 21 * 21)).collect();
            let edges = if layers == 1 { vec![0.0, 0.0] } else { vec![0.0, 100.0, 1000.0, 6000.0] };
            Stack::new(vec![0.0, 86_400.0], edges, -50.0, 80.0, 1.0, 21, 21, 1e-4, values).unwrap()
        };
        (bathymetry, field(current, 3), field(wind, 1))
    }

    fn settling(depth_m: f64, current: [f64; 2], wind: [f64; 2], error: CurrentError, terms: &[&str], table: &str) -> Settling {
        let (bathymetry, currents, wind) = ocean(depth_m, current, wind);
        let terms: Vec<String> = terms.iter().map(|t| t.to_string()).collect();
        Settling::with(Breakup::parse(table).unwrap(), bathymetry, currents, wind, error, &terms).unwrap()
    }

    const NO_ERROR: CurrentError = CurrentError { surface_mps: 0.0, upper_mps: 0.0, upper_depth_m: 1000.0, deep_mps: 0.0 };
    const TABLE: &str = include_str!("breakup.toml");

    fn predict(s: &Settling, contact: &Contact) -> Vec<f64> {
        let mut out = vec![0.0; s.columns().len()];
        s.predict_contact(contact, &mut out);
        out
    }

    /// The values of class `c` in a prediction row.
    fn class_row(out: &[f64], c: usize) -> &[f64] {
        &out[5 + CLASS_COLUMNS.len() * c..5 + CLASS_COLUMNS.len() * (c + 1)]
    }

    const CONTACT: Contact = Contact { parent: 0, unix_s: 43_200.0, latitude_deg: -38.0, longitude_deg: 88.0, velocity: [150.0, -80.0, -120.0] };

    #[test]
    fn no_current_and_no_glide_lands_directly_below_the_contact() {
        // Every class and family: no carry, float, current or glide leaves nothing to move it.
        let s = settling(4000.0, [0.0; 2], [0.0; 2], NO_ERROR, &["current"], TABLE);
        let out = predict(&s, &CONTACT);
        for (c, class) in s.breakup.classes.iter().enumerate() {
            let row = class_row(&out, c);
            assert_eq!(&row[..4], &[0.0; 4], "{class}: mean and spread");
            assert_eq!(&row[5..7], &[0.0; 2], "{class}: the draw");
            assert!((row[7] - 4000.0).abs() < 1e-9, "{class}: rests at the contact depth");
        }
        // With the glide on, the mean stays below the contact but the spread opens.
        let s = settling(4000.0, [0.0; 2], [0.0; 2], NO_ERROR, &["current", "glide"], TABLE);
        let engine = class_row(&predict(&s, &CONTACT), 0).to_vec();
        assert!(engine[..2].iter().all(|x| *x == 0.0) && engine[2] > 0.0);
    }

    #[test]
    fn uniform_current_and_constant_speed_give_u_h_over_w() {
        // One element with a fixed terminal speed: s = 600 kg/m2, rho = 5000, Cd = 1 gives
        // w = 3.021152 m/s (physics tests). In a uniform 0.1 m/s east, 0.05 m/s north current
        // over 4,000 m it moves U H / w = (132.40, 66.20) m, with no spread.
        let table = TABLE.replace(
            "areal_density_kg_m2 = { log_uniform = [400.0, 1300.0] }\nmaterial_density_kg_m3 = { uniform = [3500.0, 6000.0] }\ndrag_coefficient = { uniform = [0.8, 1.2] }",
            "areal_density_kg_m2 = 600.0\nmaterial_density_kg_m3 = 5000.0\ndrag_coefficient = 1.0",
        );
        let s = settling(4000.0, [0.1, 0.05], [0.0; 2], NO_ERROR, &["current"], &table);
        let w = terminal_speed(600.0, 5000.0, 1.0);
        let out = predict(&s, &CONTACT);
        let engine = class_row(&out, 0);
        assert!((engine[0] - 0.1 * 4000.0 / w).abs() < 1e-6 && (engine[1] - 0.05 * 4000.0 / w).abs() < 1e-6);
        assert!((engine[0] - 132.40).abs() < 0.01);
        assert!(engine[2] < 1e-6 && engine[3] < 1e-6);
        // Nothing is random here, so the draw is the same point.
        assert!((engine[5] - engine[0]).abs() < 1e-6 && (engine[6] - engine[1]).abs() < 1e-6);
    }

    #[test]
    fn family_selection_follows_the_anchor_impacts() {
        let s = Breakup::parse(TABLE).unwrap().selection;
        // US Airways 1549 (Hudson, 2009): about 3.8 m/s down at 65 m/s: a ditching.
        assert!(s.probabilities(3.8, 65.0).unwrap()[0] > 0.8);
        // AF447 (2009): about 55 m/s down at about 80 m/s: broken, not intact or fragmented.
        assert!(s.probabilities(55.0, 80.0).unwrap()[1] > 0.8);
        // A steep dive at 250 m/s.
        assert!(s.probabilities(150.0, 250.0).unwrap()[2] > 0.95);
        let p = s.probabilities(20.0, 120.0).unwrap();
        assert!((p.iter().sum::<f64>() - 1.0).abs() < 1e-12 && p.iter().all(|x| *x > 0.0));
    }

    /// xorshift64: uniform draws on (0, 1) and standard normals.
    struct Xorshift(u64);

    impl Xorshift {
        fn uniform(&mut self) -> f64 {
            self.0 ^= self.0 << 13;
            self.0 ^= self.0 >> 7;
            self.0 ^= self.0 << 17;
            ((self.0 >> 11) as f64 + 0.5) / (1u64 << 53) as f64
        }

        fn normal(&mut self) -> f64 {
            (-2.0 * self.uniform().ln()).sqrt() * (std::f64::consts::TAU * self.uniform()).cos()
        }
    }

    /// A surface-intensified current over a slower deep flow, U(z) = A exp(-z / 400 m) + B.
    const SHEAR: [[f64; 2]; 2] = [[0.25, -0.10], [0.02, 0.03]];

    fn sheared(z: f64) -> [f64; 2] {
        let e = (-z / 400.0).exp();
        [SHEAR[0][0] * e + SHEAR[1][0], SHEAR[0][1] * e + SHEAR[1][1]]
    }

    /// That current as 60 m layers holding each layer's mean, over a flat seabed at 3,600 m,
    /// with a uniform 10 m wind.
    fn sheared_ocean(wind: [f64; 2]) -> (Bathymetry, Stack, Stack) {
        let (bathymetry, _, wind) = ocean(3600.0, [0.0; 2], wind);
        let edges: Vec<f64> = (0..=60).map(|k| 60.0 * k as f64).collect();
        let mean = |c: usize, k: usize| {
            let (a, b) = (edges[k], edges[k + 1]);
            SHEAR[0][c] * 400.0 * ((-a / 400.0).exp() - (-b / 400.0).exp()) / (b - a) + SHEAR[1][c]
        };
        let mut values = Vec::new();
        for c in 0..2 {
            for _time in 0..2 {
                for k in 0..60 {
                    values.extend(std::iter::repeat((mean(c, k) / 1e-5).round() as i16).take(21 * 21));
                }
            }
        }
        let currents = Stack::new(vec![0.0, 86_400.0], edges, -50.0, 80.0, 1.0, 21, 21, 1e-5, values).unwrap();
        (bathymetry, currents, wind)
    }

    /// One element of class `c`, stepped down independently of the closed forms: the family and
    /// every parameter drawn from the table, the drift afloat, then the descent through the
    /// sheared current in 10 m steps, and the glide with its heading diffusing in steps of a third
    /// of its memory (which overstates the glide's mean square by about 1%). None for an element
    /// that stays afloat.
    fn descend(s: &Settling, c: usize, contact: &Contact, water: &Water, error: &CurrentError, rng: &mut Xorshift) -> Option<[f64; 2]> {
        let [ve, vn, vu] = contact.velocity;
        let p = s.breakup.selection.probabilities(-vu, (ve * ve + vn * vn + vu * vu).sqrt()).unwrap();
        let u = rng.uniform();
        let e: &Element = &s.breakup.elements[if u < p[0] { 0 } else if u < p[0] + p[1] { 1 } else { 2 }][c];
        let fate = rng.uniform();
        if fate < e.stays_afloat {
            return None;
        }
        let draw = |r: &Range, rng: &mut Xorshift| r.quantile(rng.uniform());
        // Carry after contact.
        let vh = ve.hypot(vn);
        let along = [ve / vh, vn / vh];
        let d = vh * draw(&e.carry_s, rng);
        let lateral = e.carry_lateral * d * (2.0 * rng.uniform() - 1.0);
        let mut at = [d * along[0] - lateral * along[1], d * along[1] + lateral * along[0]];
        // Afloat.
        if fate >= e.stays_afloat + e.sinks_at_once {
            let (t, a) = (draw(&e.float_s, rng), draw(&e.leeway, rng));
            for k in 0..2 {
                at[k] += t * (water.surface_current[k] + a * water.wind[k] + error.surface_mps * rng.normal());
            }
        }
        // Sinking through the current, with its error constant within each layer.
        let w = draw(&e.descent_factor, rng)
            * terminal_speed(draw(&e.areal_density_kg_m2, rng), draw(&e.material_density_kg_m3, rng), draw(&e.drag_coefficient, rng));
        let upper = [error.upper_mps * rng.normal(), error.upper_mps * rng.normal()];
        let deep = [error.deep_mps * rng.normal(), error.deep_mps * rng.normal()];
        let mut z = 0.0;
        while z < water.depth_m {
            let (flow, bias) = (sheared(z + 5.0), if z < error.upper_depth_m { upper } else { deep });
            for k in 0..2 {
                at[k] += (flow[k] + bias[k]) * 10.0 / w;
            }
            z += 10.0;
        }
        // Glide.
        let (g, memory) = (draw(&e.glide_ratio, rng), draw(&e.glide_memory_m, rng));
        let steps = (water.depth_m / (memory / 3.0).min(10.0)).ceil();
        let dz = water.depth_m / steps;
        let mut heading = std::f64::consts::TAU * rng.uniform();
        for _ in 0..steps as usize {
            at = [at[0] + g * heading.cos() * dz, at[1] + g * heading.sin() * dz];
            heading += (2.0 * dz / memory).sqrt() * rng.normal();
        }
        Some(at)
    }

    /// A sample of offsets against a class's predicted mean and covariance, within the sample's
    /// Monte Carlo errors (standard errors of the second moments from its fourth moments: the
    /// float times make some classes heavy-tailed).
    fn check_moments(what: &str, points: &[[f64; 2]], row: &[f64]) {
        let (mean, sd, rho) = ([row[0], row[1]], [row[2], row[3]], row[4]);
        let m = points.len() as f64;
        let average = |f: &dyn Fn(&[f64; 2]) -> f64| points.iter().map(f).sum::<f64>() / m;
        let centre = [average(&|p| p[0]), average(&|p| p[1])];
        for k in 0..2 {
            let tolerance = 4.0 * sd[k] / m.sqrt();
            assert!((centre[k] - mean[k]).abs() < tolerance, "{what}: mean[{k}] {} vs {} (+-{tolerance})", centre[k], mean[k]);
        }
        for (i, j, predicted) in [(0, 0, sd[0] * sd[0]), (1, 1, sd[1] * sd[1]), (0, 1, rho * sd[0] * sd[1])] {
            let product = |p: &[f64; 2]| (p[i] - centre[i]) * (p[j] - centre[j]);
            let sample = average(&product);
            let se = ((average(&|p| product(p).powi(2)) - sample * sample) / m).sqrt();
            let tolerance = 4.0 * se + 0.01 * sd[0] * sd[1];
            assert!((sample - predicted).abs() < tolerance, "{what}: cov[{i}{j}] {sample} vs {predicted} (+-{tolerance})");
        }
    }

    /// Synthetic recovery: resting points from `descend`, which steps each element down through
    /// a sheared current rather than using the closed forms, must match the predicted share that
    /// settles, mean and covariance of every class. So must the module's own draws, one per
    /// impact sample.
    #[test]
    fn simulated_descents_match_the_predicted_moments() {
        let error = CurrentError { surface_mps: 0.05, upper_mps: 0.04, upper_depth_m: 1000.0, deep_mps: 0.02 };
        let (bathymetry, currents, wind) = sheared_ocean([6.0, 5.0]);
        let s = Settling::with(Breakup::parse(TABLE).unwrap(), bathymetry, currents, wind, error, &all_terms()).unwrap();
        // 9 m/s down at 100 m/s: a mixture of all three families (19%, 68%, 13%).
        let contact = Contact { parent: 0, unix_s: 43_200.0, latitude_deg: -38.0, longitude_deg: 88.0, velocity: [70.42, -70.42, -9.0] };
        let water = s.water(&contact).unwrap();
        let exact = SHEAR[0][0] * 400.0 * (1.0 - (-9.0f64).exp()) + SHEAR[1][0] * 3600.0;
        assert!((water.current_integral[0] - exact).abs() < 0.02, "layered integral {:?}", water.current_integral);
        let out = predict(&s, &contact);
        let n = 4000;
        let draws: Vec<Vec<f64>> = (0..n).map(|k| predict(&s, &Contact { parent: k, ..contact })).collect();
        let mut rng = Xorshift(0x9E37_79B9_7F4A_7C15);
        for (c, class) in s.breakup.classes.iter().enumerate() {
            let row = class_row(&out, c);
            let stepped: Vec<[f64; 2]> = (0..n).filter_map(|_| descend(&s, c, &contact, &water, &error, &mut rng)).collect();
            let settled = stepped.len() as f64 / n as f64;
            assert!((settled - row[8]).abs() < 4.0 * (row[8] * (1.0 - row[8]) / n as f64).sqrt() + 1e-9, "{class}: settles {settled} vs {}", row[8]);
            check_moments(&format!("{class} stepped"), &stepped, row);
            let drawn: Vec<[f64; 2]> = draws.iter().map(|d| [class_row(d, c)[5], class_row(d, c)[6]]).collect();
            check_moments(&format!("{class} drawn"), &drawn, row);
        }
    }

    #[test]
    fn run_toml_parameters_parse() {
        let run: toml::Table = toml::from_str(include_str!("run.toml")).unwrap();
        let params: Params = run["hypotheses"]["settling"].clone().try_into().unwrap();
        assert_eq!(params.terms, all_terms());
        assert!(params.current_error.integral_sd(4000.0) > 0.0);
    }
}
