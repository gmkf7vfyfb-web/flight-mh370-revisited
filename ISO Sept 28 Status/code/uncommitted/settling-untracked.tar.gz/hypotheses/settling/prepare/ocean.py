#!/usr/bin/env python3
"""The ocean fields hypotheses/settling reads, in its stack layout (environment.rs, Stack):
little-endian int16, [component u, v][time][layer][row][column], value = scale x packed,
-32768 = no data, with a TOML sidecar of the same stem.

- Currents: CSIRO Bluelink ReANalysis BRAN2016 (OFAM3, 0.1 deg B-grid velocity points, 51 z*
  layers to 5,000 m, daily means stamped 12:00 UTC), public NCI THREDDS OPeNDAP, no login:
  https://thredds.nci.org.au/thredds/dodsC/gb6/BRAN/BRAN_2016/OFAM/ocean_{u,v}_2014_03.nc.
  Cut server-side to the box; the source's own int16 packing is kept, so values are exact.
  Acknowledgement requested by CSIRO: "BRAN is made freely available by CSIRO Bluelink and is
  supported by the Bluelink Partnership: a collaboration between the Australian Department of
  Defence, Bureau of Meteorology and CSIRO."
- Wind: ECMWF ERA5 10 m wind, hourly analyses, read (not copied whole) from the drift thread's
  MHGRID file in /jackbox/home/MH370-inputs/ocean/era5-wind10/ and repacked.

    ocean.py [--out /jackbox/home/MH370-inputs/ocean/settling]
"""

import argparse
import hashlib
import json
import struct
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

BRAN = "https://thredds.nci.org.au/thredds/dodsC/gb6/BRAN/BRAN_2016/OFAM/ocean_{}_2014_03.nc"
BRAN_SCALE = 3.051851e-4
ERA5 = Path("/jackbox/home/MH370-inputs/ocean/era5-wind10/era5-wind10-hourly-20140307-20140531.mhgrid")
# 50-27 S, 80-105 E: the 7th arc and impacts up to ~400 NM beyond it (thr_4pbhvf3sxi, 28 Sep 2026).
SOUTH, NORTH, WEST, EAST, STEP = -50.0, -27.0, 80.0, 105.0, 0.1
DAYS = ["2014-03-07", "2014-03-08"]  # the daily means either side of the impact (~00:20 UTC 8 March)
WIND_HOURS = ("2014-03-07T18:00", "2014-03-08T12:00")
NO_DATA = -32768


def fetch(url, attempts=6):
    for attempt in range(attempts):
        try:
            with urllib.request.urlopen(url, timeout=600) as response:
                return response.read()
        except Exception:
            if attempt == attempts - 1:
                raise
            time.sleep(2**attempt)


def ascii_values(url):
    """The values of a one-variable DAP2 ASCII response: the line after its name."""
    lines = [l for l in fetch(url).decode().splitlines() if l.strip()]
    return np.array([float(v) for v in lines[-1].split(",")])


def dods_int(blob, count):
    """Values of a single-array DAP2 response (XDR: count twice, then big-endian int32)."""
    data = blob[blob.index(b"\nData:\n") + 7 :]
    n, m = struct.unpack(">II", data[:8])
    if n != m or n != count or len(data) != 8 + 4 * n:
        raise ValueError("unexpected DAP2 payload")
    return np.frombuffer(data, ">i4", n, 8)


def index_range(axis, lo, hi):
    rows = np.flatnonzero((axis >= lo - 1e-4) & (axis <= hi + 1e-4))
    if rows.size == 0 or np.abs(np.diff(axis[rows]) - STEP).max() > 1e-4:
        raise ValueError("axis is not the expected 0.1 degree grid")
    return rows[0], rows[-1]


def unix(stamp):
    return datetime.fromisoformat(stamp).replace(tzinfo=timezone.utc).timestamp()


def write_stack(path, values, sidecar):
    """values: int16 [component][time][layer][row][column]."""
    path.parent.mkdir(parents=True, exist_ok=True)
    np.ascontiguousarray(values, dtype="<i2").tofile(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    lines = [f"# Written by hypotheses/settling/prepare/ocean.py on {datetime.now(timezone.utc):%Y-%m-%dT%H:%M:%SZ}."]
    for key, value in {**sidecar, "sha256": digest}.items():
        lines.append(f"{key} = {json.dumps(value) if not isinstance(value, float) else repr(value)}")
    path.with_suffix(".toml").write_text("\n".join(lines) + "\n")
    print(f"{path}: {path.stat().st_size / 1e6:.1f} MB, sha256 {digest[:12]}")


def currents(out):
    probe = BRAN.format("u")
    lat, lon = ascii_values(f"{probe}.ascii?yu_ocean"), ascii_values(f"{probe}.ascii?xu_ocean")
    y0, y1 = index_range(lat, SOUTH, NORTH)
    x0, x1 = index_range(lon, WEST, EAST)
    edges = ascii_values(f"{probe}.ascii?st_edges_ocean")
    stamps = 86_400.0 * ascii_values(f"{probe}.ascii?Time") + unix("1979-01-01T00:00")
    days = [int(np.flatnonzero(np.isclose(stamps, unix(f"{d}T12:00")))[0]) for d in DAYS]
    layers, rows, cols = len(edges) - 1, y1 - y0 + 1, x1 - x0 + 1
    values = np.empty((2, len(days), layers, rows, cols), dtype="<i2")
    for c, var in enumerate("uv"):
        for t, k in enumerate(days):
            query = f"{var}.{var}%5B{k}:{k}%5D%5B0:{layers - 1}%5D%5B{y0}:{y1}%5D%5B{x0}:{x1}%5D"
            raw = dods_int(fetch(f"{BRAN.format(var)}.dods?{query}"), layers * rows * cols)
            values[c, t] = raw.reshape(layers, rows, cols).astype("<i2")  # -32768 is BRAN's missing value
            print(f"BRAN2016 {var} {DAYS[t]}: {np.mean(values[c, t] != NO_DATA):.1%} of cells have data")
    write_stack(
        out / "bran2016-currents-20140307-20140308.i16",
        values,
        {
            "name": "BRAN2016 (OFAM3) currents, every z* layer, daily means",
            "source": BRAN.format("{u,v}"),
            "acknowledgement": "BRAN is made freely available by CSIRO Bluelink and is supported by the Bluelink "
            "Partnership: a collaboration between the Australian Department of Defence, Bureau of Meteorology and CSIRO.",
            "layout": "little-endian int16, [component u, v][time][layer][row][column]; value = scale x packed; "
            "-32768 = no data (land or below the model seabed)",
            "times_unix_s": [float(stamps[k]) for k in days],
            "layer_edges_m": [float(e) for e in edges],
            "south_deg": float(round(lat[y0], 4)),
            "west_deg": float(round(lon[x0], 4)),
            "step_deg": STEP,
            "rows": int(rows),
            "columns": int(cols),
            "scale": BRAN_SCALE,
        },
    )


def wind(out):
    with open(ERA5, "rb") as f:
        head = f.read(32)
        if head[:8] != b"MHGRID1\0":
            raise ValueError(f"{ERA5}: not an MHGRID file")
        schema, _, nt, ny, nx, nc = struct.unpack("<6I", head[8:])
        if schema != 3 or nc != 2:
            raise ValueError(f"{ERA5}: expected schema 3 with u and v")
        times = np.frombuffer(f.read(8 * nt), "<f8")
        lat = np.frombuffer(f.read(8 * ny), "<f8")
        lon = np.frombuffer(f.read(8 * nx), "<f8")
        components = []
        for _ in range(nc):
            name, encoding, scale, offset, missing, land = struct.unpack("<16sIddhh", f.read(40))
            if encoding != 1 or offset != 0.0:
                raise ValueError(f"{ERA5}: unexpected packing")
            components.append((name.rstrip(b"\0").decode(), scale, missing, land, f.tell()))
            f.seek(2 * nt * ny * nx, 1)
    t = np.flatnonzero((times >= unix(WIND_HOURS[0])) & (times <= unix(WIND_HOURS[1])))
    rows = np.flatnonzero((lat >= SOUTH - 1e-6) & (lat <= NORTH + 1e-6))
    cols = np.flatnonzero((lon >= WEST - 1e-6) & (lon <= EAST + 1e-6))
    step = float(lat[1] - lat[0])
    if not (np.allclose(np.diff(lat), step) and np.allclose(np.diff(lon), step)):
        raise ValueError(f"{ERA5}: grid is not regular")
    values = np.empty((2, len(t), 1, len(rows), len(cols)), dtype="<i2")
    scales = []
    for c, (name, scale, missing, land, at) in enumerate(components):
        grid = np.memmap(ERA5, "<i2", "r", offset=at, shape=(nt, ny, nx))
        block = np.array(grid[t[0] : t[-1] + 1, rows[0] : rows[-1] + 1, cols[0] : cols[-1] + 1])
        block[(block == missing) | (block == land)] = NO_DATA
        values[c, :, 0] = block
        scales.append(scale)
    if scales[0] != scales[1]:
        raise ValueError("u and v packed with different scales")
    meta = json.loads(ERA5.with_suffix(".mhgrid.json").read_text())
    write_stack(
        out / "era5-wind10-20140307T18-20140308T12.i16",
        values,
        {
            "name": "ERA5 10 m wind (u10, v10), hourly analyses",
            "source": f"{ERA5} (sha256 {meta.get('sha256', 'unknown')}), from {meta['source']}",
            "acknowledgement": "Contains modified Copernicus Climate Change Service information (ERA5, Hersbach et al. 2020).",
            "layout": "little-endian int16, [component u, v][time][layer][row][column]; value = scale x packed; "
            "-32768 = no data; one surface layer",
            "times_unix_s": [float(x) for x in times[t]],
            "layer_edges_m": [0.0, 0.0],
            "south_deg": float(lat[rows[0]]),
            "west_deg": float(lon[cols[0]]),
            "step_deg": step,
            "rows": int(len(rows)),
            "columns": int(len(cols)),
            "scale": float(scales[0]),
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", type=Path, default=Path("/jackbox/home/MH370-inputs/ocean/settling"))
    args = parser.parse_args()
    currents(args.out)
    wind(args.out)


if __name__ == "__main__":
    main()
