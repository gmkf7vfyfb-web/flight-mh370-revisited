//! Element classes and breakup families (breakup.toml): which elements exist and in what state,
//! selected by the impact. The table is the module's only description of the breakup, kept in
//! one place so that it can become the shared breakup field without touching the physics.

use super::physics::{Element, Slowness};
use serde::Deserialize;

/// The families, in the order the selection rule produces them.
pub const FAMILIES: [&str; 3] = ["intact", "broken", "fragmented"];

pub struct Breakup {
    pub classes: Vec<String>,
    pub selection: Selection,
    /// [family][class], families in `FAMILIES` order.
    pub elements: Vec<Vec<Element>>,
    /// E[1/w] and E[1/w^2] of each element, which do not depend on the impact.
    pub slowness: Vec<Vec<Slowness>>,
}

/// P(family | impact) from the descent speed V_d and the speed V at first contact, with
/// L(x) = 1 / (1 + exp(-x)):
///   P(intact) = L(ln(a / V_d) / s) L(ln(c / V) / s)
///   P(fragmented) = (1 - P(intact)) L(ln(V / b) / s)
///   P(broken) = the rest.
/// Speeds rather than energies because mass is not yet modelled; the specific kinetic energies
/// V_d^2 / 2 and V^2 / 2 order the impacts the same way.
#[derive(Debug, Clone, Copy, PartialEq, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Selection {
    /// a: the descent speed (m/s) at which an otherwise gentle contact is even odds intact.
    pub intact_descent_mps: f64,
    /// c: the speed (m/s) at which a shallow contact is even odds intact.
    pub intact_speed_mps: f64,
    /// b: the speed (m/s) at which a contact that is not intact is even odds fragmented.
    pub fragmented_speed_mps: f64,
    /// s: the width of each transition in ln(speed).
    pub log_width: f64,
}

impl Selection {
    pub fn probabilities(&self, descent_mps: f64, speed_mps: f64) -> Option<[f64; 3]> {
        if !(descent_mps.is_finite() && speed_mps > 0.0 && speed_mps.is_finite()) {
            return None;
        }
        let logistic = |x: f64| 1.0 / (1.0 + (-x).exp());
        // A level or climbing contact counts as a descent of 1 cm/s.
        let descent = descent_mps.max(0.01);
        let intact = logistic((self.intact_descent_mps / descent).ln() / self.log_width)
            * logistic((self.intact_speed_mps / speed_mps).ln() / self.log_width);
        let fragmented = (1.0 - intact) * logistic((speed_mps / self.fragmented_speed_mps).ln() / self.log_width);
        Some([intact, 1.0 - intact - fragmented, fragmented])
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Table {
    classes: Vec<String>,
    selection: Selection,
    /// Per class: properties shared by every family.
    class: toml::Table,
    /// Per family and class: the properties that differ from the class's.
    family: toml::Table,
}

impl Breakup {
    pub fn parse(text: &str) -> Result<Breakup, String> {
        let table: Table = toml::from_str(text).map_err(|e| format!("breakup table: {e}"))?;
        let s = table.selection;
        if ![s.intact_descent_mps, s.intact_speed_mps, s.fragmented_speed_mps, s.log_width].iter().all(|x| *x > 0.0) {
            return Err("breakup table: selection speeds and width must be positive".into());
        }
        let unknown = |keys: Vec<&String>, known: &[&str], what: &str| match keys.iter().find(|k| !known.contains(&k.as_str())) {
            Some(k) => Err(format!("breakup table: unknown {what} `{k}`")),
            None => Ok(()),
        };
        let classes: Vec<&str> = table.classes.iter().map(String::as_str).collect();
        if classes.iter().enumerate().any(|(i, c)| c.is_empty() || c.contains([',', '/', ':', ' ']) || classes[..i].contains(c)) {
            return Err("breakup table: class names must be unique, non-empty, without spaces , / or :".into());
        }
        unknown(table.class.keys().collect(), &classes, "class")?;
        unknown(table.family.keys().collect(), &FAMILIES, "family")?;
        let mut elements = Vec::new();
        for family in FAMILIES {
            let overrides = match table.family.get(family) {
                Some(toml::Value::Table(t)) => t.clone(),
                None => toml::Table::new(),
                Some(_) => return Err(format!("breakup table: family.{family} must be a table")),
            };
            unknown(overrides.keys().collect(), &classes, &format!("class in family.{family}"))?;
            let mut row = Vec::new();
            for class in &table.classes {
                let mut merged = match table.class.get(class) {
                    Some(toml::Value::Table(t)) => t.clone(),
                    _ => return Err(format!("breakup table: class.{class} is missing")),
                };
                if let Some(toml::Value::Table(t)) = overrides.get(class) {
                    merged.extend(t.clone());
                }
                let element: Element = toml::Value::Table(merged)
                    .try_into()
                    .map_err(|e| format!("breakup table: {family} {class}: {e}"))?;
                element.check().map_err(|e| format!("breakup table: {family} {class}: {e}"))?;
                row.push(element);
            }
            elements.push(row);
        }
        let slowness = elements.iter().map(|row| row.iter().map(Element::slowness).collect()).collect();
        Ok(Breakup { classes: table.classes, selection: s, elements, slowness })
    }
}
