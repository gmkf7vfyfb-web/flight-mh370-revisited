//! Sinking physics: an element's terminal speed, and the mean and covariance of its resting
//! offset from the point of first contact.
//!
//! The offset is a sum of independent terms (carry after contact, drift while afloat, drift
//! with the current while sinking, glide), so means and covariances add. A mixture over breakup
//! families combines by the law of total covariance.

use serde::Deserialize;
use std::sync::OnceLock;

/// Standard gravity (m/s2).
pub const GRAVITY: f64 = 9.80665;
/// Sea water density (kg/m3) at the surface. In situ density rises about 2% by 4,000 m, which
/// changes a terminal speed by about 1%; the model neglects it.
pub const WATER_DENSITY: f64 = 1025.0;

/// A parameter: fixed, uniform, or log-uniform (for scale parameters) on [lo, hi].
#[derive(Debug, Clone, Copy, PartialEq, Deserialize)]
#[serde(try_from = "RangeSpec")]
pub struct Range {
    pub lo: f64,
    pub hi: f64,
    pub log: bool,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum RangeSpec {
    Fixed(f64),
    Uniform { uniform: [f64; 2] },
    LogUniform { log_uniform: [f64; 2] },
}

impl TryFrom<RangeSpec> for Range {
    type Error = String;
    fn try_from(spec: RangeSpec) -> Result<Self, String> {
        let range = match spec {
            RangeSpec::Fixed(x) => Range { lo: x, hi: x, log: false },
            RangeSpec::Uniform { uniform: [lo, hi] } => Range { lo, hi, log: false },
            RangeSpec::LogUniform { log_uniform: [lo, hi] } => Range { lo, hi, log: true },
        };
        if !(range.lo.is_finite() && range.hi.is_finite() && range.lo <= range.hi) || (range.log && range.lo <= 0.0) {
            return Err(format!("bad range [{}, {}]", range.lo, range.hi));
        }
        Ok(range)
    }
}

impl Range {
    /// E[f(X)], by 24-point Gauss-Legendre quadrature over the support (in log X if
    /// log-uniform): deterministic, and exact to ~1e-12 for the smooth powers used here.
    pub fn expect(&self, f: impl Fn(f64) -> f64) -> f64 {
        if self.lo == self.hi {
            return f(self.lo);
        }
        let (a, b) = if self.log { (self.lo.ln(), self.hi.ln()) } else { (self.lo, self.hi) };
        gauss_legendre()
            .iter()
            .map(|&(x, w)| {
                let u = a + (b - a) * x;
                w * f(if self.log { u.exp() } else { u })
            })
            .sum()
    }

    pub fn mean(&self) -> f64 {
        self.expect(|x| x)
    }

    /// E[X^2].
    pub fn square(&self) -> f64 {
        self.expect(|x| x * x)
    }

    /// The value at quantile `q` (for samplers).
    pub fn quantile(&self, q: f64) -> f64 {
        if self.log {
            (self.lo.ln() + q * (self.hi.ln() - self.lo.ln())).exp()
        } else {
            self.lo + q * (self.hi - self.lo)
        }
    }
}

/// Gauss-Legendre nodes and weights on [0, 1] (weights sum to one).
fn gauss_legendre() -> &'static [(f64, f64)] {
    static NODES: OnceLock<Vec<(f64, f64)>> = OnceLock::new();
    NODES.get_or_init(|| {
        let n = 24;
        (0..n)
            .map(|i| {
                let mut x = (std::f64::consts::PI * (i as f64 + 0.75) / (n as f64 + 0.5)).cos();
                let mut derivative = 1.0;
                for _ in 0..100 {
                    let (mut p0, mut p1) = (1.0, x);
                    for k in 2..=n {
                        let p2 = ((2 * k - 1) as f64 * x * p1 - (k - 1) as f64 * p0) / k as f64;
                        p0 = p1;
                        p1 = p2;
                    }
                    derivative = n as f64 * (x * p1 - p0) / (x * x - 1.0);
                    let step = p1 / derivative;
                    x -= step;
                    if step.abs() < 1e-15 {
                        break;
                    }
                }
                ((1.0 - x) / 2.0, 1.0 / ((1.0 - x * x) * derivative * derivative))
            })
            .collect()
    })
}

/// Steady terminal sinking speed (m/s) of a flooded body falling broadside:
/// w = sqrt(2 g s (1 - rho_w / rho_m) / (rho_w Cd)), where s is its mass per unit projected
/// area (kg/m2), rho_m its material density and Cd its drag coefficient. Submerged weight
/// m g (1 - rho_w / rho_m) balances drag rho_w Cd A w^2 / 2; only m / A matters, not size.
pub fn terminal_speed(areal_density_kg_m2: f64, material_density_kg_m3: f64, drag_coefficient: f64) -> f64 {
    let buoyancy = 1.0 - WATER_DENSITY / material_density_kg_m3;
    (2.0 * GRAVITY * areal_density_kg_m2 * buoyancy / (WATER_DENSITY * drag_coefficient)).sqrt()
}

/// One element class in one breakup family: the distributions of what sets where it rests.
/// All ranges are independent.
#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Element {
    /// Mass per unit projected area in its falling attitude (kg/m2).
    pub areal_density_kg_m2: Range,
    /// Density of the flooded element's material mix (kg/m3), above sea water's.
    pub material_density_kg_m3: Range,
    pub drag_coefficient: Range,
    /// Mean descent speed over the steady broadside terminal speed: above one for bodies that
    /// flutter or tumble and spend part of the fall edge-on.
    pub descent_factor: Range,
    /// Horizontal speed through the water over the descent speed while gliding or tumbling.
    pub glide_ratio: Range,
    /// Descent (m) over which the glide heading loses its memory. Much less than the depth:
    /// the glide is a random walk; much more: a straight glide in one direction.
    pub glide_memory_m: Range,
    /// Travel along the impact track after first contact (breakup, skipping, sliding), as the
    /// horizontal impact speed times this time (s).
    pub carry_s: Range,
    /// Scatter across the track, as a fraction of the along-track travel.
    pub carry_lateral: f64,
    /// Share of elements that sink at once...
    pub sinks_at_once: f64,
    /// ...and that never sink within hours (drift debris, not settled). The rest float for
    /// `float_s` seconds first.
    pub stays_afloat: f64,
    pub float_s: Range,
    /// Downwind drift while afloat, as a fraction of the 10 m wind (leeway), on top of the
    /// surface current.
    pub leeway: Range,
}

/// E[1/w] and E[1/w^2] (s/m, s2/m2) of an element's descent speed w.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Slowness {
    pub mean: f64,
    pub square: f64,
}

impl Element {
    pub fn check(&self) -> Result<(), String> {
        let unit = |x: f64| (0.0..=1.0).contains(&x);
        let positive = [
            ("areal_density_kg_m2", self.areal_density_kg_m2),
            ("drag_coefficient", self.drag_coefficient),
            ("descent_factor", self.descent_factor),
        ];
        if let Some((name, _)) = positive.iter().find(|(_, r)| r.lo <= 0.0) {
            return Err(format!("{name} must be positive"));
        }
        if self.material_density_kg_m3.lo <= WATER_DENSITY {
            return Err(format!("material_density_kg_m3 must exceed sea water's {WATER_DENSITY} kg/m3"));
        }
        let non_negative = [self.glide_ratio, self.carry_s, self.float_s, self.leeway];
        if non_negative.iter().any(|r| r.lo < 0.0) || self.glide_memory_m.lo <= 0.0 || !(self.carry_lateral >= 0.0) {
            return Err("glide, carry, float and leeway ranges must be non-negative, glide memory positive".into());
        }
        if !unit(self.sinks_at_once) || !unit(self.stays_afloat) || self.sinks_at_once + self.stays_afloat > 1.0 + 1e-12 {
            return Err("sinks_at_once and stays_afloat are shares that sum to at most one".into());
        }
        Ok(())
    }

    /// Share of elements that settle on the seabed.
    pub fn settles(&self) -> f64 {
        1.0 - self.stays_afloat
    }

    pub fn slowness(&self) -> Slowness {
        let c = WATER_DENSITY / (2.0 * GRAVITY);
        let buoyancy = |rho: f64| 1.0 - WATER_DENSITY / rho;
        Slowness {
            mean: c.sqrt()
                * self.descent_factor.expect(|k| 1.0 / k)
                * self.drag_coefficient.expect(f64::sqrt)
                * self.areal_density_kg_m2.expect(|s| 1.0 / s.sqrt())
                * self.material_density_kg_m3.expect(|r| 1.0 / buoyancy(r).sqrt()),
            square: c
                * self.descent_factor.expect(|k| 1.0 / (k * k))
                * self.drag_coefficient.mean()
                * self.areal_density_kg_m2.expect(|s| 1.0 / s)
                * self.material_density_kg_m3.expect(|r| 1.0 / buoyancy(r)),
        }
    }

    /// Mean and covariance of the resting offset (m, east and north) from first contact, given
    /// the water at the contact point and the horizontal impact velocity (m/s).
    pub fn offset(&self, slowness: Slowness, water: &Water, velocity: [f64; 2], terms: &Terms) -> Moments {
        let mut total = Moments::default();
        if terms.carry {
            total = total.add(self.carry(velocity));
        }
        if terms.float {
            total = total.add(self.float(water));
        }
        if terms.current {
            total = total.add(current(slowness, water));
        }
        if terms.glide {
            total = total.add(self.glide(water.depth_m));
        }
        total
    }

    /// Travel D = V t along the track (unit u) with lateral scatter L = f D x, x ~ U(-1, 1).
    fn carry(&self, velocity: [f64; 2]) -> Moments {
        let speed = velocity[0].hypot(velocity[1]);
        if !(speed > 0.0) {
            return Moments::default();
        }
        let along = [velocity[0] / speed, velocity[1] / speed];
        let across = [-along[1], along[0]];
        let (t1, t2) = (self.carry_s.mean(), self.carry_s.square());
        let cov = add2(
            outer(along, along, speed * speed * (t2 - t1 * t1)),
            outer(across, across, self.carry_lateral.powi(2) * speed * speed * t2 / 3.0),
        );
        Moments { mean: [speed * t1 * along[0], speed * t1 * along[1]], cov }
    }

    /// Drift V T while afloat, among elements that settle: T = 0 for those that sink at once.
    /// V = surface current + leeway x wind + error, independent of T.
    fn float(&self, water: &Water) -> Moments {
        let floats = if self.settles() > 0.0 { (self.settles() - self.sinks_at_once) / self.settles() } else { 0.0 };
        let (t1, t2) = (floats * self.float_s.mean(), floats * self.float_s.square());
        let (a1, a2) = (self.leeway.mean(), self.leeway.square());
        let w = water.wind;
        let drift = [water.surface_current[0] + a1 * w[0], water.surface_current[1] + a1 * w[1]];
        // E[V V^T] = Var(leeway) W W^T + sd^2 I + E[V] E[V]^T.
        let second = add2(
            add2(outer(w, w, a2 - a1 * a1), diagonal(water.surface_current_sd.powi(2))),
            outer(drift, drift, 1.0),
        );
        Moments { mean: [t1 * drift[0], t1 * drift[1]], cov: add2(scale2(second, t2), outer(drift, drift, -t1 * t1)) }
    }

    /// Glide with speed G w through the water whose heading diffuses with depth, memory l:
    /// E|offset|^2 = 2 G^2 l^2 (x - 1 + exp(-x)), x = depth / l, spread equally east and north.
    fn glide(&self, depth_m: f64) -> Moments {
        let square = self.glide_ratio.square()
            * self.glide_memory_m.expect(|l| {
                let x = depth_m / l;
                2.0 * l * l * (x + (-x).exp_m1())
            });
        Moments { mean: [0.0; 2], cov: diagonal(square / 2.0) }
    }
}

impl Element {
    /// One resting offset (m, east and north) drawn from the same model as `offset`, whose mean
    /// and covariance it shares exactly. The glide, whose shape has no closed form, is drawn as
    /// n straight legs in independent directions with the same mean square, n = x^2 / (2 (x - 1 +
    /// exp(-x))) (one leg, a ring of radius G H, for a straight glide), or as its Gaussian limit
    /// beyond 16 legs.
    pub fn draw(&self, water: &Water, velocity: [f64; 2], terms: &Terms, rng: &mut Rng) -> [f64; 2] {
        let pick = |r: &Range, rng: &mut Rng| r.quantile(rng.uniform());
        let mut at = [0.0; 2];
        let speed = velocity[0].hypot(velocity[1]);
        if terms.carry && speed > 0.0 {
            let along = [velocity[0] / speed, velocity[1] / speed];
            let d = speed * pick(&self.carry_s, rng);
            let lateral = self.carry_lateral * d * (2.0 * rng.uniform() - 1.0);
            at = [d * along[0] - lateral * along[1], d * along[1] + lateral * along[0]];
        }
        // Among elements that settle, a share (settles - sinks_at_once) / settles floats first.
        if terms.float && rng.uniform() * self.settles() >= self.sinks_at_once {
            let (t, a) = (pick(&self.float_s, rng), pick(&self.leeway, rng));
            let (e, n) = (rng.normal(), rng.normal());
            let sd = water.surface_current_sd;
            at[0] += t * (water.surface_current[0] + a * water.wind[0] + sd * e);
            at[1] += t * (water.surface_current[1] + a * water.wind[1] + sd * n);
        }
        if terms.current {
            let w = pick(&self.descent_factor, rng)
                * terminal_speed(
                    pick(&self.areal_density_kg_m2, rng),
                    pick(&self.material_density_kg_m3, rng),
                    pick(&self.drag_coefficient, rng),
                );
            let (e, n) = (rng.normal(), rng.normal());
            let sd = water.current_integral_sd;
            at[0] += (water.current_integral[0] + sd * e) / w;
            at[1] += (water.current_integral[1] + sd * n) / w;
        }
        if terms.glide {
            let (g, memory) = (pick(&self.glide_ratio, rng), pick(&self.glide_memory_m, rng));
            let x = water.depth_m / memory;
            let shape = x + (-x).exp_m1();
            let square = 2.0 * g * g * memory * memory * shape;
            let legs = x * x / (2.0 * shape);
            if legs <= 16.0 {
                let n = legs.round().max(1.0);
                let length = (square / n).sqrt();
                for _ in 0..n as usize {
                    let heading = std::f64::consts::TAU * rng.uniform();
                    at = [at[0] + length * heading.cos(), at[1] + length * heading.sin()];
                }
            } else {
                let sd = (square / 2.0).sqrt();
                at = [at[0] + sd * rng.normal(), at[1] + sd * rng.normal()];
            }
        }
        at
    }
}

/// A small deterministic generator (SplitMix64) for the draws: seeded from an impact sample's
/// own fields, so that a prediction is a function of the sample.
pub struct Rng(u64);

impl Rng {
    pub fn seeded(words: &[u64]) -> Rng {
        Rng(words.iter().fold(0x243F_6A88_85A3_08D3, |s, w| mix(s ^ w)))
    }

    /// A uniform draw on (0, 1).
    pub fn uniform(&mut self) -> f64 {
        self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
        ((mix(self.0) >> 11) as f64 + 0.5) / (1u64 << 53) as f64
    }

    pub fn normal(&mut self) -> f64 {
        (-2.0 * self.uniform().ln()).sqrt() * (std::f64::consts::TAU * self.uniform()).cos()
    }
}

fn mix(mut z: u64) -> u64 {
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

/// Current drift while sinking at a steady speed w: the depth-integrated current I over w,
/// exactly, since dt = dz / w. I carries an isotropic model error.
fn current(slowness: Slowness, water: &Water) -> Moments {
    let i = water.current_integral;
    let variance = slowness.square - slowness.mean * slowness.mean;
    Moments {
        mean: [slowness.mean * i[0], slowness.mean * i[1]],
        cov: add2(outer(i, i, variance), diagonal(slowness.square * water.current_integral_sd.powi(2))),
    }
}

/// The water at the contact point.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Water {
    pub depth_m: f64,
    /// Current integrated from the surface to the seabed (m2/s, east and north)...
    pub current_integral: [f64; 2],
    /// ...and its model error, per component (m2/s).
    pub current_integral_sd: f64,
    pub surface_current: [f64; 2],
    pub surface_current_sd: f64,
    /// 10 m wind (m/s).
    pub wind: [f64; 2],
}

/// The terms included in an offset: all of them for the estimate; the report turns them on one
/// at a time to show what each contributes.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Terms {
    pub carry: bool,
    pub float: bool,
    pub current: bool,
    pub glide: bool,
}

/// Mean and covariance of an east/north offset (m).
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Moments {
    pub mean: [f64; 2],
    pub cov: [[f64; 2]; 2],
}

impl Moments {
    /// The sum of two independent offsets.
    pub fn add(self, other: Moments) -> Moments {
        Moments { mean: [self.mean[0] + other.mean[0], self.mean[1] + other.mean[1]], cov: add2(self.cov, other.cov) }
    }

    /// A mixture with weights summing to one: the law of total covariance, taken about the
    /// mixture mean so that equal parts leave no rounding residue.
    pub fn mixture(parts: &[(f64, Moments)]) -> Moments {
        let mean = parts.iter().fold([0.0; 2], |a, (p, m)| [a[0] + p * m.mean[0], a[1] + p * m.mean[1]]);
        let cov = parts.iter().fold([[0.0; 2]; 2], |a, (p, m)| {
            let d = [m.mean[0] - mean[0], m.mean[1] - mean[1]];
            add2(a, scale2(add2(m.cov, outer(d, d, 1.0)), *p))
        });
        Moments { mean, cov }
    }

    /// (sd east, sd north, correlation); the correlation is 0 when either sd is 0.
    pub fn spread(&self) -> (f64, f64, f64) {
        let (se, sn) = (self.cov[0][0].max(0.0).sqrt(), self.cov[1][1].max(0.0).sqrt());
        let rho = if se > 0.0 && sn > 0.0 { (self.cov[0][1] / (se * sn)).clamp(-1.0, 1.0) } else { 0.0 };
        (se, sn, rho)
    }
}

fn outer(a: [f64; 2], b: [f64; 2], s: f64) -> [[f64; 2]; 2] {
    [[s * a[0] * b[0], s * a[0] * b[1]], [s * a[1] * b[0], s * a[1] * b[1]]]
}

fn diagonal(v: f64) -> [[f64; 2]; 2] {
    [[v, 0.0], [0.0, v]]
}

fn add2(a: [[f64; 2]; 2], b: [[f64; 2]; 2]) -> [[f64; 2]; 2] {
    [[a[0][0] + b[0][0], a[0][1] + b[0][1]], [a[1][0] + b[1][0], a[1][1] + b[1][1]]]
}

fn scale2(a: [[f64; 2]; 2], s: f64) -> [[f64; 2]; 2] {
    [[s * a[0][0], s * a[0][1]], [s * a[1][0], s * a[1][1]]]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn terminal_speed_by_hand_and_the_sphere_formula() {
        // By hand: s = 600 kg/m2, rho_m = 5,000 kg/m3, Cd = 1.0.
        // Buoyancy factor 1 - 1025/5000 = 0.795; 2 x 9.80665 x 600 x 0.795 = 9,355.544;
        // / 1025 = 9.127360; sqrt = 3.021152 m/s.
        assert!((terminal_speed(600.0, 5000.0, 1.0) - 3.021152).abs() < 1e-6);
        // A sphere of radius r has s = m / (pi r^2) = 4 r rho_m / 3, so the textbook result
        // w = sqrt(8 g r (rho_m - rho_w) / (3 rho_w Cd)) must follow. Steel ball, 5 mm radius,
        // Cd 0.47: w = sqrt(8 x 9.80665 x 0.005 x 6825 / (3 x 1025 x 0.47)) = 1.3610 m/s.
        let (r, rho, cd) = (0.005, 7850.0, 0.47);
        let textbook = (8.0 * GRAVITY * r * (rho - WATER_DENSITY) / (3.0 * WATER_DENSITY * cd)).sqrt();
        assert!((textbook - 1.3610).abs() < 1e-4);
        assert!((terminal_speed(4.0 * r * rho / 3.0, rho, cd) - textbook).abs() < 1e-12);
    }

    #[test]
    fn quadrature_matches_closed_form_moments() {
        // Uniform on [2, 5]: E[X^2] = (125 - 8) / 9 = 13; E[1/X] = ln(2.5) / 3.
        let u = Range { lo: 2.0, hi: 5.0, log: false };
        assert!((u.square() - 13.0).abs() < 1e-12);
        assert!((u.expect(|x| 1.0 / x) - 2.5f64.ln() / 3.0).abs() < 1e-12);
        // Log-uniform on [10, 1000]: E[X] = (1000 - 10) / ln(100); E[X^-1/2] = 2 (10^-1/2 - 1000^-1/2) / ln 100.
        let l = Range { lo: 10.0, hi: 1000.0, log: true };
        assert!((l.mean() / (990.0 / 100f64.ln()) - 1.0).abs() < 1e-12);
        let expected = 2.0 * (10f64.powf(-0.5) - 1000f64.powf(-0.5)) / 100f64.ln();
        assert!((l.expect(|x| x.powf(-0.5)) / expected - 1.0).abs() < 1e-12);
        assert_eq!(Range { lo: 3.0, hi: 3.0, log: false }.square(), 9.0);
    }

    #[test]
    fn mixture_is_the_law_of_total_covariance() {
        // Two point masses at (+-100, 0) with equal weight: mean 0, variance 100^2 east.
        let at = |x: f64| Moments { mean: [x, 0.0], cov: [[0.0; 2]; 2] };
        let m = Moments::mixture(&[(0.5, at(100.0)), (0.5, at(-100.0))]);
        assert_eq!(m.mean, [0.0, 0.0]);
        assert!((m.cov[0][0] - 1e4).abs() < 1e-9 && m.cov[1][1] == 0.0);
    }
}
