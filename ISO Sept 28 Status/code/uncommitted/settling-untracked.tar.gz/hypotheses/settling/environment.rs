//! The ocean at the contact point, from files outside git (paths in run.toml, relative to the
//! repository root): seabed depth and slope, the current integrated over depth, the surface
//! current, and the 10 m wind.

use serde::Deserialize;
use std::path::Path;

/// Little-endian int16 elevations (m, positive up), rows south to north, with a TOML sidecar of
/// the same stem (ETOPO 2022 at 1 arc-minute, as written for hypotheses/hydroacoustics).
pub struct Bathymetry {
    south: f64,
    west: f64,
    step_lat: f64,
    step_lon: f64,
    rows: usize,
    columns: usize,
    z: Vec<i16>,
}

#[derive(Deserialize)]
struct BathymetrySidecar {
    rows: usize,
    columns: usize,
    south_deg: f64,
    west_deg: f64,
    step_lat_deg: f64,
    step_lon_deg: f64,
}

impl Bathymetry {
    pub fn load(path: &Path) -> Result<Bathymetry, String> {
        let s: BathymetrySidecar = read_sidecar(path)?;
        let z = read_i16(path, s.rows * s.columns)?;
        Ok(Bathymetry::new(s.south_deg, s.west_deg, s.step_lat_deg, s.step_lon_deg, s.rows, s.columns, z))
    }

    pub fn new(south: f64, west: f64, step_lat: f64, step_lon: f64, rows: usize, columns: usize, z: Vec<i16>) -> Self {
        assert!(z.len() == rows * columns && rows >= 2 && columns >= 2);
        Bathymetry { south, west, step_lat, step_lon, rows, columns, z }
    }

    /// Bilinear elevation (m, positive up), or None outside the grid.
    pub fn elevation(&self, lat: f64, lon: f64) -> Option<f64> {
        let y = (lat - self.south) / self.step_lat;
        let x = (lon - self.west) / self.step_lon;
        if !(y >= 0.0 && x >= 0.0 && y <= (self.rows - 1) as f64 && x <= (self.columns - 1) as f64) {
            return None;
        }
        let (i, j) = ((y as usize).min(self.rows - 2), (x as usize).min(self.columns - 2));
        let (fy, fx) = (y - i as f64, x - j as f64);
        let at = |r: usize, c: usize| f64::from(self.z[r * self.columns + c]);
        Some((1.0 - fy) * ((1.0 - fx) * at(i, j) + fx * at(i, j + 1)) + fy * ((1.0 - fx) * at(i + 1, j) + fx * at(i + 1, j + 1)))
    }

    /// Water depth (m, positive down), or None on land or outside the grid.
    pub fn depth(&self, lat: f64, lon: f64) -> Option<f64> {
        self.elevation(lat, lon).map(|z| -z).filter(|d| *d > 0.0)
    }

    /// Seabed slope (degrees) from central differences one grid step either way: the slope on
    /// the grid's ~2 km scale, which smooths the steeper local relief.
    pub fn slope_deg(&self, lat: f64, lon: f64) -> Option<f64> {
        let (m, n) = geo::radii_of_curvature_km(lat);
        let dy_m = 2.0 * self.step_lat.to_radians() * m * 1000.0;
        let dx_m = 2.0 * self.step_lon.to_radians() * n * 1000.0 * lat.to_radians().cos();
        let north = self.elevation(lat + self.step_lat, lon)? - self.elevation(lat - self.step_lat, lon)?;
        let east = self.elevation(lat, lon + self.step_lon)? - self.elevation(lat, lon - self.step_lon)?;
        Some((north / dy_m).hypot(east / dx_m).atan().to_degrees())
    }
}

/// East and north components on a regular latitude/longitude grid, at several times and depth
/// layers, as written by prepare/ocean.py: little-endian int16, [component][time][layer][row]
/// [column], value = scale x packed, -32768 = no data (land, or below the model's seabed).
pub struct Stack {
    times: Vec<f64>,
    /// Layer edges (m, positive down), one more than the layers; [0, 0] for a surface field.
    edges: Vec<f64>,
    south: f64,
    west: f64,
    step: f64,
    rows: usize,
    columns: usize,
    scale: f64,
    values: Vec<i16>,
}

#[derive(Deserialize)]
struct StackSidecar {
    times_unix_s: Vec<f64>,
    layer_edges_m: Vec<f64>,
    south_deg: f64,
    west_deg: f64,
    step_deg: f64,
    rows: usize,
    columns: usize,
    scale: f64,
}

const NO_DATA: i16 = -32768;

impl Stack {
    pub fn load(path: &Path) -> Result<Stack, String> {
        let s: StackSidecar = read_sidecar(path)?;
        let layers = s.layer_edges_m.len().saturating_sub(1);
        let values = read_i16(path, 2 * s.times_unix_s.len() * layers * s.rows * s.columns)?;
        Stack::new(s.times_unix_s, s.layer_edges_m, s.south_deg, s.west_deg, s.step_deg, s.rows, s.columns, s.scale, values)
    }

    #[allow(clippy::too_many_arguments)]
    pub fn new(
        times: Vec<f64>,
        edges: Vec<f64>,
        south: f64,
        west: f64,
        step: f64,
        rows: usize,
        columns: usize,
        scale: f64,
        values: Vec<i16>,
    ) -> Result<Stack, String> {
        let increasing = |v: &[f64]| v.windows(2).all(|w| w[1] > w[0]);
        let layered = edges.len() >= 2 && (increasing(&edges) || edges == [0.0, 0.0]);
        if times.is_empty() || !increasing(&times) || !layered || rows < 2 || columns < 2 || !(step > 0.0) {
            return Err("stack: times must increase, layer edges must increase, and the grid needs 2 x 2 cells".into());
        }
        if values.len() != 2 * times.len() * (edges.len() - 1) * rows * columns {
            return Err("stack: size does not match the sidecar".into());
        }
        Ok(Stack { times, edges, south, west, step, rows, columns, scale, values })
    }

    fn layers(&self) -> usize {
        self.edges.len() - 1
    }

    fn value(&self, component: usize, time: usize, layer: usize, row: usize, column: usize) -> Option<f64> {
        let index = (((component * self.times.len() + time) * self.layers() + layer) * self.rows + row) * self.columns + column;
        let v = self.values[index];
        (v != NO_DATA).then(|| self.scale * f64::from(v))
    }

    /// The two times bracketing `unix_s`, with linear weights; None outside the time span.
    fn time_weights(&self, unix_s: f64) -> Option<[(usize, f64); 2]> {
        let n = self.times.len();
        if !(unix_s >= self.times[0] && unix_s <= self.times[n - 1]) {
            return None;
        }
        if n == 1 {
            return Some([(0, 1.0), (0, 0.0)]);
        }
        let k = self.times.partition_point(|&t| t <= unix_s).clamp(1, n - 1);
        let f = (unix_s - self.times[k - 1]) / (self.times[k] - self.times[k - 1]);
        Some([(k - 1, 1.0 - f), (k, f)])
    }

    /// `f(time, row, column)` interpolated bilinearly in space (weights renormalised over the
    /// grid points where f has data) and linearly in time. None outside the grid or the time
    /// span, or where no surrounding point has data.
    fn interpolate(&self, unix_s: f64, lat: f64, lon: f64, f: impl Fn(usize, usize, usize) -> Option<[f64; 2]>) -> Option<[f64; 2]> {
        let y = (lat - self.south) / self.step;
        let x = (lon - self.west) / self.step;
        if !(y >= 0.0 && x >= 0.0 && y <= (self.rows - 1) as f64 && x <= (self.columns - 1) as f64) {
            return None;
        }
        let (i, j) = ((y as usize).min(self.rows - 2), (x as usize).min(self.columns - 2));
        let (fy, fx) = (y - i as f64, x - j as f64);
        let corners = [(i, j, (1.0 - fy) * (1.0 - fx)), (i, j + 1, (1.0 - fy) * fx), (i + 1, j, fy * (1.0 - fx)), (i + 1, j + 1, fy * fx)];
        let mut total = [0.0; 2];
        for (t, wt) in self.time_weights(unix_s)? {
            if wt == 0.0 {
                continue;
            }
            let (mut sum, mut weight) = ([0.0; 2], 0.0);
            for &(r, c, w) in &corners {
                if let Some(v) = f(t, r, c) {
                    sum = [sum[0] + w * v[0], sum[1] + w * v[1]];
                    weight += w;
                }
            }
            if !(weight > 0.0) {
                return None;
            }
            total = [total[0] + wt * sum[0] / weight, total[1] + wt * sum[1] / weight];
        }
        Some(total)
    }

    /// The top layer's value (m/s): the surface current, or the wind of a surface field.
    pub fn surface(&self, unix_s: f64, lat: f64, lon: f64) -> Option<[f64; 2]> {
        self.interpolate(unix_s, lat, lon, |t, r, c| Some([self.value(0, t, 0, r, c)?, self.value(1, t, 0, r, c)?]))
    }

    /// The value integrated from the surface to `depth_m` (m2/s for a current). Layers below a
    /// column's deepest data (the model's seabed is shallower than the true one) continue with
    /// the deepest value, as does anything below the last layer.
    pub fn integral(&self, unix_s: f64, lat: f64, lon: f64, depth_m: f64) -> Option<[f64; 2]> {
        self.interpolate(unix_s, lat, lon, |t, r, c| {
            let mut sum = [0.0; 2];
            let mut deepest = None;
            for k in 0..self.layers() {
                let (top, bottom) = (self.edges[k], if k + 1 == self.layers() { f64::INFINITY } else { self.edges[k + 1] });
                if top >= depth_m {
                    break;
                }
                if let (Some(u), Some(v)) = (self.value(0, t, k, r, c), self.value(1, t, k, r, c)) {
                    deepest = Some([u, v]);
                }
                let [u, v] = deepest?; // no data at the top: land
                let thickness = bottom.min(depth_m) - top;
                sum = [sum[0] + u * thickness, sum[1] + v * thickness];
            }
            Some(sum)
        })
    }
}

fn read_sidecar<T: for<'de> Deserialize<'de>>(path: &Path) -> Result<T, String> {
    let sidecar = path.with_extension("toml");
    let text = std::fs::read_to_string(&sidecar).map_err(|e| format!("{}: {e}", sidecar.display()))?;
    toml::from_str(&text).map_err(|e| format!("{}: {e}", sidecar.display()))
}

fn read_i16(path: &Path, count: usize) -> Result<Vec<i16>, String> {
    let bytes = std::fs::read(path).map_err(|e| format!("{}: {e}", path.display()))?;
    if bytes.len() != 2 * count {
        return Err(format!("{}: expected {count} int16 values, found {} bytes", path.display(), bytes.len()));
    }
    Ok(bytes.chunks_exact(2).map(|b| i16::from_le_bytes([b[0], b[1]])).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A 2 x 2 grid (1 degree) with three layers: 0-100 m, 100-1000 m, 1000-3000 m.
    fn column(east: [i16; 3], deep_gap: bool) -> Stack {
        let mut values = Vec::new();
        for component in 0..2 {
            for layer in 0..3 {
                let v = if deep_gap && layer == 2 { NO_DATA } else if component == 0 { east[layer] } else { 0 };
                values.extend([v; 4]);
            }
        }
        Stack::new(vec![0.0], vec![0.0, 100.0, 1000.0, 3000.0], -40.0, 90.0, 1.0, 2, 2, 0.001, values).unwrap()
    }

    #[test]
    fn integral_sums_layers_to_the_depth_and_continues_the_deepest_value() {
        // 0.3 m/s over 100 m, 0.1 over 900 m, 0.02 over 1000-2500 m: 30 + 90 + 30 = 150 m2/s.
        let s = column([300, 100, 20], false);
        assert!((s.integral(0.0, -39.5, 90.5, 2500.0).unwrap()[0] - 150.0).abs() < 1e-9);
        // Partial top layer, and below the last edge the last layer continues.
        assert!((s.integral(0.0, -39.5, 90.5, 50.0).unwrap()[0] - 15.0).abs() < 1e-9);
        assert!((s.integral(0.0, -39.5, 90.5, 4000.0).unwrap()[0] - (120.0 + 0.02 * 3000.0)).abs() < 1e-9);
        // The model's seabed at 1000 m: its deepest value continues to the true depth.
        let shallow = column([300, 100, 20], true);
        assert!((shallow.integral(0.0, -39.5, 90.5, 2500.0).unwrap()[0] - (30.0 + 0.1 * 2400.0)).abs() < 1e-9);
        assert_eq!(s.surface(0.0, -39.5, 90.5), Some([0.3, 0.0]));
        assert_eq!(s.integral(0.0, -45.0, 90.5, 100.0), None);
    }

    #[test]
    fn bathymetry_depth_and_slope() {
        // Elevation falls 100 m per 0.1 degree eastward: a slope of atan(100 / dx).
        let z: Vec<i16> = (0..5).flat_map(|_| (0..5).map(|c| (-3000 - 100 * c) as i16)).collect();
        let b = Bathymetry::new(-40.2, 90.0, 0.1, 0.1, 5, 5, z);
        assert!((b.depth(-40.0, 90.25).unwrap() - 3250.0).abs() < 1e-9);
        let (_, n) = geo::radii_of_curvature_km(-40.0);
        let dx = 0.1f64.to_radians() * n * 1000.0 * (-40.0f64).to_radians().cos();
        assert!((b.slope_deg(-40.0, 90.2).unwrap() - (100.0 / dx).atan().to_degrees()).abs() < 1e-9);
        assert_eq!(b.depth(-30.0, 90.2), None);
    }
}
