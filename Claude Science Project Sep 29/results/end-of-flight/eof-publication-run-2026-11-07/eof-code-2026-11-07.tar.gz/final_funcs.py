
# ====================== FINAL: case-informed kernel integration (7 Nov 2026) ======================
ATT = {r: L.run_att(f"Case {r:02d}.csv") for r in range(1, 11)}
STK = ("lat", "lon", "h", "ve", "vn", "vu", "bank", "gam", "hd")
IMPK = ("t", "lat", "lon", "ve", "vn", "vu", "gam", "bank", "hd", "tas", "mach_max", "eas_max", "n_max", "n_min", "arrested", "a8r", "t15r", "h_bottom")
PRMK = ("a8", "t15", "d_on", "phi_m", "arrest", "v_pre_fpm")
THRUST_N = 55000.0
def _gam_hd(ve, vn, vu):
    gs = np.hypot(ve, vn) * KT; return np.degrees(np.arctan2(vu * 0.3048 / 60, np.maximum(gs, 1.0))), np.degrees(np.arctan2(ve, vn)) % 360

def kernel_fly(lat0, lon0, h0, ve_kt, vn_kt, vu_fpm, tstart, mass, thr_end, prm, prof, gam_given):
    n = len(lat0); w = wind_at(prof, np.clip(h0, 0, 43000)) / KT
    ae = ve_kt - w[:, 0]; an = vn_kt - w[:, 1]; hor = np.hypot(ae, an) * KT; vz = vu_fpm * 0.3048 / 60
    V0 = np.sqrt(hor ** 2 + vz ** 2); psi0 = np.arctan2(ae, an); gam0 = np.where(gam_given, np.arctan2(vz, np.maximum(hor, 1.0)), np.nan)
    targets = np.stack([T29 - tstart, T37 - tstart, T2106 - tstart], 1).astype(np.float64)
    rec, out = DK.fly_kernel(lat0.astype(np.float64), lon0.astype(np.float64), h0.astype(np.float64), V0, psi0, gam0, mass.astype(np.float64),
                             np.full(n, THRUST_N), thr_end.astype(np.float64), prm["v_pre_fpm"], prm["d_on"], prm["a8"], prm["t15"], prm["phi_m"], prm["sgn"],
                             prm["arrest"], prm["h_pull_ft"], prm["n_rec"], prm["gam_top"], prm["phi_arr"], targets, E5["lev"].astype(np.float64),
                             np.ascontiguousarray(prof, dtype=np.float32), 0.5, np.full(n, 3000.0))
    return rec, {k: out[:, i] for i, k in enumerate(DK.OUT_NAMES)}

def fly_final(rows, d_on=None):
    n = len(rows["tP"]); K = rows["K"]; grp = np.where(K == 2, np.where(rows["gap"] > 330.0, 1, 2), 0)
    times = {"m29": T29, "m37": T37, "m2106": T2106}
    St = {nm: {k: np.full(n, np.nan) for k in STK} for nm in times}; imp = {k: np.full(n, np.nan) for k in IMPK}
    P = {k: np.full(n, np.nan) for k in PRMK}; steep = np.zeros(n, bool); t_steep = np.full(n, np.inf); run = np.zeros(n, int)
    kn = np.flatnonzero(grp == 0)
    if len(kn):                                                     # normal configuration: Boeing replay (v2 spread) ...
        rn = {k: v[kn] for k, v in rows.items()}; Fn = fly(rn, times, steep_state=True); run[kn] = Fn["run"]
        for nm in times:
            s = Fn[nm]; bank = np.zeros(len(kn))
            for r in NORMAL:
                m = Fn["run"] == r
                if m.any(): bank[m] = np.interp(s["tau"][m], ATT[r].t.values, ATT[r].bank.values)
            gm, hd = _gam_hd(s["ve"], s["vn"], s["vu"])
            for k, v in (("lat", s["lat"]), ("lon", s["lon"]), ("h", s["h"]), ("ve", s["ve"]), ("vn", s["vn"]), ("vu", s["vu"]), ("bank", bank), ("gam", gm), ("hd", hd)):
                St[nm][k][kn] = v
        I = Fn["impact"]; gm, hd = _gam_hd(I["ve"], I["vn"], I["vu"]); bank = np.zeros(len(kn))
        for r in NORMAL:
            m = Fn["run"] == r
            if m.any(): bank[m] = np.interp(I["tau"][m], ATT[r].t.values, ATT[r].bank.values)
        for k, v in (("t", I["t"]), ("lat", I["lat"]), ("lon", I["lon"]), ("ve", I["ve"]), ("vn", I["vn"]), ("vu", I["vu"]), ("gam", gm), ("bank", bank), ("hd", hd)): imp[k][kn] = v
        imp["tas"][kn] = np.hypot(np.hypot(I["ve"], I["vn"]) * KT, I["vu"] * 0.3048 / 60); imp["arrested"][kn] = 0.0
        stp = Fn["steep"]; steep[kn] = stp; t_steep[kn] = Fn["t_steep"]
        ks = kn[stp]
        if len(ks):                                                 # ... with the late steep ending flown by the case-informed kernel
            A = {k: v[stp] for k, v in Fn["at_steep"].items()}; tS = rows["tP"][ks] + Fn["t_steep"][stp]
            prm = KP.draw(len(ks), rng, CP, d_on=np.zeros(len(ks))); prm["v_pre_fpm"] = np.clip(-A["vu"], 0, 14000)
            prof = wind_profile(A["lat"], A["lon"], tS)
            rec, o = kernel_fly(A["lat"], A["lon"], A["h"], A["ve"], A["vn"], A["vu"], tS, rows["mass"][ks], np.zeros(len(ks)), prm, prof, np.ones(len(ks), bool))
            for j_, nm in enumerate(times):
                ok = np.isfinite(rec[:, j_, 0])
                for c_, k in enumerate(DK.REC_NAMES):
                    kk = {"h_ft": "h", "vn_kt": "vn", "ve_kt": "ve", "vu_fpm": "vu", "bank_deg": "bank", "gamma_deg": "gam", "heading_deg": "hd"}.get(k, k)
                    St[nm][kk][ks[ok]] = rec[ok, j_, c_]
            _put_imp(imp, ks, o, tS)
            for k in PRMK: P[k][ks] = np.asarray(prm[k], float)
    ka = np.flatnonzero(grp > 0)
    if len(ka):                                                     # alternate configuration: case-informed kernel from the power loss
        prm = KP.draw(len(ka), rng, CP, d_on=None if d_on is None else np.asarray(d_on, float)[ka])
        tP = rows["tP"][ka]; prof = wind_profile(rows["lat0"][ka], rows["lon0"][ka], tP)
        ve0 = rows["vE"][ka] / KT; vn0 = rows["vN"][ka] / KT
        rec, o = kernel_fly(rows["lat0"][ka], rows["lon0"][ka], rows["h0"][ka], ve0, vn0, np.zeros(len(ka)), tP, rows["mass"][ka],
                            np.where(np.isfinite(rows["gap"][ka]), rows["gap"][ka], 1e6), prm, prof, np.zeros(len(ka), bool))
        gm0, hd0 = _gam_hd(ve0, vn0, np.zeros(len(ka)))
        for j_, nm in enumerate(times):
            ok = np.isfinite(rec[:, j_, 0])
            pre = {"lat": rows["lat0"][ka], "lon": rows["lon0"][ka], "h": rows["h0"][ka], "ve": ve0, "vn": vn0, "vu": np.zeros(len(ka)), "bank": np.zeros(len(ka)), "gam": gm0, "hd": hd0}
            for c_, k in enumerate(DK.REC_NAMES):
                kk = {"h_ft": "h", "vn_kt": "vn", "ve_kt": "ve", "vu_fpm": "vu", "bank_deg": "bank", "gamma_deg": "gam", "heading_deg": "hd"}.get(k, k)
                St[nm][kk][ka] = np.where(ok, rec[:, j_, c_], pre[kk])        # before the power loss: powered state at takeover
        _put_imp(imp, ka, o, tP)
        for k in PRMK: P[k][ka] = np.asarray(prm[k], float)
    return dict(m29=St["m29"], m37=St["m37"], m2106=St["m2106"], impact=imp, grp=grp, run=run, steep=steep, t_steep=t_steep,
                s_t=np.ones(n), s_h=np.ones(n), params=P)

def _put_imp(imp, ix, o, tstart):
    imp["t"][ix] = tstart + o["t_rel_s"]
    for k, src_ in (("lat", "lat"), ("lon", "lon"), ("ve", "ve_kt"), ("vn", "vn_kt"), ("vu", "vu_fpm"), ("gam", "gamma_deg"), ("bank", "bank_deg"), ("hd", "heading_deg"),
                    ("tas", "tas_mps"), ("mach_max", "max_mach"), ("eas_max", "max_eas_kt"), ("n_max", "max_n_g"), ("n_min", "min_n_g"), ("arrested", "arrested"),
                    ("a8r", "a8_realised_g"), ("t15r", "t15_after_onset_s"), ("h_bottom", "h_bottom_ft")):
        imp[k][ix] = o[src_]

def is_stage_final(rows, F, D, caus, ife_a1, ti, st29, st37, idx, bmean, bvar, Dst, R2):
    """Importance sampling of the onset delay for alternate-configuration rows with power loss before 00:19:29 (exact).
    Each such row is replaced by M replicates; the onset delay is drawn from q = PF * prior + (1 - PF) * U[window], where the window
    puts the onset between 25 s before and 3 s after 00:19:29; weight prior/q/M. All other kernel parameters come from the prior."""
    M = int(os.environ.get("A1GEN_IS_M", "8")); PF = float(os.environ.get("A1GEN_IS_PRIOR", "0.15"))
    sel = np.flatnonzero((F["grp"] > 0) & (rows["tP"] < T29)); n = len(sel)
    if n == 0: return rows, F, D, caus, ife_a1, ti, st29, st37, idx, {}
    ridx = np.tile(sel, M); tPr = rows["tP"][ridx]
    lo = np.maximum(T29 - 25.0 - tPr, 0.5); hi = np.maximum(T29 + 3.0 - tPr, lo + 1.0)
    fp = rng.random(M * n) < PF
    d = np.where(fp, KP.predictive(CP, "onset_delay_s", "noinput", M * n, rng), lo + (hi - lo) * rng.random(M * n))
    lp = don_logpdf(d); inwin = (d >= lo) & (d <= hi)
    lq = np.logaddexp(np.log(PF) + lp, np.where(inwin, np.log(1 - PF) - np.log(hi - lo), -np.inf))
    logw = lp - lq - np.log(M)
    parts = []
    for c0 in range(0, M * n, 250000):
        ks = np.arange(c0, min(c0 + 250000, M * n)); rr = ridx[ks]
        rws = {k: v[rr] for k, v in rows.items()}
        Fr = fly_final(rws, d_on=d[ks])
        Dr, cr, ir, tr, s29, s37 = score(Fr, rws, bmean[rr], bvar[rr], {k: v[rr] for k, v in Dst.items()}, R2["ffinal"][idx[rr]])
        parts.append((rws, Fr, Dr, cr, ir, tr))
    rws, Fr, Dr, cr, ir, tr = parts[0]
    for p_ in parts[1:]:
        rws = _cat(rws, p_[0]); Fr = {k: _cat(Fr[k], p_[1][k]) for k in Fr}; Dr = _cat(Dr, p_[2]); cr = _cat(cr, p_[3]); ir = _cat(ir, p_[4]); tr = _cat(tr, p_[5])
    base = len(R2["fam"]); newpos = base + np.arange(M * n); orig = idx[ridx]
    for key in ("fam", "sel", "lat", "lon", "arc", "timp", "cfg", "flown", "ffinal", "tP_n", "tP_a", "surv"):
        if key in R2 and np.ndim(R2[key]) == 1 and len(R2[key]) == base: R2[key] = np.r_[R2[key], np.asarray(R2[key])[orig]]
    R2["lw"] = np.r_[R2["lw"], np.asarray(R2["lw"])[orig] + logw]; R2["lw"][idx[sel]] = -np.inf
    R2["cellsD"] = {k: np.r_[v, v[orig]] for k, v in R2["cellsD"].items()}
    R2["newc"] = {k: np.r_[v, v[orig]] for k, v in R2["newc"].items()}
    R2["orig"] = np.r_[np.arange(base), orig]
    keepF = [k for k in F if k in Fr]
    F2 = {k: _cat(F[k], Fr[k]) for k in keepF}
    rows2 = {k: np.r_[rows[k], rws[k]] for k in rows}
    info = dict(is_rows=int(n), is_M=M, is_prior_frac=PF, is_logw_q=[float(v) for v in np.quantile(logw + np.log(M), [0.01, 0.5, 0.99])])
    return rows2, F2, _cat(D, Dr), _cat(caus, cr), np.r_[ife_a1, ir], np.r_[ti, tr], F2["m29"], F2["m37"], np.r_[idx, newpos], info
