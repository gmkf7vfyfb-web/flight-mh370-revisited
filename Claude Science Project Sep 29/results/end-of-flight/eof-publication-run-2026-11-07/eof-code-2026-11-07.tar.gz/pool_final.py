"""Pool the final end-of-flight seeds (a1gen_final.py outputs) per route family. Every treatment and variant is a re-weighting of the
same thinned rows. Seeds are pooled by total evidence (core hand-off evidence + end-of-flight evidence), i.e. the rows of all seeds form
one importance sample. Seed bootstrap gives Monte Carlo intervals. Log evidence is compared only within the same data group (spec).
Writes tables (CSV), pooled weighted draws for figures, and the downstream hand-off sample (thinned, unbiased)."""
import json, glob, re, gzip, sys, os, numpy as np, pandas as pd
W = "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07"; E = "/Users/pete/Downloads/mh370-exchange/core/run-j"
SPEC = json.load(open(W + "/eof-final-spec.json")); TR = SPEC["treatments"]
OUTD = sys.argv[1] if len(sys.argv) > 1 else W + "/out"; RES = sys.argv[2] if len(sys.argv) > 2 else W + "/results"; os.makedirs(RES, exist_ok=True)
FAMNAME = {1: "No pilot after fuel exhaustion", 2: "Piloted after fuel exhaustion", 3: "Planned descent"}
VARIANTS = {"headline": {}, "cause prior 0.5": {"cause": "g50"}, "two-stage log-on delay": {"cause": "two"},
            "include lost-control piloted paths": {"lostc": False}, "00:21:06 entertainment-system factor": {"ife": True},
            "piloted push-over from cases": {"R": "push_cases"}, "onset delay log-uniform 10-300 s": {"R": "onset_loguniform"},
            "arrest probability 0.2": {"R": "arrest_0.2"}, "arrest probability 0.9": {"R": "arrest_0.9"}}
def core_lnz(fam, s):
    p = f"{E}/run-j-waypoints/bto-bfo/seed-{s}/handoff-m2241/handoff.toml.gz" if fam == "wp" else f"{E}/run-j-repro-radar/bto-bfo/seed-{s}/handoff-m0011/handoff.toml.gz"
    for line in gzip.open(p, "rt"):
        m = re.match(r"log_evidence = (\S+)", line)
        if m: return float(m.group(1))
def load(fam):
    seeds = sorted(int(re.search(r"-s(\d+)\.npz", p).group(1)) for p in glob.glob(f"{OUTD}/{fam}-s*.npz"))
    Z = {s: dict(np.load(f"{OUTD}/{fam}-s{s}.npz")) for s in seeds}; zc = {s: core_lnz(fam, s) for s in seeds}
    for s in seeds:
        Z[s]["seed"] = np.full(len(Z[s]["lw"]), s, np.int16); Z[s]["lw"] = Z[s]["lw"] + zc[s]
        other = ~np.isin(Z[s]["fam"], (1, 2, 3))                       # family code 6 etc.: flown by the withdrawn uncontrolled law (review 7 Nov)
        Z[s]["lostc"] = Z[s]["lostc"] | other | (Z[s]["o_reached"] < 0.5)   # also: kernel paths that did not reach the sea within 3,000 s (declared, about 1e-4 of rows)
        Z[s]["ife"] = np.where(other, np.log1p(-0.5 * (Z[s]["t_imp"] > 97.471)), Z[s]["ife"]).astype(np.float32)
        Z[s]["gam_desc"] = np.degrees(np.arctan2(np.sqrt(np.maximum(Z[s]["vke"], 0)), np.sqrt(np.maximum(Z[s]["ke"] - Z[s]["vke"], 0)))).astype(np.float32)
    X = {k: np.concatenate([Z[s][k] for s in seeds]) for k in Z[seeds[0]]}
    return seeds, X
def logw(X, D, v):
    cause = v.get("cause", "g75"); lw = X["lw"] + X["D_" + D].astype(np.float64) + (0.0 if D == "D13" else X["C_" + cause].astype(np.float64))
    if v.get("lostc", True): lw = np.where(X["lostc"], -np.inf, lw)
    if v.get("ife"): lw = lw + X["ife"]
    if "R" in v: lw = lw + X["R_" + v["R"]].astype(np.float64)
    return np.where(np.isfinite(lw), lw, -np.inf)
def wq(x, w, q):
    o = np.argsort(x); c = np.cumsum(w[o]); c /= c[-1]; return [float(x[o][min(np.searchsorted(c, qq), len(o) - 1)]) for qq in q]
def stats(X, lw, seeds, nboot=200, rng=None):
    sid = X["seed"]; S = len(seeds); m = lw.max(); w = np.exp(lw - m); Zs = np.array([w[sid == s].sum() for s in seeds])
    lnZ = float(np.log(Zs.mean()) + m); p = w / w.sum(); a = np.abs(X["arc"]); r = dict(lnZ=lnZ, ess=float(1 / np.sum(p ** 2)))
    for c, nm in FAMNAME.items():
        k = X["fam"] == c; sh = p[k].sum(); r["share: " + nm] = float(sh); r["ESS: " + nm] = float(sh ** 2 / max(np.sum(p[k] ** 2), 1e-300))
    r["share: other (descent begun before fuel exhaustion, no intervention)"] = float(p[~np.isin(X["fam"], (1, 2, 3))].sum())
    r["provisional (no-pilot ESS < 500)"] = bool(r["ESS: " + FAMNAME[1]] < 500 and r["share: " + FAMNAME[1]] > 0.01)
    k1 = X["fam"] == 1; r["alternate configuration within no-pilot"] = float(p[k1 & (X["cfg"] == 2)].sum() / max(p[k1].sum(), 1e-300))
    hi = X["ke"] >= 4e9; fast = -X["o_vs37"] >= 10000
    r["high-energy impact (>= 4 GJ)"] = float(p[hi].sum()); r["fast descent at 00:19:37 (>= 10,000 ft/min)"] = float(p[fast].sum())
    r["fast at 00:19:37 and high-energy impact"] = float(p[fast & hi].sum())
    for q, v in zip((5, 50, 95), wq(X["lat"], p, (0.05, 0.5, 0.95))): r[f"latitude q{q}"] = v
    for q, v in zip((50, 90, 95, 99), wq(a, p, (0.5, 0.9, 0.95, 0.99))): r[f"|arc distance| q{q} NM"] = v
    for d in (10, 25, 50): r[f"within {d} NM"] = float(p[a <= d].sum())
    for q, v in zip((1, 50, 99), wq(X["arc"], p, (0.01, 0.5, 0.99))): r[f"signed arc distance q{q} NM"] = v
    for q, v in zip((5, 50, 95), wq(X["t_imp"] / 60, p, (0.05, 0.5, 0.95))): r[f"impact min after 00:19:29 q{q}"] = v
    ok = np.isfinite(X["ke"])
    for q, v in zip((5, 50, 95), wq(X["ke"][ok] / 1e9, p[ok] / p[ok].sum(), (0.05, 0.5, 0.95))): r[f"impact kinetic energy GJ q{q}"] = v
    if rng is not None:
        bs = []
        for _ in range(nboot):
            pick = rng.integers(0, S, S); wb = np.zeros(len(w)); cnt = np.bincount(pick, minlength=S)
            for i_, s in enumerate(seeds):
                if cnt[i_]: wb[sid == s] = w[sid == s] * cnt[i_]
            pb = wb / wb.sum(); bs.append((np.log(np.mean(Zs[pick])) + m, pb[X["fam"] == 1].sum(), wq(X["lat"], pb, (0.5,))[0], pb[a <= 25].sum()))
        bs = np.array(bs); r["boot_lnZ"] = bs[:, 0]
        for i_, nm in ((1, "share: " + FAMNAME[1]), (2, "latitude q50"), (3, "within 25 NM")): r[nm + " 90% seed interval"] = f"{np.quantile(bs[:, i_], 0.05):.3f} to {np.quantile(bs[:, i_], 0.95):.3f}"
    return r, p
if __name__ == "__main__":
    rng = np.random.default_rng(20261107); rows = []; vrows = []
    for fam, fname in (("df", "Davey model + fuel"), ("wp", "Waypoints")):
        seeds, X = load(fam); print(fam, len(seeds), "seeds", len(X["lw"]), "rows", flush=True)
        if os.environ.get("POOL_EXPECT", "1") == "1" and OUTD.endswith("/out"): assert len(seeds) == (16 if fam == "df" else 24), f"{fam}: {len(seeds)} seeds"
        res = {}; P = {}
        for D in TR:
            r, p = stats(X, logw(X, D, {}), seeds, rng=rng); res[D] = r; P[D] = p
        for D in TR:
            r = res[D]; grp = TR[D]["group"]; ref = next(k for k in TR if TR[k]["group"] == grp)
            dz = r["lnZ"] - res[ref]["lnZ"]; bz = r["boot_lnZ"] - res[ref]["boot_lnZ"]
            row = {"route family": fname, "code": D, "00:19 treatment": TR[D]["label"], "headline": TR[D]["headline"], "data group": grp, "seeds": len(seeds),
                   "ln Z": round(r["lnZ"], 3), "ln Z relative to first treatment of the same group": ("reference" if D == ref else f"{dz:+.2f} ({np.quantile(bz, 0.05):+.2f} to {np.quantile(bz, 0.95):+.2f})")}
            row.update({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items() if k not in ("lnZ", "boot_lnZ")}); rows.append(row)
            # pooled weighted draws for figures (resampled 60,000)
            pick = rng.choice(len(P[D]), size=60000, p=P[D])
            np.save(f"{RES}/pooled-draws-{fam}-{D}.npy", np.c_[X["lat"][pick], X["lon"][pick], X["arc"][pick], X["t_imp"][pick] / 60, X["fam"][pick], X["cfg"][pick],
                                                               X["ke"][pick] / 1e9, -X["o_vs37"][pick], X["gam_desc"][pick]].astype(np.float32))
        for vn, v in VARIANTS.items():
            for D in ("D0", "D7", "D8", "D9", "D10", "D14", "D11"):
                r, _ = stats(X, logw(X, D, v), seeds)
                vrows.append({"route family": fname, "variant": vn, "code": D, "00:19 treatment": TR[D]["label"], "ln Z": round(r["lnZ"], 3),
                              **{k: round(r[k], 4) for k in ("share: " + FAMNAME[1], "share: " + FAMNAME[2], "share: " + FAMNAME[3], "latitude q50", "|arc distance| q95 NM", "within 25 NM",
                                                            "impact min after 00:19:29 q50", "high-energy impact (>= 4 GJ)", "fast descent at 00:19:37 (>= 10,000 ft/min)", "ESS: " + FAMNAME[1])}})
        # downstream hand-off: thinned rows keeping every headline treatment's pooled weight (unbiased roulette), log-weight per treatment
        HL = [D for D in TR if TR[D]["headline"]]; lws = {D: logw(X, D, {}) for D in HL}
        pmax = np.zeros(len(X["lw"]))
        for D in HL:
            m = lws[D].max(); q = np.exp(lws[D] - m); pmax = np.maximum(pmax, q / q.sum())
        target = 500000.0; lo, hi = -60.0, 0.0
        for _ in range(80):
            me = 0.5 * (lo + hi); lo, hi = (me, hi) if np.sum(np.minimum(1, pmax / np.exp(me))) > target else (lo, me)
        eps = np.exp(0.5 * (lo + hi)); pk = np.minimum(1, pmax / eps); keep = (pmax > 0) & (rng.random(len(pmax)) < pk); K = np.flatnonzero(keep)
        H = {"log_weight_" + D: (lws[D][K] - np.log(pk[K])).astype(np.float64) for D in HL}
        cols = {"latitude_deg": "lat", "longitude_deg": "lon", "arc_distance_nm_signed": "arc", "impact_s_after_001929": "t_imp", "kinetic_energy_j": "ke",
                "vertical_kinetic_energy_j": "vke", "mass_kg": "mass", "flight_path_angle_deg_descent_positive": "gam_desc", "bank_deg": "o_bank", "ground_track_deg": "o_hd",
                "ground_speed_mps": "o_tas", "reached_sea": "o_reached", "max_mach": "o_mach_max", "max_eas_kt": "o_eas_max", "max_load_factor_g": "o_n_max", "min_load_factor_g": "o_n_min",
                "vertical_speed_001929_fpm": "o_vs29", "vertical_speed_001937_fpm": "o_vs37", "family_code": "fam", "electrical_configuration_code": "cfg",
                "first_flameout_s_after_001929": "o_ffirst", "final_flameout_s_after_001929": "o_ffinal", "seed": "seed", "arrested_dive": "o_arrested", "late_steep_ending": "steep"}
        H.update({k: X[v][K] for k, v in cols.items()})
        np.savez_compressed(f"{RES}/eof-final-handoff-{fam}.npz", **H)
        json.dump(dict(route_family=fname, rows=int(len(K)), treatments={D: TR[D]["label"] for D in HL}, columns=list(cols), family_codes=FAMNAME,
                       electrical_configuration_codes={0: "mixture (planned descent, no draw)", 1: "normal", 2: "alternate"},
                       use="Weights: w = exp(log_weight_<treatment>), normalise to sum 1. Every downstream module scores these same rows (composition rule 3).",
                       caveats=["Impact energy, attitude and angle of the no-pilot dives come from the case-informed kernel; dives above about Mach 0.99 have no recorded transport precedent.",
                                "Piloted rows keep the engine trajectories; their impact attitude is the engine's.", "Break-up is not applied; settling applies it.",
                                "Energy-transfer duration is not computed (declared absence).",
                                "Flight-path angle: ground-relative, positive in descent, from the kinetic energies. Speed: ground speed. Track: ground track. Bank: kernel or engine value; normal-configuration glides use the Boeing donor bank.",
                                "Impact energy of no-pilot alternate-configuration dives is at or above the top of the Boeing range; treat the 4 GJ label as a sensitivity.",
                                "Only headline-treatment weights are carried; variants need the per-seed component files (out/*.npz)."]),
                  open(f"{RES}/eof-final-handoff-{fam}.json", "w"), indent=1)
        print(fam, "hand-off rows", len(K), flush=True)
    T = pd.DataFrame(rows); T.to_csv(f"{RES}/eof-final-treatments.csv", index=False)
    V = pd.DataFrame(vrows); V.to_csv(f"{RES}/eof-final-variants.csv", index=False)
    pd.set_option("display.width", 250); print(T[["route family", "code", "ln Z", "ln Z relative to first treatment of the same group", "share: " + FAMNAME[1], "latitude q50", "|arc distance| q95 NM", "within 25 NM", "impact min after 00:19:29 q50"]].to_string(index=False))
