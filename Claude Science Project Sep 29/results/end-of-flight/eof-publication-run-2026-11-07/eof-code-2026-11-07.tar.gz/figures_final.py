"""Figures for the final end-of-flight run: working versions (with plain and technical footnotes) and Journal of Navigation
versions (greyscale, 127 mm wide, no title, no footnotes; 600 dpi -word.png + PDF + proof with caption + caption text)."""
import sys, json, textwrap, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
W = "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07"; sys.path.insert(0, W)
import eof_fast_lib as L
RES = sys.argv[1] if len(sys.argv) > 1 else W + "/results"; FIG = sys.argv[2] if len(sys.argv) > 2 else W + "/figs"
SPEC = json.load(open(W + "/eof-final-spec.json")); TR = SPEC["treatments"]
T = pd.read_csv(RES + "/eof-final-treatments.csv"); V = pd.read_csv(RES + "/eof-final-variants.csv")
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"], "font.size": 8, "axes.titlesize": 8,
                     "axes.labelsize": 8, "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.spines.top": False, "axes.spines.right": False})
MM = 1 / 25.4; WID = 127 * MM
SHORT = {"D13": "Nothing used after 00:11", "D0": "Log-on event only", "D7": "Both 00:19 timings", "D8": "Both timings + first frequency",
         "D9": "Both timings + both frequencies as recorded", "D10": "Both timings + both frequencies, Holland offset",
         "D14": "Both timings + both frequencies, Holland offset (zero floor)", "D11": "Both timings + offset on second frequency only"}
def draws(fam, D): return np.load(f"{RES}/pooled-draws-{fam}-{D}.npy")
ARC = None
def arc7():
    global ARC
    if ARC is None:
        la = np.linspace(-44, -14, 61); ARC = (la, np.array([L.arc_lon("m0019a", x, 0.0, 18400.0) for x in la]))
    return ARC
def save(fig, name, caption, foot_plain, foot_tech, jon_builder):
    # working version: footnotes at the bottom (plain + technical), at most about 25 % of the height
    w = 160 * MM; h = fig.get_size_inches()[1]
    fp = "\n".join(textwrap.wrap("Plain note: " + foot_plain, 150)); ft = "\n".join(textwrap.wrap("Technical note: " + foot_tech, 150))
    nl = fp.count("\n") + ft.count("\n") + 2; extra = (nl * 7.5 + 6) / 72
    b0 = getattr(fig, "_b0", 0.09); fig.set_size_inches(w, h + extra); fig.subplots_adjust(bottom=extra / (h + extra) + b0 * h / (h + extra))
    fig.text(0.01, 0.005, fp + "\n" + ft, fontsize=6, va="bottom", ha="left", family="serif")
    fig.savefig(f"{FIG}/{name}-working.png", dpi=200); plt.close(fig)
    # journal version
    fj = jon_builder(); fj.savefig(f"{FIG}/{name}-word.png", dpi=600, bbox_inches="tight"); fj.savefig(f"{FIG}/{name}.pdf", bbox_inches="tight")
    hj = fj.get_size_inches()[1]; cap = "\n".join(textwrap.wrap(caption, 120)); nlc = cap.count("\n") + 1; ex = (nlc * 9 + 8) / 72
    bj = getattr(fj, "_bj", 0.35); fj.set_size_inches(WID, hj + ex); fj.subplots_adjust(bottom=(ex + bj) / (hj + ex))
    fj.text(0.0, 0.01, cap, fontsize=7, va="bottom", ha="left"); fj.savefig(f"{FIG}/{name}-proof.png", dpi=300, bbox_inches="tight"); plt.close(fj)
    open(f"{FIG}/{name}-caption.txt", "w").write(caption + "\n")

# ---------- Figure 1: impact density maps, Davey model + fuel, four treatments ----------
def fig_maps(jon=False):
    Ds = ["D7", "D8", "D9", "D10"]; fig, axs = plt.subplots(2, 2, figsize=(WID if jon else 160 * MM, (WID if jon else 160 * MM) * 0.95), sharex=True, sharey=True)
    la, lo = arc7()
    for ax, D, let in zip(axs.flat, Ds, "abcd"):
        X = draws("df", D); H, xe, ye = np.histogram2d(X[:, 1], X[:, 0], bins=[np.arange(86, 96.01, 0.1), np.arange(-41, -32.99, 0.1)])
        Hn = H.T / np.quantile(H[H > 0], 0.995); Hn = np.clip(Hn, 0, 1); ax.imshow(np.where(Hn > 0.005, Hn, np.nan), origin="lower", extent=[xe[0], xe[-1], ye[0], ye[-1]], cmap="Greys", vmin=0, vmax=1, aspect=1 / np.cos(np.radians(37)))
        ax.plot(lo, la, color="0.25", lw=0.8, ls="--"); ax.set_xlim(86, 96); ax.set_ylim(-41, -33)
        ax.text(0.03, 0.97, f"({let})" if jon else f"({let}) {SHORT[D]}", transform=ax.transAxes, va="top", ha="left", fontsize=7)
    for ax in axs[1]: ax.set_xlabel("Longitude (deg E)")
    for ax in axs[:, 0]: ax.set_ylabel("Latitude (deg)")
    fig.tight_layout(); return fig

# ---------- Figure 2: distance from the 7th arc ----------
def fig_arc(jon=False):
    fig, axs = plt.subplots(1, 2, figsize=(WID if jon else 160 * MM, 72 * MM), sharey=True)
    styles = {"D13": ("0.6", ":"), "D0": ("0.5", "-."), "D7": ("0.35", "--"), "D8": ("0.2", (0, (5, 1, 1, 1))), "D9": ("0.0", "-"), "D10": ("0.0", (0, (3, 1)))}
    for ax, fam, nm, let in zip(axs, ("df", "wp"), ("Davey model + fuel", "Waypoints"), "ab"):
        for D, (c, ls) in styles.items():
            a = np.sort(np.abs(draws(fam, D)[:, 2])); ax.plot(a, np.arange(1, len(a) + 1) / len(a), color=c, ls=ls, lw=1.0, label=SHORT[D])
        for y in (0.5, 0.9, 0.95, 0.99): ax.axhline(y, color="0.85", lw=0.5, zorder=0)
        ax.axvline(25, color="0.7", lw=0.6, zorder=0); ax.set_xlim(0, 150); ax.set_xlabel("Distance from the 7th arc (NM)")
        ax.text(0.98, 0.03, f"({let}) {nm}", transform=ax.transAxes, ha="right", fontsize=7)
    axs[0].set_ylabel("Cumulative share of impacts"); axs[0].set_yticks([0, 0.25, 0.5, 0.75, 0.9, 0.99]); axs[0].set_yticklabels(["0", "0.25", "0.5", "0.75", "0.9", "0.99"])
    fig.tight_layout(); fig.subplots_adjust(bottom=0.33); fig._b0 = 0.33; fig._bj = 0.95
    h, l = axs[1].get_legend_handles_labels(); axs[0].legend(h, l, loc="upper left", bbox_to_anchor=(0.0, -0.22), ncol=3, frameon=False, fontsize=6); return fig

# ---------- Figure 3: impact latitude and impact time ----------
def fig_lat_time(jon=False):
    fig, axs = plt.subplots(1, 2, figsize=(WID if jon else 160 * MM, 62 * MM))
    styles = {"D0": ("0.5", "-."), "D7": ("0.35", "--"), "D9": ("0.0", "-"), "D10": ("0.0", (0, (3, 1)))}
    bins = np.arange(-41, -31.99, 0.25)
    for D, (c, ls) in styles.items():
        X = draws("df", D); h, _ = np.histogram(X[:, 0], bins=bins, density=True); axs[0].step(bins[:-1], h, where="post", color=c, ls=ls, lw=1.0, label=SHORT[D])
        t = np.sort(X[:, 3]); axs[1].plot(t, np.arange(1, len(t) + 1) / len(t), color=c, ls=ls, lw=1.0)
    axs[0].set_xlabel("Impact latitude (deg)"); axs[0].set_ylabel("Density (per deg)"); axs[0].text(0.02, 0.96, "(a)", transform=axs[0].transAxes, va="top", fontsize=7)
    axs[1].set_xscale("log"); axs[1].set_xlim(0.3, 60); axs[1].set_xticks([0.5, 1, 2, 5, 10, 20, 50]); axs[1].set_xticklabels(["0.5", "1", "2", "5", "10", "20", "50"])
    axs[1].set_xlabel("Impact time after 00:19:29 UTC (min)"); axs[1].set_ylabel("Cumulative share"); axs[1].text(0.02, 0.96, "(b)", transform=axs[1].transAxes, va="top", fontsize=7)
    axs[0].set_ylim(0, 0.62); axs[0].legend(loc="upper left", bbox_to_anchor=(0.0, 0.93), frameon=False, fontsize=6); fig.tight_layout(); return fig

# ---------- Figure 4: family split under each assumption ----------
def fig_split(jon=False):
    vs = list(dict.fromkeys(V["variant"])); Ds = ["D7", "D9", "D10"]
    NAME = {"headline": "Headline assumptions", "cause prior 0.5": "Log-on cause prior 0.5", "two-stage log-on delay": "Two-stage log-on delay",
            "include lost-control piloted paths": "Include paths that lost control", "00:21:06 entertainment-system factor": "00:21:06 message factor",
            "piloted push-over from cases": "Push-over strength from cases", "onset delay log-uniform 10-300 s": "Onset delay 10-300 s, log-uniform",
            "arrest probability 0.2": "Dive arrest probability 0.2", "arrest probability 0.9": "Dive arrest probability 0.9"}
    TT = {"D7": "(a) Both timings", "D9": "(b) Both frequencies\nas recorded", "D10": "(c) Both frequencies,\nHolland offset"}
    wdt = WID if jon else 160 * MM
    fig, axs = plt.subplots(1, 3, figsize=(wdt, 82 * MM), sharey=True)
    for ax, D in zip(axs, Ds):
        S = V[(V["route family"] == "Davey model + fuel") & (V["code"] == D)].set_index("variant").loc[vs]
        y = np.arange(len(vs))[::-1]; a = S["share: No pilot after fuel exhaustion"].values; b = S["share: Piloted after fuel exhaustion"].values
        ax.barh(y, a, color="0.25", height=0.7, label="No pilot after fuel exhaustion"); ax.barh(y, b, left=a, color="0.75", height=0.7, label="Piloted after fuel exhaustion")
        ax.set_xlim(0, 1); ax.set_xticks([0, 0.5, 1]); ax.set_xlabel("Posterior share"); ax.set_title(TT[D], fontsize=7, loc="left")
    axs[0].set_yticks(np.arange(len(vs))[::-1]); axs[0].set_yticklabels([NAME.get(v, v) for v in vs], fontsize=6)
    h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, loc="upper center", ncol=2, frameon=False, fontsize=6, bbox_to_anchor=(0.6, 1.0))
    fig.tight_layout(rect=(0, 0, 1, 0.92)); return fig

# ---------- Figure 5: impact energy and outcome ----------
def fig_energy(jon=False):
    fig, axs = plt.subplots(1, 2, figsize=(WID if jon else 160 * MM, 62 * MM))
    for D, (c, ls) in {"D0": ("0.5", "-."), "D7": ("0.35", "--"), "D9": ("0.0", "-"), "D10": ("0.0", (0, (3, 1)))}.items():
        X = draws("df", D); e = np.sort(X[:, 6]); axs[0].plot(e, np.arange(1, len(e) + 1) / len(e), color=c, ls=ls, lw=1.0, label=SHORT[D])
    axs[0].axvline(4, color="0.7", lw=0.6); axs[0].set_xlabel("Impact kinetic energy (GJ)"); axs[0].set_ylabel("Cumulative share"); axs[0].set_xlim(0, 11)
    h, l = axs[0].get_legend_handles_labels(); axs[0].legend(h, l, loc="upper left", bbox_to_anchor=(0.0, -0.30) if jon else (0.0, -0.22), ncol=1 if jon else 2, frameon=False, fontsize=6); axs[0].text(0.98, 0.04, "(a)", transform=axs[0].transAxes, ha="right", fontsize=7)
    X = draws("df", "D10"); hi = X[:, 6] >= 4; axs[1].hist([X[hi, 2], X[~hi, 2]], bins=np.arange(-80, 80.1, 4), stacked=True, color=["0.25", "0.75"], label=["Energy >= 4 GJ", "Energy < 4 GJ"])
    axs[1].set_xlabel("Signed distance from the 7th arc (NM)"); axs[1].set_ylabel("Number of draws"); axs[1].legend(frameon=False, fontsize=6, loc="upper left" if jon else "upper center", bbox_to_anchor=(0.0, -0.30) if jon else (0.5, -0.30), ncol=1 if jon else 2); axs[1].set_xlim(-60, 80)
    axs[1].text(0.98, 0.95, "(b)", transform=axs[1].transAxes, ha="right", va="top", fontsize=7); fig.tight_layout(); bb = 0.50 if jon else 0.36; fig.subplots_adjust(bottom=bb); fig._b0 = bb; fig._bj = 0.95; return fig

COMMON_T = ("Final end-of-flight run, 7 Nov 2026 (a1gen_final.py, spec eof-final-spec.json). Core: Run J hand-offs at 00:10:59; Davey model + fuel 16 seeds"
            "; waypoints 24 seeds (planned descent only there). Conditional on engine power at 00:11. No-pilot dives: case-informed kernel (Test A and Test B passed). "
            "Log-on cause prior 0.75 fuel exhaustion; lag Gamma(8, 14.875 s); BFO sd 4.32 Hz; break-up not applied; piloted paths flown by the withdrawn uncontrolled law excluded.")
COMMON_P = ("The paths start from the flight model at 00:11 and continue to the sea. The 00:19 data are used in different ways (see key). The no-pilot dives are drawn from a model built on real airliner dives and Boeing 777 simulator runs.")
FIGS = [("eof-final-impact-maps", fig_maps, "Impact position density for the Davey model with the fuel model, conditional on engine power at 00:11, under four treatments of the 00:19 satellite data: (a) both timing values; (b) both timing values and the first frequency; (c) both timing values and both frequencies as recorded; (d) both frequencies with Holland's start-up offset. The dashed line is the 7th arc at sea level. Darker shading means more impacts.",
         "Darker grey shows where more paths reach the sea. The dashed line is the 7th arc."),
        ("eof-final-arc-distance", fig_arc, "Cumulative distribution of the distance from the 7th arc at impact for (a) the Davey model with the fuel model and (b) the waypoint model, under six treatments of the 00:19 data. Horizontal lines mark 50, 90, 95 and 99 per cent; the vertical line marks 25 NM.",
         "Each line shows how many impacts lie within a given distance of the 7th arc."),
        ("eof-final-latitude-and-time", fig_lat_time, "(a) Impact latitude density and (b) cumulative distribution of the impact time after 00:19:29 UTC, Davey model with the fuel model, under four treatments of the 00:19 data.",
         "Panel (a) shows where along the arc the impacts fall. Panel (b) shows how soon after 00:19:29 they occur."),
        ("eof-final-family-split", fig_split, "Posterior share of the no-pilot and piloted end-of-flight families, Davey model with the fuel model, under each modelling assumption, for three treatments of the 00:19 data. The split depends on the assumptions and is reported as a conditional result.",
         "Each bar shows the share of each family under one set of assumptions. The bars change with the assumptions, so the split is conditional."),
        ("eof-final-energy", fig_energy, "(a) Cumulative distribution of the impact kinetic energy, Davey model with the fuel model, under four treatments of the 00:19 data; the vertical line marks 4 GJ. (b) Signed distance from the 7th arc at impact, split at an impact kinetic energy of 4 GJ, both frequencies with Holland's start-up offset.",
         "Panel (a) shows the impact energy. Panel (b) shows that impacts with energy of 4 GJ or more end close to the arc.")]
if __name__ == "__main__":
    for name, fn, cap, plain in FIGS:
        save(fn(False), name, cap, COMMON_P + " " + plain, COMMON_T, lambda fn=fn: fn(True)); print("saved", name)
