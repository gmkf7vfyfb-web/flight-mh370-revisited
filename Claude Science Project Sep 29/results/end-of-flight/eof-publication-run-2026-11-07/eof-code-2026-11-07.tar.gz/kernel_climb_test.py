import sys; sys.path.insert(0, "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07")
import numpy as np, json, dive_kernel as K, kernel_params as KP
cp = json.load(open("case-prior.json")); r = np.random.default_rng(2); n = 20000
P = KP.draw(n, r, cp, d_on=np.zeros(n)); P["v_pre_fpm"] = np.zeros(n)
lev = np.array([0, 5000, 10000, 20000, 30000, 40000, 50000.0]); prof = np.zeros((n, 7, 2), np.float32)
for h0, g0 in ((12000.0, 8.0), (6000.0, 15.0), (20000.0, 3.0), (-30.0, 0.0)):
    rec, out = K.fly_kernel(np.full(n, -37.0), np.full(n, 89.0), np.full(n, h0), np.full(n, 160.0), np.zeros(n), np.full(n, np.radians(g0)), np.full(n, 175000.0),
        np.zeros(n), np.zeros(n), P["v_pre_fpm"], P["d_on"], P["a8"], P["t15"], P["phi_m"], P["sgn"], P["arrest"], P["h_pull_ft"], P["n_rec"], P["gam_top"], P["phi_arr"],
        np.full((n, 3), -1.0), lev, prof, 0.5, np.full(n, 3000.0))
    o = {k: out[:, i] for i, k in enumerate(K.OUT_NAMES)}
    print(f"start {h0:.0f} ft climb {g0} deg: not reaching sea {1 - o['reached_sea'].mean():.4f}; t q50/q99 {np.quantile(o['t_rel_s'], [0.5, 0.99]).round(1)}; |lat| max {np.abs(o['lat']).max():.2f}")
