    # ====================== FINAL outputs: per-path components (thinned, unbiased) + headline summary ======================
    S1, S2 = res["S1"], res["S2"]; n1 = len(S1["fam"]); j = n1 + idx
    lw = np.r_[np.where(S1["sel"], S1["lw"], -np.inf), S2["lw"] + dlnz]
    fam = np.r_[S1["fam"], S2["fam"]].astype(np.int8); arm = np.r_[np.zeros(n1, np.int8), np.ones(len(S2["fam"]), np.int8)]
    cfgK = np.r_[np.where(S1["cfg"] == 2, 2, np.where(S1["cfg"] == 1, 1, 0)), np.where(S2["cfg"] == 2, 2, np.where(S2["cfg"] == 1, 1, 0))].astype(np.int8)
    flown = np.r_[S1["flown"], S2["flown"]]
    cells = {}
    for k in S1["cellsD"]:
        c = np.r_[S1["cellsD"][k], S2["cellsD"][k]].astype(np.float64); c[j] = D[k]; cells[k] = c
    cz = {}
    for nm in CAUSES:
        c = np.r_[S1["newc"][nm], S2["newc"][nm]].astype(np.float64); c[j] = caus[nm]; cz[nm] = c
    lat = np.r_[S1["lat"], S2["lat"]].astype(np.float64); lon = np.r_[S1["lon"], S2["lon"]].astype(np.float64)
    arc = np.r_[S1["arc"], S2["arc"]].astype(np.float64); tim = np.r_[S1["timp"], S2["timp"]].astype(np.float64)
    I = F["impact"]; lat[j] = I["lat"]; lon[j] = I["lon"]; tim[j] = I["t"]
    btoI = L.bto_v("m0019a", I["lat"], I["lon"], np.zeros(len(idx)))
    btoI2 = L.bto_v("m0019a", I["lat"] + 0.01, I["lon"], np.zeros(len(idx))); btoI3 = L.bto_v("m0019a", I["lat"], I["lon"] + 0.01, np.zeros(len(idx)))
    grad = np.hypot((btoI2 - btoI) / (0.01 * 60), (btoI3 - btoI) / (0.01 * 60 * np.cos(np.radians(I["lat"])))); arc[j] = (btoI - 18400.0) / grad
    orig2 = S2["orig"] if "orig" in S2 else np.arange(len(S2["fam"]))
    def stored(S, name, default, orig=None):
        try:
            v = np.asarray(S["g"](name), np.float64)
        except KeyError:
            v = np.full(len(S["fam"]) if orig is None else int(orig.max()) + 1, default)
        return v if orig is None else v[orig]
    def both(name, default=np.nan): return np.r_[stored(S1, name, default), stored(S2, name, default, orig2)]
    mass = both("mass_kg"); ve = both("velocity_east_mps"); vn = both("velocity_north_mps"); vu = both("velocity_up_mps")
    O = dict(gam=both("flight_path_angle_deg"), bank=both("latent:impact_bank_deg"), hd=both("latent:impact_heading_deg"),
             vs29=both("latent:state_m0019a_vertical_speed_fpm"), vs37=both("latent:state_m0019b_vertical_speed_fpm"),
             n_max=both("latent:struct_max_load_factor_g"), n_min=both("latent:struct_min_load_factor_g"),
             push_drawn=both("latent:pushover_drawn", 0.0), push_nfloor=both("latent:pushover_n_floor_g"),
             ffirst=both("latent:first_flameout_unix_s"), ffinal=both("latent:realised_flameout_unix_s"),
             mach_max=np.full(len(fam), np.nan), eas_max=np.full(len(fam), np.nan), tas=np.sqrt(ve ** 2 + vn ** 2 + vu ** 2), arrested=np.full(len(fam), np.nan))
    ke = 0.5 * mass * (ve ** 2 + vn ** 2 + vu ** 2); vke = 0.5 * mass * vu ** 2
    mA = rows["mass"]; geV = np.hypot(I["ve"], I["vn"]) * KT; vzA = I["vu"] * 0.3048 / 60
    ke[j] = 0.5 * mA * (geV ** 2 + vzA ** 2); vke[j] = 0.5 * mA * vzA ** 2; mass[j] = mA
    for k, v in (("gam", I["gam"]), ("bank", I["bank"]), ("hd", I["hd"]), ("vs29", st29["vu"]), ("vs37", st37["vu"]), ("n_max", I["n_max"]), ("n_min", I["n_min"]),
                 ("mach_max", I["mach_max"]), ("eas_max", I["eas_max"]), ("tas", I["tas"]), ("arrested", I["arrested"])):
        O[k][j] = v
    O["ffinal"][j] = R2["ffinal"][idx]; O["push_drawn"][j] = 0.0
    grp = np.full(len(fam), -1, np.int8); grp[j] = F["grp"]; steep = np.zeros(len(fam), bool); steep[j] = F["steep"]
    PR = {k: np.full(len(fam), np.nan) for k in PRMK}
    for k in PRMK: PR[k][j] = F["params"][k]
    ife = np.where(np.isin(fam, (2, 3)), np.log1p(-0.5 * (tim > T2106)), 0.0); ife[j] = ife_a1
    lr_push = np.zeros(len(fam)); pk = (fam == 2) & (O["push_drawn"] > 0.5) & np.isfinite(O["push_nfloor"])
    if pk.any():
        a_dn = np.clip(1.0 - O["push_nfloor"][pk], 0.2, 2.0)
        lr_push[pk] = KP.logpdf_predictive(CP, "a8_g", "active", a_dn) - np.log(1.0 / 1.8)
    alt = np.isfinite(PR["d_on"]) & (grp > 0)
    lr_don = np.zeros(len(fam)); dd = PR["d_on"][alt]
    lr_don[alt] = np.where((dd >= 10) & (dd <= 300), -np.log(dd * np.log(30.0)), -np.inf) - don_logpdf(dd)
    p_arr0 = KP.ARREST_BETA[0] / sum(KP.ARREST_BETA); ar = (grp >= 0) & np.isfinite(PR["a8"])
    def lr_arrest(p):
        x = np.zeros(len(fam)); a_ = PR["arrest"][ar] > 0.5; x[ar] = np.where(a_, np.log(p / p_arr0), np.log((1 - p) / (1 - p_arr0))); return x
    LR = {"push_cases": lr_push, "onset_loguniform": lr_don, "arrest_0.2": lr_arrest(0.2), "arrest_0.9": lr_arrest(0.9)}
    lostc = np.isin(fam, (2, 3)) & flown
    pmax = np.zeros(len(fam)); summary = {}
    def norm_p(v):
        f = np.isfinite(v)
        if not f.any(): return np.zeros(len(v)), -np.inf
        s_ = v[f].max(); p = np.where(f, np.exp(v - s_), 0.0); Z = p.sum(); return p / Z, float(np.log(Z) + s_)
    for k in cells:
        for nm in CAUSES:
            base_ = lw + cells[k] + (0.0 if k == "D13" else cz[nm])
            for excl in (True, False):
                v = np.where(lostc, -np.inf, base_) if excl else base_
                p, lz = norm_p(v); pmax = np.maximum(pmax, p)
                if nm == "g75" and excl:
                    cell = dict(lnZ=lz, ess=float(1 / max(np.sum(p * p), 1e-300)))
                    for fname, code in (("A1", 1), ("A2", 2), ("B", 3)):
                        kk = fam == code; sh = float(p[kk].sum()); cell[fname] = dict(share=sh, ess=float(sh ** 2 / max(np.sum(p[kk] ** 2), 1e-300)))
                    kk = p > 0; o_ = np.argsort(lat[kk]); cs = np.cumsum(p[kk][o_]); cell["lat_q05_q50_q95"] = [float(lat[kk][o_][min(np.searchsorted(cs, q), len(o_) - 1)]) for q in (0.05, 0.5, 0.95)]
                    cell["within25"] = float(p[np.abs(arc) <= 25].sum()); summary[k] = cell
            if nm == "g75":
                for lrn, lrv in LR.items():
                    p, _ = norm_p(np.where(lostc, -np.inf, base_) + lrv); pmax = np.maximum(pmax, p)
        p, _ = norm_p(np.where(lostc, -np.inf, lw + cells[k] + (0.0 if k == "D13" else cz["g75"])) + ife); pmax = np.maximum(pmax, p)
    target = float(os.environ.get("A1GEN_KEEP", "300000")); lo_e, hi_e = -60.0, 0.0
    for _ in range(80):
        me = 0.5 * (lo_e + hi_e); cnt = np.sum(np.minimum(1.0, pmax / np.exp(me)))
        lo_e, hi_e = (me, hi_e) if cnt > target else (lo_e, me)
    eps = np.exp(0.5 * (lo_e + hi_e)); pk_ = np.minimum(1.0, pmax / eps)
    keep = (pmax > 0) & (rng.random(len(fam)) < pk_)
    lw_t = lw + np.log(1.0 / np.maximum(pk_, 1e-300)); K_ = np.flatnonzero(keep)
    comp = dict(lw=lw_t[K_], fam=fam[K_], arm=arm[K_], cfg=cfgK[K_], grp=grp[K_], lostc=lostc[K_], steep=steep[K_], ife=ife[K_].astype(np.float32),
                lat=lat[K_].astype(np.float32), lon=lon[K_].astype(np.float32), arc=arc[K_].astype(np.float32), t_imp=(tim[K_] - T29).astype(np.float32),
                ke=ke[K_].astype(np.float32), vke=vke[K_].astype(np.float32), mass=mass[K_].astype(np.float32))
    comp.update({"o_" + k: v[K_].astype(np.float32) for k, v in O.items()}); comp.update({"p_" + k: v[K_].astype(np.float32) for k, v in PR.items()})
    comp.update({"D_" + k: v[K_].astype(np.float32) for k, v in cells.items()}); comp.update({"C_" + k: v[K_].astype(np.float32) for k, v in cz.items()})
    comp.update({"R_" + k: v[K_].astype(np.float32) for k, v in LR.items()})
    comp["o_ffirst"] = (O["ffirst"][K_] - T29).astype(np.float32); comp["o_ffinal"] = (O["ffinal"][K_] - T29).astype(np.float32)
    np.savez_compressed(outp + ".npz", **comp)
    out = dict(seed=seed, T0=T0_, T1=T1_, dlnZ_filter=dlnz, n_rows=int(len(fam)), n_kept=int(len(K_)), eps=float(eps), n_a1=int(len(idx)),
               is_info=(isinfo if 'isinfo' in dir() else {}), cause_fe=CAUSE_FE, headline=summary,
               kernel_q={k: [float(x) for x in np.nanquantile(F["params"][k], [0.05, 0.5, 0.95])] for k in PRMK if np.isfinite(F["params"][k]).any()})
    json.dump(out, open(outp + ".json", "w"), indent=1)
    print(json.dumps({k: out[k] for k in ("seed", "n_rows", "n_kept", "n_a1")}))
    for k, c in summary.items():
        print(k, "lnZ %.3f A1/A2/B %.3f/%.3f/%.3f essA1 %.0f lat50 %.2f w25 %.2f" % (c["lnZ"], c["A1"]["share"], c["A2"]["share"], c["B"]["share"], c["A1"]["ess"], c["lat_q05_q50_q95"][1], c["within25"]))
if __name__ == "__main__":
    main()
