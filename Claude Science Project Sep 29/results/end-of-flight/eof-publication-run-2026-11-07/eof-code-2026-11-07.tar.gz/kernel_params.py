"""Parameter draws for the case-informed dive kernel (no effective crew input). Evidence ranges (Boeing 777 alternate-power
simulations 3, 4, 6, 10; real no-input cases) are documented in eof-final-spec.json."""
import json, numpy as np
FT = 0.3048
BOEING = dict(v_pre_fpm=(1165.0, 1465.0), h_bot_ft=(3751.0, 18895.0), n_rec=(1.62, 2.55), gam_top_deg=(1.84, 57.65), phi_arr_deg=(37.7, 51.8))
PHI_M_DEG = (35.0, 100.0)          # bank at the end of the build-up: Boeing 39-44 deg at 15,000 ft/min; Adam Air 574 90-100 deg; lower bound set 4 deg below the Boeing minimum as a margin (own choice)
ARREST_BETA = (1 + 4, 1 + 1)       # Boeing 4 of 4 arrested the first roll-off without input; Adam Air 574 (no input, cruise) 0 of 1
def predictive(cp, name, cls, n, rng):
    q = cp["quantities"][name]["draws"]; mu = np.asarray(q["mu_" + cls]); ta = np.asarray(q["tau"])
    k = rng.integers(0, len(mu), n); return np.exp(mu[k] + ta[k] * rng.standard_normal(n))
def logpdf_predictive(cp, name, cls, x):
    q = cp["quantities"][name]["draws"]; mu = np.asarray(q["mu_" + cls]); ta = np.asarray(q["tau"])
    lx = np.log(x)[:, None]; v = -0.5 * ((lx - mu[None]) / ta[None]) ** 2 - np.log(ta[None] * np.sqrt(2 * np.pi))
    m = v.max(1, keepdims=True); return (m[:, 0] + np.log(np.mean(np.exp(v - m), 1))) - np.log(x)
def draw(n, rng, cp, boeing=BOEING, arrest_beta=ARREST_BETA, d_on=None, t15=None, v_pre=None, a8=None):
    """Kernel parameters. a8 and T15 are independent draws from the case predictive, truncated to feasible pairs (15,000 ft/min
    reachable within T15 at a8). When T15 is given (importance sampling), only a8 is redrawn for infeasible pairs; the truncation
    then acts on a8 given T15, which the caller's weight must account for (see a8_feasible_logprob)."""
    v_pre = rng.uniform(*boeing["v_pre_fpm"], n) if v_pre is None else np.array(v_pre, float)
    if d_on is None: d_on = predictive(cp, "onset_delay_s", "noinput", n, rng)
    given = t15 is not None
    dv = (15000.0 - v_pre) * FT / 60.0
    if given:                                              # a8 | T15 from the truncated predictive by inverse CDF on a fine log grid
        t15 = np.array(t15, float)
        a8 = a8_truncated(cp, dv / (9.80665 * 0.98 * t15), rng) if a8 is None else np.array(a8, float)
    else:
        a8 = predictive(cp, "a8_g", "noinput", n, rng); t15 = predictive(cp, "t15_s", "noinput", n, rng)
        bad = dv / (a8 * 9.80665) >= t15 * 0.98
        while bad.any():                                   # joint truncation (feasible share about 0.96): redraw both
            a8[bad] = predictive(cp, "a8_g", "noinput", bad.sum(), rng); t15[bad] = predictive(cp, "t15_s", "noinput", bad.sum(), rng)
            bad = dv / (a8 * 9.80665) >= t15 * 0.98
    p = rng.beta(*arrest_beta, n)
    return dict(v_pre_fpm=v_pre, d_on=d_on, a8=a8, t15=t15, phi_m=np.radians(rng.uniform(*PHI_M_DEG, n)), sgn=rng.choice([-1.0, 1.0], n),
                arrest=rng.random(n) < p, h_pull_ft=rng.uniform(*boeing["h_bot_ft"], n), n_rec=rng.uniform(*boeing["n_rec"], n),
                gam_top=np.radians(rng.uniform(*boeing["gam_top_deg"], n)), phi_arr=np.radians(rng.uniform(*boeing["phi_arr_deg"], n)))

from scipy.stats import norm as _norm
_CDF = {}
def _a8_cdf(cp):
    if id(cp) not in _CDF:
        lg = np.linspace(np.log(1e-3), np.log(50.0), 20001); lp = logpdf_predictive(cp, "a8_g", "noinput", np.exp(lg)) + lg   # density of log a8
        pdf = np.exp(lp - lp.max()); cdf = np.concatenate([[0.0], np.cumsum(0.5 * (pdf[1:] + pdf[:-1]) * np.diff(lg))]); cdf /= cdf[-1]
        _CDF[id(cp)] = (lg, cdf)
    return _CDF[id(cp)]
def a8_truncated(cp, x, rng):
    """Draw a8 from the no-input predictive truncated to a8 > x (inverse CDF on the grid)."""
    lg, cdf = _a8_cdf(cp); Fx = np.interp(np.log(np.maximum(x, 1e-12)), lg, cdf, left=0.0, right=1.0)
    u = Fx + (1.0 - Fx) * rng.random(len(x)); u = np.minimum(u, 1.0 - 1e-15)
    return np.maximum(np.exp(np.interp(u, cdf, lg)), x * 1.0001)
def feasible_logprob(cp, t15, v_pre, nsub=None):
    """log P(a8 > (15,000 - v_pre) ft/min / (g 0.98 T15)) under the no-input a8 predictive (same grid as the sampler)."""
    lg, cdf = _a8_cdf(cp); x = (15000.0 - np.asarray(v_pre)) * FT / 60.0 / (9.80665 * 0.98 * np.asarray(t15))
    Fx = np.interp(np.log(np.maximum(x, 1e-12)), lg, cdf, left=0.0, right=1.0)
    with np.errstate(divide="ignore"): return np.log(np.maximum(1.0 - Fx, 0.0))
def log_ZF(cp, rng, n=2000000, boeing=BOEING):
    """log of the prior probability that an independent (a8, T15, v_pre) draw is feasible (normaliser of the truncated prior)."""
    vp = rng.uniform(*boeing["v_pre_fpm"], n); a8 = predictive(cp, "a8_g", "noinput", n, rng); t15 = predictive(cp, "t15_s", "noinput", n, rng)
    return float(np.log(np.mean((15000.0 - vp) * FT / 60.0 / (a8 * 9.80665) < t15 * 0.98)))

_GRID = {}
def logpdf_grid(cp, name, cls, x):
    """Fast predictive log density by interpolation on a log grid (same values as logpdf_predictive)."""
    key = (id(cp), name, cls)
    if key not in _GRID:
        lg = np.linspace(np.log(1e-3), np.log(1e4), 8000); _GRID[key] = (lg, logpdf_predictive(cp, name, cls, np.exp(lg)))
    lg, lp = _GRID[key]; return np.interp(np.log(np.maximum(np.asarray(x, float), 1e-12)), lg, lp, left=-np.inf, right=-np.inf)

from scipy.stats import norm as _nm
A8_MIX = ((0.4, None, None), (0.3, np.log(0.85), 0.2), (0.3, np.log(1.3), 0.2))   # (weight, log-median, log-sd); None = the truncated prior
def a8_mixture(cp, x, rng):
    """Draw a8 > x from q = 0.4 p_trunc + 0.3 LN_trunc(0.85 g, 0.2) + 0.3 LN_trunc(1.3 g, 0.2); return a8 and log p_trunc(a8) - log q(a8)."""
    n = len(x); comp = rng.choice(len(A8_MIX), size=n, p=[c[0] for c in A8_MIX]); a = np.empty(n)
    lx = np.log(np.maximum(x, 1e-12))
    for c, (w, mu, sd) in enumerate(A8_MIX):
        m = comp == c
        if not m.any(): continue
        if mu is None: a[m] = a8_truncated(cp, x[m], rng)
        else:
            lo = _nm.cdf((lx[m] - mu) / sd); u = lo + (1 - lo) * rng.random(m.sum()); u = np.clip(u, 1e-15, 1 - 1e-15)
            a[m] = np.maximum(np.exp(mu + sd * _nm.ppf(u)), x[m] * 1.0001)
    la = np.log(a); lpF = feasible_logprob_x(cp, x)
    lp_tr = logpdf_grid(cp, "a8_g", "noinput", a) - lpF                         # truncated prior density
    terms = []
    for w, mu, sd in A8_MIX:
        if mu is None: terms.append(np.log(w) + lp_tr)
        else:
            sf = np.maximum(_nm.sf((lx - mu) / sd), 1e-300)
            terms.append(np.log(w) - 0.5 * ((la - mu) / sd) ** 2 - np.log(a * sd * np.sqrt(2 * np.pi)) - np.log(sf))
    lq = np.logaddexp.reduce(np.vstack(terms), axis=0)
    return a, lp_tr - lq
def feasible_logprob_x(cp, x):
    lg, cdf = _a8_cdf(cp); Fx = np.interp(np.log(np.maximum(x, 1e-12)), lg, cdf, left=0.0, right=1.0)
    with np.errstate(divide="ignore"): return np.log(np.maximum(1.0 - Fx, 0.0))
