"""Fuel-model + data-to-00:11 prior on the power-loss time (alternate: first flame-out; normal: final flame-out), stored 00:11-arm rows."""
import sys, json, numpy as np
fam_name, seed = sys.argv[1], int(sys.argv[2])
E = "/Users/pete/Downloads/mh370-exchange"
if fam_name == "wp":
    O = E + "/end-of-flight/run-j-joined-v2"; SD = E + "/core/run-j/run-j-waypoints/bto-bfo"
    r0011 = O + "/J0011"; h2241 = f"{SD}/seed-{seed}/handoff-m2241/handoff.toml.gz"; h0011 = f"{SD}/seed-{seed}/handoff-m0011/handoff.toml.gz"
else:
    SD = E + "/core/run-j/run-j-repro-radar/bto-bfo"; r0011 = E + "/end-of-flight/run-j/run-j-repro-radar"; h0011 = h2241 = f"{SD}/seed-{seed}/handoff-m0011/handoff.toml.gz"
sys.argv = ["a1gen_d5.py", r0011, r0011, h2241, h0011, "x", str(seed)]
sys.path.insert(0, "."); import a1gen_d5 as A
J = A.J
if fam_name == "df":
    src = open("a1gen_compact_d5.py").read().split("prod, h0011, outp, seed = sys.argv[1:5]")[0]; g_ = {}; exec(compile(src, "compact", "exec"), g_); J.load = g_["load_compact"]; J.Prior = g_["_NeutralPrior"]
T0_, T1_ = J.stop_unix(h2241), J.stop_unix(h0011)
m2, g2, _ = J.load(r0011, seed); p2 = J.Prior(m2["config"]["hypotheses"]["end-of-flight"]["onset"])
tau2 = g2("latent:onset_unix_s"); P2 = tau2 + g2("latent:predicted_endurance_at_onset_s"); mech2 = g2("latent:onset_mechanism"); tau2 = np.where(mech2 == 2, P2, tau2)
with np.errstate(invalid="ignore"): lr = p2.log_density(mech2, tau2, P2, T0_) - p2.log_density(mech2, tau2, P2, T1_)
s2 = np.isfinite(lr) & (P2 >= T1_) & (mech2 == 2)
lw = np.log(g2("weight")) + np.where(s2, lr, -np.inf)
cfg = g2("latent:ap_loss_config"); ff = g2("latent:first_flameout_unix_s"); fl = g2("latent:realised_flameout_unix_s")
out = {"shape": A.SHAPE, "scale": A.SCALE, "T11": A.T11, "T29": A.T29}
edges = np.arange(0, 1201, 10.0)
for c, tP in ((1, fl), (2, np.where(np.isfinite(ff), ff, fl))):
    lag = A.T29 - tP; ok = (cfg == c) & np.isfinite(lw) & np.isfinite(lag)
    w = np.exp(lw[ok] - lw[ok].max()); L = lag[ok]
    h, _ = np.histogram(L, bins=edges, weights=w); tot = w.sum()
    out[f"cfg{c}"] = dict(hist=(h / tot).tolist(), share_in_window=float(w[(L > 0) & (L <= A.T29 - A.T11)].sum() / tot), share_after_0019=float(w[L <= 0].sum() / tot), n=int(ok.sum()))
out["edges"] = edges.tolist()
json.dump(out, open(f"q2/fuel-tp-{fam_name}-s{seed}.json", "w")); print(fam_name, seed, {k: (v["share_in_window"], v["share_after_0019"], v["n"]) for k, v in out.items() if k.startswith("cfg")}, out["shape"], out["scale"])
