"""Pre-registered Test B (prereg/prereg-case-prior-and-kernel-2026-11-07.md): dive kernel against each Boeing 777 alternate-power
simulation, held out from the case prior and from the Boeing evidence ranges."""
import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07")
import case_prior, kernel_params as KP, dive_kernel as K, eof_fast_lib as L
EV = pd.read_csv("/Users/pete/.claude-science/orgs/9db41e8b-db54-4736-82b9-d77e2a9ad222/artifacts/proj_9cc1a5a85f63/0307aa11-9a97-4987-9cb5-b22f4b21e977/v23f70536_boeing-end-of-flight-runs-table.csv").set_index("run")
MEAS = {3: dict(v_pre=1185, h_bot=3751, n_rec=2.55, gtop=57.65, parr=37.7), 4: dict(v_pre=1465, h_bot=13979, n_rec=1.94, gtop=10.95, parr=51.8),
        6: dict(v_pre=1300, h_bot=18895, n_rec=1.62, gtop=1.84, parr=39.9), 10: dict(v_pre=1165, h_bot=14217, n_rec=1.95, gtop=41.10, parr=51.6)}
rng = np.random.default_rng(7); N = 4000; rows = []
lev = np.arange(0, 50001, 1000.0); sp = (23.5 + 0.79 * np.minimum(lev, 25000.0) / 1000.0) * 0.514444
prof1 = np.stack([sp * np.sin(np.radians(66.0)), sp * np.cos(np.radians(66.0))], -1).astype(np.float32)
for r in (3, 4, 6, 10):
    cp = case_prior.main(out=f"prereg/case-prior-without-sim{r}.json", exclude=f"Boeing 777 simulation {r}")
    others = [MEAS[k] for k in MEAS if k != r]
    bo = dict(v_pre_fpm=(min(o["v_pre"] for o in others), max(o["v_pre"] for o in others)), h_bot_ft=(min(o["h_bot"] for o in others), max(o["h_bot"] for o in others)),
              n_rec=(min(o["n_rec"] for o in others), max(o["n_rec"] for o in others)), gam_top_deg=(min(o["gtop"] for o in others), max(o["gtop"] for o in others)),
              phi_arr_deg=(min(o["parr"] for o in others), max(o["parr"] for o in others)))
    P = KP.draw(N, rng, cp, boeing=bo, arrest_beta=(1 + 3, 1 + 1))
    R = L.run_raw(f"Case {r:02d}.csv"); e = EV.loc[r]; tau0 = float(e["first flame-out s"]); t = R["t"]
    h0 = float(np.interp(tau0, t, R["h"])); ve0 = np.interp(tau0, t, R["ve"]); vn0 = np.interp(tau0, t, R["vn"])
    sp0 = (23.5 + 0.79 * min(h0, 25000) / 1000); vae = ve0 - sp0 * np.sin(np.radians(66)); van = vn0 - sp0 * np.cos(np.radians(66))
    V0 = np.hypot(vae, van) * 0.514444; psi0 = np.arctan2(vae, van)
    t2 = str(e["second flame-out s"]); left_runs = r in (4, 10)
    thr_end = 1e6 if left_runs else float(t2.replace("≈", "").split()[0]) - tau0
    rec, out = K.fly_kernel(np.full(N, -37.0), np.full(N, 89.0), np.full(N, h0), np.full(N, V0), np.full(N, psi0), np.full(N, np.nan), np.full(N, 174000.0),
                            np.full(N, 55000.0), np.full(N, thr_end), P["v_pre_fpm"], P["d_on"], P["a8"], P["t15"], P["phi_m"], P["sgn"],
                            P["arrest"], P["h_pull_ft"], P["n_rec"], P["gam_top"], P["phi_arr"], np.full((N, 3), -1.0), lev, np.repeat(prof1[None], N, 0), 0.5, np.full(N, 3000.0))
    o = {k: out[:, i] for i, k in enumerate(K.OUT_NAMES)}
    dist = np.hypot((o["lat"] + 37.0) * 60.0, (o["lon"] - 89.0) * 60.0 * np.cos(np.radians(37.0)))
    desc = -R["vu"]; k15 = np.flatnonzero((t > tau0) & (desc >= 15000)); t15obs = t[k15[0]] - tau0
    after = t > t[k15[0]]; ka = np.flatnonzero(after & (desc < 1000)); tarr = t[ka[0]] if len(ka) else t[-1]
    pk_obs = desc[(t >= t[k15[0]]) & (t <= tarr)].max()
    h_end = R["h"][-1]; d_end = max(np.mean(desc[-5:]), 1000.0); t_sea_obs = t[-1] - tau0 + h_end / (d_end / 60.0)
    dist_obs = float(e["ground distance loss to end NM"])
    kt15 = o["t15_after_onset_s"] + P["d_on"]
    for name, sim, obs in (("time first flame-out to 15,000 ft/min (s)", kt15, t15obs), ("peak descent before arrest or sea (ft/min)", o["peak_descent_before_arrest_fpm"], pk_obs),
                           ("time first flame-out to the sea (s)", o["t_rel_s"], t_sea_obs), ("ground distance loss to end (NM)", dist, dist_obs)):
        f = np.isfinite(sim); pit = float(np.mean(sim[f] < obs))
        rows.append(dict(simulation=r, target=name, observed=round(float(obs), 1), kernel_q05=round(float(np.quantile(sim[f], 0.05)), 1),
                         kernel_q50=round(float(np.quantile(sim[f], 0.5)), 1), kernel_q95=round(float(np.quantile(sim[f], 0.95)), 1), pit=round(pit, 3), inside_90=bool(0.05 <= pit <= 0.95)))
T = pd.DataFrame(rows); T.to_csv("prereg/test-b-kernel-vs-boeing.csv", index=False)
print(T.to_string(index=False)); n_in = int(T.inside_90.sum()); print("inside central 90%:", n_in, "of", len(T), "PASS" if n_in >= 13 else "FAIL")
