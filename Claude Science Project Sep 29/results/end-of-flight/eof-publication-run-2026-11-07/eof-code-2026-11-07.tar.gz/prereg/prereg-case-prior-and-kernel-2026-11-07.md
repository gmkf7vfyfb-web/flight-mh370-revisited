# Pre-registration: case-informed dive prior and dive kernel (written 7 Nov 2026, before any test was run)

## Test A: leave-one-case-out predictive coverage of the hierarchical case prior
Quantities (log scale, lognormal hierarchical model, two classes by crew input during the build-up):
1. a8 = largest 8-s mean downward acceleration during the build-up (g). 15 values: 10 with active crew input, Adam Air 574 and Boeing 777 simulations 3, 4, 6, 10 with no effective input.
2. T15 = time from descent onset to 15,000 ft/min (s). 10 values.
3. d_on = delay from power loss (or autopilot loss) to descent onset, no-input class only (s). 6 values.
For each value: refit without it, compute the probability integral transform (PIT) of the left-out value under the class predictive (including its own measurement error).
PASS rule (fixed now): for each quantity, at most 2 PIT values outside [0.025, 0.975]. The result is reported whether it passes or fails.

## Test B: dive kernel against the four Boeing 777 alternate-power simulations (held out one at a time)
For simulation k: refit the case prior without simulation k; start the kernel from that simulation's state at first flame-out (altitude, true airspeed, track; left engine running for simulations 4 and 10, stopped for 3 and 6); draw 4,000 paths.
Targets per simulation (4): time from first flame-out to 15,000 ft/min; peak descent rate before the first arrest or the sea; time from first flame-out to the sea; ground distance from the flame-out point to the end of record.
PASS rule (fixed now): at least 13 of the 16 PIT values inside [0.05, 0.95]. The result is reported whether it passes or fails. A failure does not stop the production run; it is declared in every product.
