"""Shared code for the fast-route end-of-flight estimator (3 Nov 2026).
Project BTO/BFO model port (matches engine/crates/satcom to 1e-9 on test points), Boeing-run loader and splicer,
side-mounted HGA gain model (Large 2019 Fig. 19), and constants. Data paths are absolute on this machine."""

import io, zipfile, numpy as np, pandas as pd

from scipy.ndimage import uniform_filter1d as uf

ENGINE_DATA = '/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07/repo/Claude Science Project Sep 29/engine/data'

BOEING_ZIP = '/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07/repo/ISO Sept 28 Status/inputs/end-of-flight/2018-08-19-eof-sims.zip'

C = 299792.458
FUP = 1646652500.0
FDN = 3615152500.0
KMFT = 0.0003048
KMSKT = 0.0005144444444444444
a_ = 6378.137
e2 = 0.0066943799901413165

PERTH = np.array([-2368.8, 4881.1, -3342.0])

NOM = np.array([18334.71723222356, 38439.534054309945, 0.0])

eph = pd.read_csv(ENGINE_DATA + '/satellite-ephemeris-inmarsat.csv').set_index('epoch_id')

_o = pd.read_csv(ENGINE_DATA + '/satcom-observations.csv'); obs = _o.set_index(_o.columns[0])

def lla(lat,lon,h):
    la,lo=np.radians(lat),np.radians(lon); N=a_/np.sqrt(1-e2*np.sin(la)**2)
    return np.array([(N+h)*np.cos(la)*np.cos(lo),(N+h)*np.cos(la)*np.sin(lo),(N*(1-e2)+h)*np.sin(la)])


def basis(lat,lon):
    la,lo=np.radians(lat),np.radians(lon)
    up=np.array([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]); east=np.array([-np.sin(lo),np.cos(lo),0.]); north=np.cross(up,east)
    return north,east,up


def ep(i): r=eph.loc[i]; return np.array([r.x_km,r.y_km,r.z_km]),np.array([r.vx_km_s,r.vy_km_s,r.vz_km_s]),obs.loc[i,"satellite_afc_hz"]


EP = {i: ep(i) for i in ['m0011','m0019a','m0019b']}

def sat_ned(i,lat,lon,h_ft=35000):
    s,_,_=ep(i); p=lla(lat,lon,h_ft*KMFT); n,e,u=basis(lat,lon); d=s-p; d/=np.linalg.norm(d)
    return np.array([d@n,d@e,-(d@u)])


lat19, lon19, lat11, lon11 = -37.2, 89.64043621961909, np.float64(-36.104185832099084), 89.96598808211215

S19 = sat_ned('m0019a', lat19, lon19); S11 = sat_ned('m0011', lat11, lon11)

TH = np.array([0, 12, 24, 33, 41, 49, 58, 70, 80, 90, 100]); GG = np.array([14.5, 14.2, 14.0, 13.5, 13.0, 12.3, 11.5, 10.6, 7.45, 4.3, -5.0])

NS = np.array([0, np.cos(np.pi/4), -np.sin(np.pi/4)]); NP = np.array([0, -np.cos(np.pi/4), -np.sin(np.pi/4)])

def bfo_nb(i,lat,lon,alt_ft,trk,gs_kt,vup_fpm):
    S,V,afc=ep(i); n,e,u=basis(lat,lon)
    hor=(n*np.cos(np.radians(trk))+e*np.sin(np.radians(trk)))*gs_kt*KMSKT; vel=hor+u*vup_fpm*KMFT/60
    ac=lla(lat,lon,alt_ft*KMFT); ts=(S-ac)/np.linalg.norm(S-ac)
    upl=-FUP/C*np.dot(V-vel,ts); g=(S-PERTH)/np.linalg.norm(S-PERTH); dn=-FDN/C*np.dot(V,g)
    fn=(lla(lat,lon,0)-NOM); fn/=np.linalg.norm(fn); comp=FUP/C*np.dot(hor,fn)
    return upl+dn+comp+afc


def bto(i,lat,lon,alt):
    S,_,_=ep(i); ac=lla(lat,lon,alt*KMFT); return 2*(np.linalg.norm(S-ac)+np.linalg.norm(S-PERTH))/C*1e6-(499962.0-4283.0)


def arc_lon(i,lat,alt,b):
    w,ea=65.0,150.0
    for _ in range(60):
        m=0.5*(w+ea); (w,ea)=(m,ea) if bto(i,lat,m,alt)<b else (w,m)
    return 0.5*(w+ea)


def lla_v(lat,lon,h):
    la,lo=np.radians(lat),np.radians(lon); N=a_/np.sqrt(1-e2*np.sin(la)**2)
    return np.stack([(N+h)*np.cos(la)*np.cos(lo),(N+h)*np.cos(la)*np.sin(lo),(N*(1-e2)+h)*np.sin(la)],-1)


def basis_v(lat,lon):
    la,lo=np.radians(lat),np.radians(lon)
    up=np.stack([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)],-1); east=np.stack([-np.sin(lo),np.cos(lo),0*lo],-1); north=np.cross(up,east)
    return north,east,up


def bto_v(i,lat,lon,alt_ft):
    S=EP[i][0]; ac=lla_v(lat,lon,alt_ft*KMFT)
    return 2*(np.linalg.norm(S-ac,axis=-1)+np.linalg.norm(S-PERTH))/C*1e6-(499962.0-4283.0)


def bfo_v(i,lat,lon,alt_ft,vn_kt,ve_kt,vup_fpm):
    S,V,afc=EP[i]; n,e,u=basis_v(lat,lon)
    hor=(n*vn_kt[...,None]+e*ve_kt[...,None])*KMSKT; vel=hor+u*(vup_fpm*KMFT/60)[...,None]
    ac=lla_v(lat,lon,alt_ft*KMFT); d=S-ac; ts=d/np.linalg.norm(d,axis=-1,keepdims=True)
    upl=-FUP/C*np.sum((V-vel)*ts,-1); g=(S-PERTH)/np.linalg.norm(S-PERTH); dn=-FDN/C*np.dot(V,g)
    fn=lla_v(lat,lon,0*lat)-NOM; fn/=np.linalg.norm(fn,axis=-1,keepdims=True); comp=FUP/C*np.sum(hor*fn,-1)
    return upl+dn+comp+afc


def G(th): return np.interp(th,TH,GG)


def C_nb(psi,th,ph):
    p,t,f=np.radians([psi,th,ph]); cp,sp,ct,st,cf,sf=np.cos(p),np.sin(p),np.cos(t),np.sin(t),np.cos(f),np.sin(f)
    return np.array([[ct*cp,ct*sp,-st],[sf*st*cp-cf*sp,sf*st*sp+cf*cp,sf*ct],[cf*st*cp+sf*sp,cf*st*sp-sf*cp,cf*ct]])


def gain(psi,th,ph,S=S19):
    b=C_nb(psi,th,ph)@S
    a=[np.degrees(np.arccos(np.clip(b@N,-1,1))) for N in (NS,NP)]
    return max(G(a[0]),G(a[1])), int(np.argmin(a))  # 0 starboard,1 port


def run_raw(n):
    df=pd.read_csv(io.BytesIO(z.read(n))).dropna(); df.columns=["t","x","y","h"]
    t=df.t.values.astype(float); x=uf(df.x.values,7,mode="nearest"); y=uf(df.y.values,7,mode="nearest"); h=df.h.values.astype(float)
    ve=np.gradient(x,t)*3600; vn=np.gradient(y,t)*3600; hs=uf(h,3,mode="nearest"); vu=np.gradient(hs,t)*60
    return dict(t=t,e=x,n=y,h=h,ve=ve,vn=vn,vu=vu)


def splice(R,tu,t1=None,g=None,s_min=-1500):
    """real-time axis s (s rel. power loss) -> e,n,h,ve,vn,vu. Normal with g: cruise..., one-engine run[t1,t1+g], then run[tu:]"""
    t=R["t"]; s=np.arange(s_min,int(t[-1]-tu)-6)
    out={k:np.empty(len(s)) for k in ["e","n","h","ve","vn","vu"]}
    def seg_idx(tt): return np.clip(np.round(tt).astype(int),0,len(t)-1)
    if g is None:
        tau=s+tu; inrun=tau>=t[0]; i=seg_idx(tau)
        for k in ["h","ve","vn","vu"]: out[k]=np.where(inrun,R[k][i],R[k][0] if k!="vu" else 0.0)
        out["h"]=np.where(inrun,R["h"][i],R["h"][0])
        e0,n0=R["e"][0],R["n"][0]; dtb=np.minimum(tau-t[0],0)
        out["e"]=np.where(inrun,R["e"][i],e0+R["ve"][0]/3600*dtb); out["n"]=np.where(inrun,R["n"][i],n0+R["vn"][0]/3600*dtb)
        return s,out
    # normal with gap g (s): segment A cruise s< -g ; B one-engine s in [-g,0): tau=t1+g+s ; C s>=0: tau=tu+s
    A=s<-g; Bm=(s>=-g)&(s<0); Cm=s>=0
    iB=seg_idx(t1+g+s); iC=seg_idx(tu+s); i1=seg_idx(np.array([t1]))[0]
    for k in ["h","ve","vn","vu"]:
        out[k]=np.where(Cm,R[k][iC],np.where(Bm,R[k][iB],R[k][i1] if k!="vu" else 0.0))
    # positions: continuous chaining
    eB=R["e"][iB]-R["e"][i1]; nB=R["n"][iB]-R["n"][i1]
    iBend=seg_idx(np.array([t1+g]))[0]; eBend=R["e"][iBend]-R["e"][i1]; nBend=R["n"][iBend]-R["n"][i1]
    itu=seg_idx(np.array([tu]))[0]; eC=R["e"][iC]-R["e"][itu]+eBend; nC=R["n"][iC]-R["n"][itu]+nBend
    dtA=s+g; eA=R["ve"][i1]/3600*dtA; nA=R["vn"][i1]/3600*dtA
    out["e"]=np.where(Cm,eC,np.where(Bm,eB,eA)); out["n"]=np.where(Cm,nC,np.where(Bm,nB,nA))
    return s,out


def run_att(n):
    df=pd.read_csv(io.BytesIO(z.read(n))).dropna(); df.columns=["t","x","y","h"]
    t=df.t.values; x=uf(df.x.values*1852,7); y=uf(df.y.values*1852,7); h=uf(df.h.values*0.3048,7)
    vx,vy,vz=np.gradient(x,t),np.gradient(y,t),np.gradient(h,t)
    gs=np.hypot(vx,vy); psi=np.degrees(np.unwrap(np.arctan2(vx,vy)))
    om=uf(np.gradient(np.radians(psi),t),9); V=np.sqrt(gs**2+vz**2)
    bank=np.degrees(np.arctan(V*om/9.81)); gam=np.degrees(np.arctan2(vz,gs))
    return pd.DataFrame(dict(t=t,psi=psi%360,pitch=gam+3,bank=np.clip(bank,-85,85),fpm=vz/0.3048*60,alt=df.h.values))


def att_full(n,aoa=3.0):
    df=pd.read_csv(io.BytesIO(z.read(n))).dropna(); df.columns=["t","x","y","h"]
    a=run_att(n); a["pitch"]=a.pitch-3+aoa
    hs=uf(df.h.values.astype(float),3,mode="nearest"); a["desc"]=-np.gradient(hs,df.t.values)*60
    return a


z = zipfile.ZipFile(BOEING_ZIP)

G0 = gain(185, 2.5, 0, S11)[0]   # level cruise reference at 00:10:59