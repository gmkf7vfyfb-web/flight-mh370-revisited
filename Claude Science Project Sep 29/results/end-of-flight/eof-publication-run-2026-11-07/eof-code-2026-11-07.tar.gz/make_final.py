src = open("a1gen_d5.py").read()
def rep(old, new, count=1):
    global src
    n = src.count(old)
    assert n == count, (n, old[:80])
    src = src.replace(old, new)
rep('"""Fast-route end-of-flight estimator, per seed (3 Nov 2026, Pete-approved overnight plan, items 1, 2, 5).',
    '"""FINAL end-of-flight estimator, per seed (7 Nov 2026; derived from the fast-route a1gen_d5.py of 6 Nov).\n'
    'Changes: case-informed dive kernel (dive_kernel.py) for no-pilot alternate-configuration descents and late steep endings of\n'
    'normal-configuration glides; break-up factor removed; log-on cause prior from eof-final-spec.json; corrected two-stage delay;\n'
    'zero-floor Holland treatment on both bursts (D14); importance sampling on the onset delay; per-path likelihood components and\n'
    'impact outputs saved (thinned, unbiased) for re-weighting and for the downstream modules.\n'
    'Original header follows.\nFast-route end-of-flight estimator, per seed (3 Nov 2026, Pete-approved overnight plan, items 1, 2, 5).')
rep('from option_table_0019 import W_S\n',
    'from option_table_0019 import W_S\n'
    'FINAL = "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07"\n'
    'sys.path.insert(0, FINAL)\n'
    'import dive_kernel as DK, kernel_params as KP\n'
    'SPEC = json.load(open(FINAL + "/eof-final-spec.json")); CP = json.load(open(FINAL + "/case-prior.json"))\n'
    'CAUSE_FE = float(SPEC["priors"]["logon_cause_fuel_exhaustion"])\n'
    '_LG = np.linspace(np.log(0.5), np.log(5000.0), 6000); _LP = KP.logpdf_predictive(CP, "onset_delay_s", "noinput", np.exp(_LG))\n'
    'def don_logpdf(d):\n'
    '    return np.interp(np.log(np.maximum(d, 1e-6)), _LG, _LP, left=-np.inf, right=-np.inf)\n')
# two-stage delay: terminal about 60 s (ATSB 3 Dec 2015), not the withdrawn 60-160 s
rep('_sdu = ((_G >= 60) & (_G <= 160)).astype(float); _sdu /= _trap(_sdu, _G)',
    '_sdu = np.exp(-0.5 * ((_G - 60) / 10) ** 2) * (_G > 0); _sdu /= _trap(_sdu, _G)   # terminal about 60 s (ATSB 3 Dec 2015); 160 s was withdrawn')
# cause prior from spec
rep('def cause_term(t_imp, tP, fo_final, lagf):', 'def cause_term(t_imp, tP, fo_final, lagf, pfe=None):')
rep('    return np.logaddexp(np.log(0.75) + C1, np.log(0.25) + C2)\n',
    '    pfe = CAUSE_FE if pfe is None else pfe\n    return np.logaddexp(np.log(pfe) + C1, np.log(1.0 - pfe) + C2)\n'
    'CAUSES = {"g75": (lag_logpdf, None), "g50": (lag_logpdf, 0.5), "two": (lag_logpdf_two, None)}   # g75 = headline (CAUSE_FE from the spec)\n')
rep('    caus = {nm: cause_term(ti, tP, ffinal, lf) for nm, lf in (("gamma", lag_logpdf), ("two", lag_logpdf_two))}',
    '    caus = {nm: cause_term(ti, tP, ffinal, lf, pf) for nm, (lf, pf) in CAUSES.items()}')
rep('        for nm, lf in (("gamma", lag_logpdf), ("two", lag_logpdf_two)):\n            cn = cause_term(timp, tP_n, ffinal, lf); ca = cause_term(timp, tP_a, ffinal, lf)',
    '        for nm, (lf, pf) in CAUSES.items():\n            cn = cause_term(timp, tP_n, ffinal, lf, pf); ca = cause_term(timp, tP_a, ffinal, lf, pf)')
# break-up factor removed
rep('    return {k: v + surv for k, v in D.items()}', '    return D                                   # break-up factor removed (settling ruling)')
rep('    out = base + bto + l29 + acc + surv\n', '    out = base + bto + l29 + acc               # break-up factor removed\n')
# Holland zero floor on both bursts
rep('''    acc = np.full(np.shape(p29), -np.inf)          # running log-sum-exp: O(n) memory (was 1,024 x n terms held at once)
    for s2, ws in zip(SEC, WSEC):''', '''    acc = np.full(np.shape(p29), -np.inf)          # running log-sum-exp: O(n) memory (was 1,024 x n terms held at once)
    for s2, ws in (zip(SEC0, WSEC0) if offset == "holland0" else zip(SEC, WSEC)):''')
rep('''def parse_bias(path):''', '''def d14_stored(g, hpath, prefix):
    """Both bursts with Holland's start-up offset, zero floor (R1200 offset U[0,130] Hz, R600 offset = that + U[0,6] Hz), for stored
    engine rows, from the stored innovations through the sequential bias chain (as d5_stored). R600 BTO included; R1200 BTO added by caller."""
    bm, bv = parse_bias(hpath); par = g("parent").astype(int); M0, V0 = bm[par], bv[par]
    obs = {r["epoch_id"]: r for r in csv.DictReader(open(J.SATCOM_CSV))}; sdt = float(obs["m0019a"]["bto_sd_us"])
    N_ = lambda x, S: -0.5 * (x * x / S + np.log(2 * np.pi * S))
    m, v = M0.copy(), V0.copy(); eps = ("m2315", "m0011") if prefix else ()
    try:
        [g(f"bfo_innovation_hz:{ep}") for ep in eps]
    except KeyError:
        return np.full(len(M0), -np.inf)
    for ep in eps:
        r = g(f"bfo_innovation_hz:{ep}") - (m - M0); S = v + SD_BFO ** 2; K = v / S; m = m + K * r; v = v * (1 - K)
    i29 = g("bfo_innovation_hz:m0019a") - (m - M0); p37 = -2.0 - g("bfo_innovation_hz:m0019b") - M0
    S = v + SD_BFO ** 2; K = v / S; v1 = v * (1 - K); acc = np.full(len(M0), -np.inf)
    for s2, ws in zip(SEC0, WSEC0):
        for d, wd in zip(FMS, WFMS):
            r29 = i29 - (s2 + d); m1 = m + K * r29
            acc = np.logaddexp(acc, np.log(ws * wd) + N_(r29, S) + N_((-2.0 - s2) - (p37 + m1), v1 + SD_BFO ** 2))
    bto = N_(g("bto_residual_us:m0019a"), sdt ** 2)
    base = np.where(np.isfinite(g("loglik:m0011")), g("loglik:m0011"), -np.inf) if prefix else 0.0
    out = base + bto + acc
    return np.where(np.isfinite(out), out, -np.inf)

def parse_bias(path):''')
rep('''        cellsD["D6"] = d5_stored(g, h2241 if arm == 'S1' else h0011, arm == 'S1', zero_floor=True)''',
    '''        cellsD["D6"] = d5_stored(g, h2241 if arm == 'S1' else h0011, arm == 'S1', zero_floor=True)
        cellsD["D14"] = d14_stored(g, h2241 if arm == 'S1' else h0011, arm == 'S1')''')
rep('''        for k_src, k_new in (("D3", "D9"), ("D4", "D10"), ("D5", "D11"), ("D6", "D12")): cellsD[k_new] = cellsD[k_src] + _b37''',
    '''        for k_src, k_new in (("D3", "D9"), ("D4", "D10"), ("D5", "D11"), ("D6", "D12")): cellsD[k_new] = cellsD[k_src] + _b37
        cellsD["D14"] = cellsD["D14"] + _b37''')
rep('''    for k_src, k_new in (("D3", "D9"), ("D4", "D10"), ("D5", "D11"), ("D6", "D12")): D[k_new] = D[k_src] + bto37   # both BTOs + the BFO cells''',
    '''    for k_src, k_new in (("D3", "D9"), ("D4", "D10"), ("D5", "D11"), ("D6", "D12")): D[k_new] = D[k_src] + bto37   # both BTOs + the BFO cells
    D["D14"] = bto29 + bto37 + bfo_ll(bmean, bvar, p29, p37, True, "holland0")''')
rep('''    for k in ("D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "D11", "D12", "D13"): D[k]''',
    '''    for k in ("D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "D11", "D12", "D13", "D14"): D[k]''')
# score: bank from the state (kernel rows) instead of Boeing lookup
rep('''    bank = np.zeros(len(rows["tP"]))
    for r in range(1, 11):
        k = F["run"] == r
        if not k.any(): continue
        A = L.run_att(f"Case {r:02d}.csv"); bank[k] = np.interp(s21["tau"][k], A.t.values, A.bank.values)''',
    '''    bank = np.nan_to_num(np.asarray(s21["bank"], float))''')
# fly(): optional state at steep onset, and tau at impact
rep('def fly(rows, times, run_override=None, st_override=None):', 'def fly(rows, times, run_override=None, st_override=None, steep_state=False):')
rep('''    ti = rows["tP"] + hi_; sti = state(ti); out["impact"] = dict(t=ti, **{k: sti[k] for k in ("lat", "lon", "ve", "vn", "vu")})''',
    '''    ti = rows["tP"] + hi_; sti = state(ti); out["impact"] = dict(t=ti, **{k: sti[k] for k in ("lat", "lon", "ve", "vn", "vu", "tau", "h")})
    if steep_state: out["at_steep"] = state(rows["tP"] + np.where(np.isfinite(t_steep), t_steep, 0.0))''')
open("a1gen_final_part1.py", "w").write(src)
print("part1 ok", len(src))
