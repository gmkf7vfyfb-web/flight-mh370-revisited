"""Case-informed dive kernel (7 Nov 2026): three-degree-of-freedom point mass (wind axes) for the descent after power loss
with no effective crew input. Phases: (0) before onset: straight flight, true airspeed held, descent at the pre-onset rate;
(1) build-up: the target downward acceleration grows exponentially, a(t) = a8 * g * exp((t - T15)/tau_e) for t < T15, where
tau_e is solved so that the descent rate reaches 15,000 ft/min at t = T15 (so a8 and T15 are the two case-informed quantities);
the bank grows in proportion, phi(t) = sign * phi_m * a(t)/(a8 g); the load factor n solves g(1 - n cos(phi) cos(gamma)) = a(t), limited to the transport-category manoeuvring
limits [-1.0, +2.5] g (CS-25.337); (2) after T15 the load factor and bank are frozen at their build-up end values (no input) and gravity and drag
set the dive; (3) optional arrest (Boeing 777 alternate-power simulations: pull-out at 1.6-2.5 g with the bank still 38-52 deg, bottom
3,750-18,900 ft, climb angle 2-58 deg): the pull starts when the height above the drawn bottom altitude h_bot equals the
pull-out height V^2 (1 - cos gamma) / (g (n_rec cos phi_arr - 1)); the bank moves to phi_arr at 15 deg/s and n = n_rec until
gamma >= gamma_top; then the bank returns to the frozen spiral bank and n to the frozen value, so the nose drops again (no further arrest). Drag: CD = CD0 + k CL^2 + 20 (M - 0.76)^4 for M > 0.76
(Lock's fourth-power drag rise), ISA atmosphere, Boeing 777-200ER reference area 427.8 m^2. Thrust T (N) until t_thr_end.
ERA5 wind (per-path vertical profile) is added to the ground velocity. Euler integration, dt = 0.5 s.
All angles in radians inside; outputs in project units (ft, kt, ft/min, deg)."""
import numpy as np
from numba import njit, prange
G0 = 9.80665; FT = 0.3048; KT = 0.514444; S_REF = 427.8; CD0 = 0.018; K_IND = 0.046; MCR = 0.76; K_DR = 20.0
CLMAX_LOW = 1.4; CLMAX_HIGH = 0.9   # clean-wing maximum lift coefficient: about 1.4 at low Mach, falling to about 0.9 at Mach 0.8 and above (buffet limit)

@njit(cache=True, fastmath=False)
def isa(h_m):
    if h_m < 11000.0:
        T = 288.15 - 0.0065 * h_m; p = 101325.0 * (T / 288.15) ** 5.25588
    else:
        T = 216.65; p = 22632.1 * np.exp(-(h_m - 11000.0) / 6341.6)
    rho = p / (287.053 * T); a = np.sqrt(1.4 * 287.053 * T)
    return rho, a

@njit(cache=True, fastmath=False)
def wind(lev, prof_i, h_ft):
    # lev ascending pressure-altitude levels (ft); prof_i (nlev, 2) m/s east/north
    nl = lev.shape[0]
    if h_ft <= lev[0]: return prof_i[0, 0], prof_i[0, 1]
    if h_ft >= lev[nl - 1]: return prof_i[nl - 1, 0], prof_i[nl - 1, 1]
    j = np.searchsorted(lev, h_ft) - 1
    f = (h_ft - lev[j]) / (lev[j + 1] - lev[j])
    return prof_i[j, 0] * (1 - f) + prof_i[j + 1, 0] * f, prof_i[j, 1] * (1 - f) + prof_i[j + 1, 1] * f

@njit(cache=True)
def solve_tau(a, T, dv):
    # tau (1 - exp(-T/tau)) = dv / a ; returns nan if infeasible (dv/a >= T)
    x = dv / a
    if x >= T: return np.nan
    lo = 1e-3; hi = 1e6
    for _ in range(80):
        m = 0.5 * (lo + hi)
        if m * (1.0 - np.exp(-T / m)) < x: lo = m
        else: hi = m
    return 0.5 * (lo + hi)

NREC = 3   # recorded target times per path
NOUT_T = 9 # lat, lon, h_ft, vn_kt, ve_kt, vu_fpm, bank_deg, gamma_deg, heading_deg
NOUT_I = 21

@njit(parallel=True, cache=True, fastmath=False)
def fly_kernel(lat0, lon0, h0_ft, V0, psi0, gam0, mass, thrust_N, t_thr_end, v_pre_fpm, d_on, a8, t15, phi_m, sgn,
               arrest, h_pull_ft, n_rec, gam_top, phi_arr, targets, lev, prof, dt, t_max):
    n = lat0.shape[0]
    rec = np.full((n, NREC, NOUT_T), np.nan, dtype=np.float32)
    out = np.full((n, NOUT_I), np.nan, dtype=np.float64)
    for i in prange(n):
        lat = lat0[i]; lon = lon0[i]; h = h0_ft[i] * FT; V = V0[i]; psi = psi0[i]; gam = gam0[i] if not np.isnan(gam0[i]) else -v_pre_fpm[i] * FT / 60.0 / max(V, 50.0)
        phi = 0.0; t = 0.0; phase = 0; n_fr = 1.0; phi_fr = 0.0;
        tau_e = solve_tau(a8[i] * G0, t15[i], 15000.0 * FT / 60.0 - v_pre_fpm[i] * FT / 60.0)
        if np.isnan(tau_e): tau_e = 1.0
        tau0 = d_on[i]; arrested_done = False; t15r = np.nan; maxM = 0.0; maxEAS = 0.0
        nmax = 1.0; nmin = 1.0; hbot = np.nan; nn = 1.0; pk_pre = 0.0
        # ring buffer of vertical speed for the 8-s mean acceleration
        nb = int(round(8.0 / dt)); buf = np.zeros(64); a8r = 0.0; k = 0; prev_vz = V * np.sin(gam)
        coslat = np.cos(np.radians(lat))
        rec_done = np.zeros(NREC, dtype=np.bool_)
        for j in range(NREC):
            if targets[i, j] < 0.0:
                rec_done[j] = True
        if h <= 0.0:
            t_max_i = -1.0                       # already at the sea: no flight
        else:
            t_max_i = t_max[i]
        while t < t_max_i:
            rho, asnd = isa(max(h, 0.0)); M = V / asnd; q = 0.5 * rho * V * V
            eas = V * np.sqrt(rho / 1.225) / KT
            if M > maxM: maxM = M
            if eas > maxEAS: maxEAS = eas
            # --- control law ---
            if phase == 0:
                nn = np.cos(gam); phi = 0.0
                if t >= tau0: phase = 1
            if phase == 1 or phase == 4:
                tau = t - tau0
                ad = a8[i] * G0 * np.exp((tau - t15[i]) / tau_e)
                phi = sgn[i] * phi_m[i] * ad / (a8[i] * G0)
                den = np.cos(gam) * np.cos(phi)
                if abs(den) > 0.05: nn = (1.0 - ad / G0) / den
                else: nn = 1.0
                if nn > 2.5: nn = 2.5
                if nn < -1.0: nn = -1.0
                if tau >= t15[i]:
                    phase = 2 if phase == 1 else 5; n_fr = nn; phi_fr = phi
            if phase == 2 or phase == 5:
                nn = n_fr; phi = phi_fr
            if (phase == 1 or phase == 2) and arrest[i] and (not arrested_done) and gam < 0.0:
                dn_ = n_rec[i] * np.cos(phi_arr[i]) - 1.0
                if dn_ < 0.1: dn_ = 0.1
                if h <= h_pull_ft[i] * FT + V * V * (1.0 - np.cos(gam)) / (G0 * dn_):
                    if phase == 1:                    # arrest before the build-up ended: frozen spiral = planned plateau (bank phi_m, n for a8 at level flight)
                        phi_fr = sgn[i] * phi_m[i]; cpm = np.cos(phi_fr)
                        n_fr = (1.0 - a8[i]) / cpm if abs(cpm) > 0.05 else 1.0
                        if n_fr > 2.5: n_fr = 2.5
                        if n_fr < -1.0: n_fr = -1.0
                    phase = 3
            if phase == 3:
                step = np.radians(15.0) * dt; tgt = np.sign(phi if phi != 0.0 else sgn[i]) * phi_arr[i]
                if abs(phi - tgt) <= step: phi = tgt
                else: phi += np.sign(tgt - phi) * step
                nn = n_rec[i]
                if gam >= gam_top[i] or V < 110.0:          # top of the climb, or the pull can no longer be held (low speed)
                    arrested_done = True; phase = 6
            if phase == 6:                       # after the arrest: bank returns to the frozen spiral bank; n frozen (no input)
                step = np.radians(15.0) * dt
                if abs(phi - phi_fr) <= step: phi = phi_fr
                else: phi += np.sign(phi_fr - phi) * step
                nn = n_fr
                if V < 150.0 and nn * np.cos(phi) >= np.cos(gam):   # low speed, still climbing: the nose drops (no input)
                    nn = 0.8 * np.cos(gam) / max(abs(np.cos(phi)), 0.2)
            if phase == 3 and (np.isnan(hbot) or h < hbot): hbot = h
            if nn > 2.5: nn = 2.5
            if nn < -1.0: nn = -1.0
            clmax = CLMAX_LOW if M < 0.5 else (CLMAX_HIGH if M > 0.8 else CLMAX_LOW + (CLMAX_HIGH - CLMAX_LOW) * (M - 0.5) / 0.3)
            nlim = clmax * q * S_REF / (mass[i] * G0)                 # stall: |n| cannot exceed the lift the wing can give
            if nn > nlim: nn = nlim
            if nn < -nlim: nn = -nlim
            if nn > nmax: nmax = nn
            if nn < nmin: nmin = nn
            # --- aerodynamics ---
            CL = nn * mass[i] * G0 / max(q * S_REF, 1.0)
            dM = M - MCR
            CD = CD0 + K_IND * CL * CL + (K_DR * dM ** 4 if dM > 0 else 0.0)
            D = q * S_REF * CD
            T = thrust_N[i] if t < t_thr_end[i] else 0.0
            dV = (T - D) / mass[i] - G0 * np.sin(gam)
            cg = np.cos(gam)
            dg = (G0 / max(V, 50.0)) * (nn * np.cos(phi) - cg) if phase != 0 else 0.0
            dpsi = G0 * nn * np.sin(phi) / (max(V, 50.0) * max(cg, 0.05))
            we, wn = wind(lev, prof[i], h / FT)
            vn = V * cg * np.cos(psi) + wn; ve = V * cg * np.sin(psi) + we; vz = V * np.sin(gam)
            # record targets
            for j in range(NREC):
                if (not rec_done[j]) and t >= targets[i, j]:
                    rec[i, j, 0] = lat; rec[i, j, 1] = lon; rec[i, j, 2] = h / FT; rec[i, j, 3] = vn / KT; rec[i, j, 4] = ve / KT
                    rec[i, j, 5] = vz / FT * 60.0; rec[i, j, 6] = np.degrees(phi); rec[i, j, 7] = np.degrees(gam); rec[i, j, 8] = np.degrees(psi) % 360.0
                    rec_done[j] = True
            if (not arrested_done) and phase != 3 and -vz > pk_pre: pk_pre = -vz
            # 8-s mean downward acceleration
            buf[k % nb] = vz
            if k >= nb:
                a_dn = -(vz - buf[(k + 1) % nb]) / ((nb - 1) * dt) / G0
                if a_dn > a8r: a8r = a_dn
            k += 1
            if phase != 0 and np.isnan(t15r) and -vz / FT * 60.0 >= 15000.0: t15r = t - d_on[i]
            # --- step ---
            hn = h + vz * dt
            if hn <= 0.0:
                fr = h / max(h - hn, 1e-9)
                lat += vn * dt * fr / 1852.0 / 60.0; lon += ve * dt * fr / 1852.0 / 60.0 / coslat
                t += dt * fr; h = 0.0
                break
            lat += vn * dt / 1852.0 / 60.0; lon += ve * dt / 1852.0 / 60.0 / coslat
            h = hn; V = max(V + dV * dt, 50.0); gam = gam + dg * dt
            if gam < -np.radians(89.0): gam = -np.radians(89.0)
            if gam > np.radians(60.0): gam = np.radians(60.0)
            psi = psi + dpsi * dt; t += dt
        if h < 0.0: h = 0.0
        cg = np.cos(gam); we, wn = wind(lev, prof[i], 0.0)
        out[i, 0] = t; out[i, 1] = lat; out[i, 2] = lon; out[i, 3] = V
        out[i, 4] = (V * cg * np.cos(psi) + wn) / KT; out[i, 5] = (V * cg * np.sin(psi) + we) / KT; out[i, 6] = V * np.sin(gam) / FT * 60.0
        out[i, 7] = np.degrees(gam); out[i, 8] = np.degrees(phi); out[i, 9] = np.degrees(psi) % 360.0; out[i, 10] = nn
        out[i, 11] = maxM; out[i, 12] = maxEAS; out[i, 13] = nmax; out[i, 14] = nmin; out[i, 15] = a8r; out[i, 16] = t15r
        out[i, 17] = 1.0 if arrested_done else 0.0; out[i, 18] = hbot / FT if not np.isnan(hbot) else np.nan; out[i, 19] = 1.0 if h <= 0.0 else 0.0;  # 0 = did not reach the sea within t_max
        out[i, 20] = pk_pre / FT * 60.0
    return rec, out

OUT_NAMES = ["t_rel_s", "lat", "lon", "tas_mps", "vn_kt", "ve_kt", "vu_fpm", "gamma_deg", "bank_deg", "heading_deg", "n_g",
             "max_mach", "max_eas_kt", "max_n_g", "min_n_g", "a8_realised_g", "t15_after_onset_s", "arrested", "h_bottom_ft", "reached_sea", "peak_descent_before_arrest_fpm"]
REC_NAMES = ["lat", "lon", "h_ft", "vn_kt", "ve_kt", "vu_fpm", "bank_deg", "gamma_deg", "heading_deg"]
