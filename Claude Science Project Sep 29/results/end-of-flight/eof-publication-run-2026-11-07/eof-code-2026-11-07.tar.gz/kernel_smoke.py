import sys; sys.path.insert(0, "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07")
import numpy as np, time, dive_kernel as K
n=20000; r=np.random.default_rng(1)
lev=np.array([0,5000,10000,20000,30000,40000,50000],float); prof=np.zeros((n,7,2),np.float32)
args=dict(lat0=np.full(n,-37.0), lon0=np.full(n,89.0), h0_ft=np.full(n,35000.0), V0=np.full(n,240.0), psi0=np.full(n,np.pi), gam0=np.full(n,np.nan), mass=np.full(n,175000.0),
 thrust_N=np.full(n,55000.0), t_thr_end=np.full(n,400.0), v_pre_fpm=np.full(n,1300.0), d_on=r.uniform(20,120,n), a8=np.exp(r.normal(np.log(0.7),0.5,n)), t15=np.exp(r.normal(np.log(40),0.9,n)),
 phi_m=np.radians(r.uniform(40,120,n)), sgn=r.choice([-1.0,1.0],n), arrest=r.random(n)<0.45, h_pull_ft=r.uniform(3750,18900,n),
 n_rec=r.uniform(1.6,2.5,n), gam_top=np.radians(r.uniform(2,58,n)), phi_arr=np.radians(r.uniform(38,52,n)), targets=np.tile([60.0,68.0,150.0],(n,1)), lev=lev, prof=prof, dt=0.5, t_max=np.full(n,3000.0))
t0=time.time(); rec,out=K.fly_kernel(**args); print('compile+run %.1f s'%(time.time()-t0))
t0=time.time(); rec,out=K.fly_kernel(**args); print('run %.2f s for %d'%(time.time()-t0,n))
o={k:out[:,i] for i,k in enumerate(K.OUT_NAMES)}
for k in ['t_rel_s','vu_fpm','gamma_deg','max_mach','max_eas_kt','a8_realised_g','t15_after_onset_s','arrested','h_bottom_ft','reached_sea','max_n_g','min_n_g']:
    v=o[k]; f=np.isfinite(v); print(k, np.round(np.quantile(v[f],[0.05,0.5,0.95]),2) if f.any() else 'nan', 'finite %.2f'%f.mean())
bad=o['reached_sea']<1; print('not reaching sea', bad.mean())
for k in ['a8','t15','d_on','phi_m','n_rec','gam_top','phi_arr','arrest']:
    v=np.asarray(args[k],float); print(k, np.round(np.quantile(v[bad],[0.05,0.5,0.95]),3), 'all', np.round(np.quantile(v,[0.05,0.5,0.95]),3))
print('final gamma', np.round(np.quantile(o['gamma_deg'][bad],[0.05,.5,.95]),1), 'n', np.round(np.quantile(o['n_g'][bad],[0.05,.5,.95]),2), 'bank', np.round(np.quantile(o['bank_deg'][bad],[0.05,.5,.95]),1), 'tas',np.round(np.quantile(o['tas_mps'][bad],[0.05,.5,.95]),1))
