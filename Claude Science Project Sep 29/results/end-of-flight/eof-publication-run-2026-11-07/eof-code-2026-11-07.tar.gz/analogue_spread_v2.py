"""Revised (v2) spread kernel for the Boeing-analogue end-of-flight generator.

Stdlib + numpy only. Preregistration: prereg-loo-boeing-analogue-v2.md (artifact version 915a40c9).
Source: Boeing engineering-simulator end-of-flight runs (ATSB scenarios, April 2016; traces released by
Iannello 2018). Event times inferred from the tracks; mean sink, A0 and T_g from the v1 phugoid fit
(phugoid-growth-fit.csv, artifact version b0c18c3e). Constants below use ALL donors (not leave one out).

Alternate group (runs 3, 4, 6, 10): time stretch s_t after first flame-out, ln s_t = k*S_ALT*T_3.
  Replay keeps ground and vertical speed; path is scaled by s_t about the flame-out point; times to end
  and to 15,000 ft/min and ground distance scale by s_t; peak descent is unchanged; bank follows
  atan(tan|bank_d(t_u + 20/s_t)|/s_t). Altitude offset: raise the start by
  (s_t - 1) * (h_flameout - h_end) of the donor so the replay ends at the donor's end altitude.
Normal group (runs 1, 2, 5, 7, 8, 9): sink scale s_h, ln s_h = k*S_NORM*T_3, plus a steep ending:
  (ln A0, ln T_g) ~ N(PHUGOID_MEAN, k^2 * PHUGOID_COV); projected peak descent at t s after autopilot
  loss = s_h*sink_d + A0*exp(t/(60*T_g)); t_steep = first t >= 0 where this reaches 15,000 ft/min;
  steep if t_steep < time_to_end_d / s_h. Otherwise the glide replays the donor with sink scaled by s_h.
"""
import numpy as np

NU = 3                 # Student-t degrees of freedom (fixed in the preregistration)
K_DEFAULT = 1.5        # headline spread factor; 1.0 and 2.0 were sensitivities
STEEP_FTMIN = 15000.0  # steep-ending threshold (ft/min)

NORMAL_RUNS = [1, 2, 5, 7, 8, 9]
NORMAL_MEAN_SINK_FTMIN = np.array([1309.599, 1322.827, 1745.622, 1333.173, 1400.928, 1390.516])
NORMAL_TIME_TO_END_S = np.array([1411.0, 1368.0, 1019.0, 1341.0, 1342.0, 1441.0])
NORMAL_HEIGHT_LOSS_FT = np.array([31035.0, 30736.0, 32489.0, 30996.0, 32265.0, 34266.0])
PHUGOID_MEAN = np.array([7.505847, 2.789303])        # (ln A0 [ft/min], ln T_g [min])
PHUGOID_COV = np.array([[0.359309, 0.0899], [0.0899, 0.133143]])
S_NORM = 0.108162     # sd of ln(mean sink) over the six normal runs

ALT_RUNS = [3, 4, 6, 10]
ALT_TIME_TO_15K_S = np.array([296.0, 168.0, 157.0, 171.0])
ALT_H_FLAMEOUT_FT = np.array([39955.0, 39984.0, 34954.0, 39954.0])
ALT_H_END_FT = np.array([653.0, 484.0, 742.0, 1131.0])
S_ALT = 0.293849      # sd of ln(time to 15,000 ft/min) over the four alternate runs, pooled


def steep_time_s(sink_eff_ftmin, ln_a0, ln_tg):
    """First time (s after autopilot loss) at which sink + A0 exp(t/T_g) reaches STEEP_FTMIN."""
    a0 = np.exp(ln_a0); tg_s = 60.0 * np.exp(ln_tg)
    x = (STEEP_FTMIN - sink_eff_ftmin) / a0
    with np.errstate(divide="ignore", invalid="ignore"):
        t = np.where(x > 1.0, tg_s * np.log(np.maximum(x, 1.0)), 0.0)
    return t


def kernel_normal(donor, rng, k, mean_sink, time_to_end, height_loss, ph_mean, ph_cov, s_norm, nu=NU):
    """Normal-group kernel for given donor indices (array). Returns dict of arrays."""
    n = len(donor)
    s_h = np.exp(k * s_norm * rng.standard_t(nu, n))
    z = rng.multivariate_normal(ph_mean, ph_cov * k ** 2, n)
    sink = mean_sink[donor] * s_h
    t_cross = steep_time_s(sink, z[:, 0], z[:, 1])
    end_glide = time_to_end[donor] / s_h
    steep = t_cross < end_glide
    h_rem = height_loss[donor] * np.clip(1.0 - t_cross / end_glide, 0.0, 1.0)
    end_s = np.where(steep, t_cross + 60.0 * h_rem / STEEP_FTMIN, end_glide)
    return dict(donor=donor, s_h=s_h, ln_a0=z[:, 0], ln_tg=z[:, 1], sink_ftmin=sink, steep=steep,
                t_steep_s=np.where(steep, t_cross, np.inf), end_s=end_s)


def kernel_alternate(donor, rng, k, s_alt, nu=NU):
    n = len(donor)
    return dict(donor=donor, s_t=np.exp(k * s_alt * rng.standard_t(nu, n)))


def draw_spread(group, n, rng, k=K_DEFAULT):
    """Draw n kernel samples with all-donor constants.

    group 'alternate' -> s_t (time stretch), donor_run, alt_offset_ft (start-altitude raise).
    group 'normal'    -> s_h (sink scale), steep (bool), t_steep_s (s after autopilot loss; inf if none),
                         donor_run, ln_a0, ln_tg, end_s (replayed time from autopilot loss to end).
    """
    if group == "alternate":
        d = rng.integers(0, len(ALT_RUNS), n)
        out = kernel_alternate(d, rng, k, S_ALT)
        out["alt_offset_ft"] = (out["s_t"] - 1.0) * (ALT_H_FLAMEOUT_FT[d] - ALT_H_END_FT[d])
    elif group == "normal":
        d = rng.integers(0, len(NORMAL_RUNS), n)
        out = kernel_normal(d, rng, k, NORMAL_MEAN_SINK_FTMIN, NORMAL_TIME_TO_END_S, NORMAL_HEIGHT_LOSS_FT,
                            PHUGOID_MEAN, PHUGOID_COV, S_NORM)
    else:
        raise ValueError("group must be 'normal' or 'alternate'")
    runs = np.array(ALT_RUNS if group == "alternate" else NORMAL_RUNS)
    out["donor_run"] = runs[out.pop("donor")]
    return out


if __name__ == "__main__":
    rng = np.random.default_rng(20261104)
    q = [0.01, 0.1, 0.5, 0.9, 0.99]
    for g in ["alternate", "normal"]:
        o = draw_spread(g, 200000, rng)
        print(g)
        for key, v in o.items():
            v = np.asarray(v)
            if v.dtype == bool:
                print(f"  {key}: share True = {v.mean():.4f}")
            elif key == "t_steep_s":
                f = v[np.isfinite(v)]
                print(f"  {key}: finite share {np.isfinite(v).mean():.4f}; quantiles of finite " + str(np.round(np.quantile(f, q), 1)))
            else:
                print(f"  {key}: quantiles {q} = " + str(np.round(np.quantile(v, q), 4)))
