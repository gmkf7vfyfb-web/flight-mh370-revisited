"""Run a1gen.py on a Run J production (compact) seed folder, e.g. run-j/run-j-repro-radar (Davey model + fuel), 00:11 arm only.
Column mapping to the joined-V2 slim names; first flame-out = onset for alternate rows (the engine moves the onset there), else the
final flame-out; predicted endurance = realised final flame-out - onset (realised ~ predicted at the 00:11 hand-off); loglik:none = 0.
Usage: python a1gen_compact.py PROD_RUN_DIR HANDOFF_0011 OUT_PREFIX SEED   (sets A1GEN_ONLY_FE=1, T0 = T1, dlnZ = 0)"""
import sys, os, json, pathlib, runpy
import numpy as np
W = "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07"
sys.path.insert(0, W + "/repo/Claude Science Project Sep 29/engine/hypotheses/end-of-flight/smoke")
import joined_v2 as J
def load_compact(run, seed):
    d = pathlib.Path(run) / f"seed-{seed}"; meta = json.loads((d / "run.json").read_text()); Y = np.load(d / "impacts32.npy", mmap_mode="r")
    ix = {c: i for i, c in enumerate(meta["impact_columns"])}; T0 = meta["compact"]["T0_unix_s"]
    tmap = {v: k for k, v in meta["compact"]["time_columns"].items()}       # joined name -> compact relative column
    col = lambda n: np.asarray(Y[:, ix[n]], np.float64)
    def g(n):
        if n in ix: return col(n)
        if n in tmap: return col(tmap[n]) + T0
        if n == "loglik:none" or n.startswith("loglik:m0011"): return np.zeros(Y.shape[0])   # 22:41-arm columns: that arm is empty here
        if n == "latent:first_flameout_unix_s":
            return np.where(col("latent:ap_loss_config") == 2, col("t_onset_s") + T0, col("t_realised_flameout_s") + T0)
        if n == "latent:predicted_endurance_at_onset_s":
            # empty final flame-out = left engine still running at impact (alternate rows): endurance beyond impact
            fo = col("t_realised_flameout_s"); return np.where(np.isfinite(fo), fo - col("t_onset_s"), 1.0e6)
        raise KeyError(n)
    meta.setdefault("slim", {"time_columns": [], "t_ref": 0.0})
    return meta, g, ix
J.load = load_compact
class _NeutralPrior:
    # single-arm mode: T0 = T1 and only flame-out-associated rows are kept, so the V2 prior ratio is identically 0 (log scale)
    def __init__(self, cfg): pass
    def log_density(self, mech, tau, P, T): return np.zeros(np.shape(tau))
J.Prior = _NeutralPrior
prod, h0011, outp, seed = sys.argv[1:5]
os.environ["A1GEN_ONLY_FE"] = "1"
sys.argv = ["a1gen.py", prod, prod, h0011, h0011, outp, seed]
runpy.run_path(W + "/a1gen_final.py", run_name="__main__")
