"""Guarded queue for the final end-of-flight production run: Davey model + fuel seeds 1-16, then waypoint seeds 1-24.
At most MAXJ seed processes at once; a new start only when system free memory >= 40 %; finished outputs are skipped (safe to rerun)."""
import subprocess, os, time, re, shutil
W = "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07"; OUT = os.environ.get("OUT", W + "/out"); MAXJ = int(os.environ.get("MAXJ", "2"))
jobs = [("df", s) for s in range(1, 17)] + [("wp", s) for s in range(1, 25)]
def free_pct():
    try:
        out = subprocess.run(["memory_pressure"], capture_output=True, text=True, timeout=30).stdout
        return int(re.search(r"free percentage: (\d+)%", out).group(1))
    except Exception:
        return 0
os.makedirs(OUT, exist_ok=True)
todo = [j for j in jobs if not os.path.exists(f"{OUT}/{j[0]}-s{j[1]}.json")]
print(time.strftime("%H:%M:%S"), f"{len(todo)} of {len(jobs)} seed runs to do", flush=True)
running = []
while todo or running:
    still = []
    for p, j in running:
        if p.poll() is None: still.append((p, j))
        else: print(time.strftime("%H:%M:%S"), "done", *j, "exit", p.returncode, "| disk free %.1f GB" % (shutil.disk_usage(OUT).free / 1e9), flush=True)
    running = still
    if todo and len(running) < MAXJ and free_pct() >= 40 and shutil.disk_usage(OUT).free > 3e9:
        fam, s = todo.pop(0)
        p = subprocess.Popen(["bash", W + "/run1_final.sh", fam, str(s)], env=dict(os.environ, OUT=OUT), stdout=subprocess.DEVNULL)
        running.append((p, (fam, s))); print(time.strftime("%H:%M:%S"), "start", fam, s, "| free mem %", free_pct(), flush=True); time.sleep(5)
    else:
        time.sleep(10)
print("ALL DONE", time.strftime("%H:%M:%S"), flush=True)
