#!/bin/bash
# usage: run1_final.sh wp|df SEED   (output prefix ${OUT:-out}/{wp,df}-sSEED)
PY=/Users/pete/.claude-science/conda/envs/python/bin/python
E=/Users/pete/Downloads/mh370-exchange; W=$E/end-of-flight/final-2026-11-07; O=${OUT:-$W/out}; mkdir -p $O
cd $W
export NUMBA_NUM_THREADS=${NUMBA_NUM_THREADS:-4} OMP_NUM_THREADS=${OMP_NUM_THREADS:-4} A1GEN_SPREAD=v2 A1GEN_K=1.5 A1GEN_ST_BOUNDS=0.5,2.5
if [ "$1" = wp ]; then
  J=$E/end-of-flight/run-j-joined-v2; SD=$E/core/run-j/run-j-waypoints/bto-bfo
  $PY a1gen_final.py $J/J2241 $J/J0011 $SD/seed-$2/handoff-m2241/handoff.toml.gz $SD/seed-$2/handoff-m0011/handoff.toml.gz $O/wp-s$2 $2 > $O/wp-s$2.log 2>&1; rc=$?
else
  SD=$E/core/run-j/run-j-repro-radar/bto-bfo
  $PY a1gen_compact_final.py $E/end-of-flight/run-j/run-j-repro-radar $SD/seed-$2/handoff-m0011/handoff.toml.gz $O/df-s$2 $2 > $O/df-s$2.log 2>&1; rc=$?
fi
echo "$1 seed $2 exit $rc"; exit $rc
