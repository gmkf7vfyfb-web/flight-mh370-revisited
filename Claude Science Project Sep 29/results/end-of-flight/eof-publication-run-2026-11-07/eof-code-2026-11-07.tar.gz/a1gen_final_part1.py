
"""FINAL end-of-flight estimator, per seed (7 Nov 2026; derived from the fast-route a1gen_d5.py of 6 Nov).
Changes: case-informed dive kernel (dive_kernel.py) for no-pilot alternate-configuration descents and late steep endings of
normal-configuration glides; break-up factor removed; log-on cause prior from eof-final-spec.json; corrected two-stage delay;
zero-floor Holland treatment on both bursts (D14); importance sampling on the onset delay; per-path likelihood components and
impact outputs saved (thinned, unbiased) for re-weighting and for the downstream modules.
Original header follows.
Fast-route end-of-flight estimator, per seed (3 Nov 2026, Pete-approved overnight plan, items 1, 2, 5).
A1 rows of the 00:11 arm are re-flown from their takeover state (power loss) with a Boeing analogue (wind swapped,
rotated, perturbed) and re-scored at 00:19 exactly as the engine scores (R600 BTO; BFO no-offset / Holland start-up
offset with the parent's bias, sequential Kalman), with the log-on delay measured from the configuration-dependent
power-loss time. A2 and B rows keep their trajectories and are re-weighted for the corrected clock (eq. 17).
Outputs one JSON + one NPZ per seed. Usage: python a1gen.py J2241_dir J0011_dir h2241.toml.gz h0011.toml.gz out_prefix seed
"""
import sys, os, json, re, gzip, struct, csv
import numpy as np
from scipy.special import gammaln, gammaincc, logsumexp
W = "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07"
sys.path.insert(0, W); sys.path.insert(0, W + "/repo/Claude Science Project Sep 29/engine/hypotheses/end-of-flight/smoke")
import eof_fast_lib as L
import joined_v2 as J
from compact_impacts import family_labels
from option_table_0019 import W_S
FINAL = "/Users/pete/Downloads/mh370-exchange/end-of-flight/final-2026-11-07"
sys.path.insert(0, FINAL)
import dive_kernel as DK, kernel_params as KP
SPEC = json.load(open(FINAL + "/eof-final-spec.json")); CP = json.load(open(FINAL + "/case-prior.json"))
CAUSE_FE = float(SPEC["priors"]["logon_cause_fuel_exhaustion"])
_LG = np.linspace(np.log(0.5), np.log(5000.0), 6000); _LP = KP.logpdf_predictive(CP, "onset_delay_s", "noinput", np.exp(_LG))
def don_logpdf(d):
    return np.interp(np.log(np.maximum(d, 1e-6)), _LG, _LP, left=-np.inf, right=-np.inf)
EVENTS = "/Users/pete/.claude-science/orgs/9db41e8b-db54-4736-82b9-d77e2a9ad222/artifacts/proj_9cc1a5a85f63/0307aa11-9a97-4987-9cb5-b22f4b21e977/v23f70536_boeing-end-of-flight-runs-table.csv"
T29, T37, T2106 = 1394237969.416, 1394237977.443, 1394237977.443 + 89.444
T_LOI = 1394241356.0; T11 = 1394237459.0
SHAPE, SCALE = 8.0, 14.875
rng = np.random.default_rng(int(sys.argv[6]) * 7919 + 17)

# ---------- ERA5 ----------
def era5():
    p = "/Users/pete/Downloads/era5-wind-temperature.bin"; f = open(p, "rb"); f.read(8); n = struct.unpack("<IIII", f.read(16))
    t = np.frombuffer(f.read(8 * n[0]), "<i8"); lev = np.frombuffer(f.read(4 * n[1]), "<f4").astype(float)
    la = np.frombuffer(f.read(4 * n[2]), "<f4").astype(float); lo = np.frombuffer(f.read(4 * n[3]), "<f4").astype(float); off = f.tell(); f.close()
    mm = np.memmap(p, dtype="<f4", mode="r", offset=off, shape=(3,) + tuple(n))
    it = np.searchsorted(t, [T11 - 3600, T_LOI + 3600]); ti = slice(max(it[0]-1, 0), min(it[1]+1, len(t)))
    ila = (la <= -15) & (la >= -50); ilo = (lo >= 70) & (lo <= 115)
    u = np.asarray(mm[1][ti][:, :, ila][:, :, :, ilo], float); v = np.asarray(mm[2][ti][:, :, ila][:, :, :, ilo], float)
    return dict(t=t[ti].astype(float), lev=lev, lat=la[ila], lon=lo[ilo], u=u, v=v)
E5 = era5()
def wind_profile(lat, lon, tt):
    """(n, nlev, 2) wind m/s at each row's position and time (bilinear lat/lon, linear time)."""
    la, lo, ts = E5["lat"], E5["lon"], E5["t"]
    fi = np.interp(lat, la[::-1], np.arange(len(la))[::-1]); fj = np.interp(lon, lo, np.arange(len(lo))); fk = np.interp(tt, ts, np.arange(len(ts)))
    i0 = np.clip(np.floor(fi).astype(int), 0, len(la)-2); j0 = np.clip(np.floor(fj).astype(int), 0, len(lo)-2); k0 = np.clip(np.floor(fk).astype(int), 0, len(ts)-2)
    a, b, c = fi - i0, fj - j0, fk - k0
    out = np.zeros((len(lat), len(E5["lev"]), 2))
    for comp, F in enumerate((E5["u"], E5["v"])):
        acc = 0
        for dk, wk in ((0, 1-c), (1, c)):
            for di, wi in ((0, 1-a), (1, a)):
                for dj, wj in ((0, 1-b), (1, b)):
                    acc = acc + (wk*wi*wj)[:, None] * F[k0+dk, :, i0+di, j0+dj]
        out[:, :, comp] = acc
    return out
def wind_at(prof, h):
    """prof (n, nlev, 2), h (n,) ft -> (n, 2) m/s, linear in pressure altitude, clamped."""
    lev = E5["lev"]; f = np.interp(h, lev, np.arange(len(lev))); i0 = np.clip(np.floor(f).astype(int), 0, len(lev)-2); a = (f - i0)[:, None]
    n = np.arange(len(h)); return prof[n, i0] * (1 - a) + prof[n, i0 + 1] * a

# ---------- Boeing library ----------
import pandas as pd
ev = pd.read_csv(EVENTS).set_index("run")
KT = 0.514444
def wsim(h):
    sp = (23.5 + 0.79 * np.minimum(h, 25000.0) / 1000.0)  # kt, from 246 deg
    return sp * np.sin(np.radians(66.0)), sp * np.cos(np.radians(66.0))
LIB = {}
for r in range(1, 11):
    R = L.run_raw(f"Case {r:02d}.csv"); t = R["t"]; h = R["h"]
    ue, vn_ = wsim(h); vae = R["ve"] - ue; van = R["vn"] - vn_
    Ae = np.r_[0, np.cumsum(vae[1:] * np.diff(t))] / 3600.0; An = np.r_[0, np.cumsum(van[1:] * np.diff(t))] / 3600.0
    e = ev.loc[r]; alt = e.configuration == "alternate"
    tau0 = float(e["first flame-out s"]) if alt else float(str(e["second flame-out s"]).replace("≈", "").split()[0])
    hs = h.astype(float)
    LIB[r] = dict(t=t, h=hs, vu=R["vu"], vae=vae, van=van, Ae=Ae, An=An, tau0=tau0, alt=alt, end=t[-1])
NORMAL = [1, 2, 5, 7, 8, 9]; ALT_RUN = [4, 10]; ALT_STOP = [3, 6]
def t15(r):
    d = LIB[r]; k = np.flatnonzero((d["t"] > d["tau0"]) & (-d["vu"] >= 15000)); return d["t"][k[0]] - d["tau0"] if len(k) else np.nan
def mean_sink(r):
    d = LIB[r]; k = d["t"] > d["tau0"]; return -np.mean(d["vu"][k])
K_INFL = float(os.environ.get("A1GEN_K", "1.5"))
SPREAD = os.environ.get("A1GEN_SPREAD", "v2")          # v2 = preregistered revised kernel (Student-t + steep ending); v1 = lognormal
import analogue_spread_v2 as S2K
ST_BOUNDS = tuple(float(x) for x in os.environ.get("A1GEN_ST_BOUNDS", "0.5,2.5").split(",")); SH_BOUNDS = (0.5, 2.0); A0_MAX = 1.5 * 3481.2; TG_MIN = 10.63 / 1.5; RAMP_S = 30.0           # production physical limits (declared; not part of the LOO test)
SIG_T = {"run": max(0.1, K_INFL * np.nanstd(np.log([t15(r) for r in ALT_RUN]), ddof=1)), "stop": max(0.1, K_INFL * np.nanstd(np.log([t15(r) for r in ALT_STOP]), ddof=1))}
SIG_H = max(0.05, K_INFL * np.std(np.log([mean_sink(r) for r in NORMAL]), ddof=1))
def t_bounded(scale, n, lo, hi):
    x = np.exp(scale * rng.standard_t(S2K.NU, n)); bad = (x < lo) | (x > hi)
    while bad.any():
        x[bad] = np.exp(scale * rng.standard_t(S2K.NU, bad.sum())); bad = (x < lo) | (x > hi)
    return x

def lookup(r, tau, key):
    d = LIB[r]; return np.interp(tau, d["t"], d[key])
def fly(rows, times, run_override=None, st_override=None, steep_state=False):
    """rows: dict of arrays for A1 rows. Returns dict of states at `times` (unix) and impact."""
    n = len(rows["tP"]); K = rows["K"]
    grp = np.where(K == 2, np.where(rows["gap"] > 330.0, 1, 2), 0)   # 0 normal, 1 alt, left engine runs on; 2 alt, left engine stops
    run = np.empty(n, int)
    for gk, lst in ((0, NORMAL), (1, ALT_RUN), (2, ALT_STOP)):
        k = grp == gk; run[k] = rng.choice(lst, size=k.sum())
    alt_row = grp > 0; s_t = np.ones(n); s_h = np.ones(n); t_steep = np.full(n, np.inf)
    if SPREAD == "v1":
        s_t = np.where(grp == 1, np.exp(rng.normal(0, SIG_T["run"], n)), np.where(grp == 2, np.exp(rng.normal(0, SIG_T["stop"], n)), 1.0))
        s_h = np.where(grp == 0, np.exp(rng.normal(0, SIG_H, n)), 1.0)
    else:
        na = alt_row.sum(); nn = (~alt_row).sum()
        s_t[alt_row] = t_bounded(K_INFL * S2K.S_ALT, na, *ST_BOUNDS)
        s_h[~alt_row] = t_bounded(K_INFL * S2K.S_NORM, nn, *SH_BOUNDS)
        z = rng.multivariate_normal(S2K.PHUGOID_MEAN, S2K.PHUGOID_COV * K_INFL ** 2, nn)
        # production physical limits (declared): initial swing A0 <= 1.5 x largest Boeing run (3,481 ft/min), growth time
        # T_g >= fastest Boeing run (10.63 min) / 1.5; draws outside are redrawn
        bad = (np.exp(z[:, 0]) > A0_MAX) | (np.exp(z[:, 1]) < TG_MIN)
        while bad.any():
            z[bad] = rng.multivariate_normal(S2K.PHUGOID_MEAN, S2K.PHUGOID_COV * K_INFL ** 2, bad.sum()); bad = (np.exp(z[:, 0]) > A0_MAX) | (np.exp(z[:, 1]) < TG_MIN)
        sink = np.array([S2K.NORMAL_MEAN_SINK_FTMIN[S2K.NORMAL_RUNS.index(r)] for r in run[~alt_row]]) * s_h[~alt_row]
        t_steep[~alt_row] = S2K.steep_time_s(sink, z[:, 0], z[:, 1])   # s after autopilot loss; dive applies if before the sea
    if st_override is not None:                                        # importance-sampling replicates: donor and stretch given
        run = np.asarray(run_override, int).copy(); s_t = np.asarray(st_override, float).copy()
    tau_e = np.empty(n); h_e = np.empty(n); hc0 = np.empty(n)
    for r in range(1, 11):
        k = run == r
        if not k.any(): continue
        d = LIB[r]; h0 = rows["h0"][k]; hc0[k] = np.interp(d["tau0"], d["t"], d["h"])
        if d["alt"]:
            tau_e[k] = d["tau0"]
        else:
            after = d["t"] >= d["tau0"]; tt = d["t"][after]; hh = d["h"][after]
            hmin = np.minimum.accumulate(hh)        # monotone envelope for energy-height entry
            idx = np.searchsorted(-hmin, -h0, side="left"); idx = np.clip(idx, 0, len(tt) - 1)
            below = h0 < hc0[k]
            tau_e[k] = np.where(below, tt[idx], d["tau0"])
        h_e[k] = np.interp(tau_e[k], d["t"], d["h"])
    prof = wind_profile(rows["lat0"], rows["lon0"], rows["tP"])
    w0 = wind_at(prof, rows["h0"]) / KT                                     # kt
    va_row = np.c_[rows["vE"] / KT - w0[:, 0], rows["vN"] / KT - w0[:, 1]]
    psi_row = np.arctan2(va_row[:, 0], va_row[:, 1])
    psi_run = np.empty(n)
    for r in range(1, 11):
        k = run == r
        if k.any(): psi_run[k] = np.arctan2(lookup(r, tau_e[k], "vae"), lookup(r, tau_e[k], "van"))
    dpsi = psi_row - psi_run; c, s = np.cos(dpsi), np.sin(dpsi)
    def kin(T):
        """Air-relative kinematics T s after power loss (T >= 0): h ft, vu ft/min, ae/an NM (unrotated), ve/vn kt."""
        Tc = np.minimum(T, t_steep); x = T - Tc                              # x > 0 only after a steep-ending onset
        tau = tau_e + Tc / s_t
        h = np.empty(n); vu = np.empty(n); ae = np.empty(n); an = np.empty(n); ve = np.empty(n); vn = np.empty(n)
        for r in range(1, 11):
            k = run == r
            if not k.any(): continue
            d = LIB[r]; tk = tau[k]; inside = tk <= d["end"]; te = np.minimum(tk, d["end"])
            hh = np.interp(te, d["t"], d["h"]); vvu = np.interp(te, d["t"], d["vu"])
            m30 = d["t"] >= d["end"] - 30; vu_end = np.mean(d["vu"][m30]); vae_end = np.mean(d["vae"][m30]); van_end = np.mean(d["van"][m30])
            ext = np.maximum(tk - d["end"], 0)
            hh = hh + vu_end / 60 * ext; vvu = np.where(inside, vvu, vu_end)
            Ae = np.interp(te, d["t"], d["Ae"]) + vae_end / 3600 * ext; An = np.interp(te, d["t"], d["An"]) + van_end / 3600 * ext
            Ae0 = np.interp(tau_e[k], d["t"], d["Ae"]); An0 = np.interp(tau_e[k], d["t"], d["An"])
            ve[k] = np.where(inside, np.interp(te, d["t"], d["vae"]), vae_end); vn[k] = np.where(inside, np.interp(te, d["t"], d["van"]), van_end)
            if d["alt"]:
                if SPREAD == "v1":                                            # v1: slowed replay (same path, speeds / s_t)
                    h[k] = hh + (rows["h0"][k] - hc0[k]); vu[k] = vvu / s_t[k]; ve[k] /= s_t[k]; vn[k] /= s_t[k]
                    ae[k] = Ae - Ae0; an[k] = An - An0
                else:                                                         # v2: path stretched by s_t about the loss, donor speeds
                    h[k] = rows["h0"][k] - s_t[k] * (hc0[k] - hh); vu[k] = vvu
                    ae[k] = s_t[k] * (Ae - Ae0); an[k] = s_t[k] * (An - An0)
            else:
                h[k] = rows["h0"][k] - s_h[k] * (h_e[k] - hh); vu[k] = s_h[k] * vvu
                ae[k] = Ae - Ae0; an[k] = An - An0
        dive = x > 0                                                          # steep ending: 30-s ramp to 15,000 ft/min, air velocity held
        vd = -S2K.STEEP_FTMIN; xr = np.minimum(x, RAMP_S)
        dh = (vu * xr + (vd - vu) * xr ** 2 / (2 * RAMP_S) + vd * np.maximum(x - RAMP_S, 0)) / 60.0
        h = np.where(dive, h + dh, h); vu = np.where(dive, vu + (vd - vu) * xr / RAMP_S, vu)
        ae = ae + ve * x / 3600.0; an = an + vn * x / 3600.0
        return h, vu, ae, an, ve, vn
    def state(t_abs, wind=True):
        dt_ = t_abs - rows["tP"]; T_ = np.maximum(dt_, 0)
        h, vu, ae, an, ve, vn = kin(T_)
        de = c * ae + s * an; dn = -s * ae + c * an; vae_ = c * ve + s * vn; van_ = -s * ve + c * vn
        nst = 40 if wind else 0; wde = np.zeros(n); wdn = np.zeros(n)
        for j in range(nst):
            hj = kin((j + 0.5) / nst * T_)[0]
            wj = wind_at(prof, np.clip(hj, 0, 43000)) / KT
            wde += wj[:, 0] * T_ / nst / 3600; wdn += wj[:, 1] * T_ / nst / 3600
        wnow = wind_at(prof, np.clip(h, 0, 43000)) / KT
        E_nm = de + wde; N_nm = dn + wdn
        lat = rows["lat0"] + N_nm / 60.0; lon = rows["lon0"] + E_nm / (60.0 * np.cos(np.radians(rows["lat0"])))
        return dict(lat=lat, lon=lon, h=h, ve=vae_ + wnow[:, 0], vn=van_ + wnow[:, 1], vu=vu, before=dt_ < 0, tau=tau_e + np.minimum(T_, t_steep) / s_t)
    out = {}
    for name, tt in times.items(): out[name] = state(np.full(n, tt) if np.isscalar(tt) else tt)
    lo_, hi_ = np.zeros(n), np.full(n, 4000.0)
    for _ in range(18):
        mid = 0.5 * (lo_ + hi_); st = state(rows["tP"] + mid, wind=False); above = st["h"] > 0; lo_ = np.where(above, mid, lo_); hi_ = np.where(above, hi_, mid)
    ti = rows["tP"] + hi_; sti = state(ti); out["impact"] = dict(t=ti, **{k: sti[k] for k in ("lat", "lon", "ve", "vn", "vu", "tau", "h")})
    if steep_state: out["at_steep"] = state(rows["tP"] + np.where(np.isfinite(t_steep), t_steep, 0.0))
    out["run"] = run; out["grp"] = grp; out["s_t"] = s_t; out["s_h"] = s_h; out["steep"] = np.isfinite(t_steep) & (t_steep < ti - rows["tP"]); out["t_steep"] = t_steep
    return out

# ---------- engine-exact 00:19 scoring ----------
OBS = {r["epoch_id"]: r for r in csv.DictReader(open(W + "/repo/Claude Science Project Sep 29/engine/data/variants/satcom-observations-bfo432.csv"))}
SD_BFO = float(OBS["m0019a"]["bfo_sd_hz"]); SD_BTO = float(OBS["m0019a"]["bto_sd_us"]); SD_BTO37 = float(OBS["m0019b"]["bto_sd_us"])
def legauss(lo, hi, nq):
    x, w = np.polynomial.legendre.leggauss(nq); return 0.5 * (lo + hi) + 0.5 * x * (hi - lo), w / w.sum()
SEC, WSEC = legauss(17.0, 130.0, 64); FMS, WFMS = legauss(0.0, 6.0, 16)
SEC0, WSEC0 = legauss(0.0, 130.0, 64)                  # zero-floor variant of the R1200-only offset (18:25 thread)
def kal(mean, var, pred, meas, sd):
    S = var + sd * sd; r = meas - (pred + mean); ll = -0.5 * (r * r / S + np.log(2 * np.pi * S)); K = var / S
    return ll, mean + K * r, var * (1 - K)
def bfo_ll(mean, var, p29, p37, use37, offset):
    if offset is None:
        l1, m1, v1 = kal(mean, var, p29, 182.0, SD_BFO); tot = l1
        if use37: l2, _, _ = kal(m1, v1, p37, -2.0, SD_BFO); tot = tot + l2
        return tot
    if offset in ("r1200", "r1200_0"):             # R600 as recorded; Holland start-up offset on the R1200 burst only
        l1, m1, v1 = kal(mean, var, p29, 182.0, SD_BFO); acc = np.full(np.shape(p29), -np.inf)
        for s2, ws in (zip(SEC, WSEC) if offset == "r1200" else zip(SEC0, WSEC0)):
            l2, _, _ = kal(m1, v1, p37, -2.0 - s2, SD_BFO); acc = np.logaddexp(acc, np.log(ws) + l2)
        return l1 + acc
    acc = np.full(np.shape(p29), -np.inf)          # running log-sum-exp: O(n) memory (was 1,024 x n terms held at once)
    for s2, ws in (zip(SEC0, WSEC0) if offset == "holland0" else zip(SEC, WSEC)):
        for d, wd in zip(FMS, WFMS):
            l1, m1, v1 = kal(mean, var, p29, 182.0 - (s2 + d), SD_BFO); l2, _, _ = kal(m1, v1, p37, -2.0 - s2, SD_BFO)
            acc = np.logaddexp(acc, np.log(ws * wd) + l1 + l2)
    return acc
def lag_logpdf(lag):
    with np.errstate(divide="ignore", invalid="ignore"):
        v = (SHAPE - 1) * np.log(lag) - lag / SCALE - SHAPE * np.log(SCALE) - gammaln(SHAPE)
    return np.where(np.isfinite(lag) & (lag > 0), v, -np.inf)
_trap = getattr(np, 'trapezoid', None) or np.trapz
_G = np.linspace(0, 1200, 12001); _apu = np.exp(-0.5 * ((_G - 60) / 15) ** 2) * (_G > 30); _apu /= _trap(_apu, _G)
_sdu = np.exp(-0.5 * ((_G - 60) / 10) ** 2) * (_G > 0); _sdu /= _trap(_sdu, _G)   # terminal about 60 s (ATSB 3 Dec 2015); 160 s was withdrawn
_two = np.convolve(_apu, _sdu)[:len(_G)] * (_G[1] - _G[0])
def lag_logpdf_two(lag):
    v = np.interp(lag, _G, _two, left=0, right=0)
    with np.errstate(divide="ignore"): return np.where(v > 0, np.log(v), -np.inf)
def cause_term(t_imp, tP, fo_final, lagf, pfe=None):
    alive = t_imp > T37; powered_0115 = (t_imp > T_LOI) & (~np.isfinite(fo_final) | (fo_final > T_LOI))
    base = np.where(alive & ~powered_0115, 0.0, -np.inf)
    C1 = lagf(T29 - tP) + base
    with np.errstate(divide="ignore", invalid="ignore"):
        surv = gammaincc(SHAPE, np.maximum(t_imp - fo_final, 0) / SCALE)
        C2 = -np.log(W_S) + base + np.where(np.isfinite(fo_final), np.log(surv), 0.0)
    pfe = CAUSE_FE if pfe is None else pfe
    return np.logaddexp(np.log(pfe) + C1, np.log(1.0 - pfe) + C2)
CAUSES = {"g75": (lag_logpdf, None), "g50": (lag_logpdf, 0.5), "two": (lag_logpdf_two, None)}   # g75 = headline (CAUSE_FE from the spec)


def Dpart(meta, g, prefix):
    """Per-row D-cell log-likelihood of the 00:19 data plus the structural survival factor, WITHOUT the log-on cause term
    (same columns as joined_v2.cells)."""
    obs = {r["epoch_id"]: r for r in csv.DictReader(open(J.SATCOM_CSV))}
    col = lambda k: np.where(np.isfinite(g("loglik:" + k)), g("loglik:" + k), -np.inf)
    sd = float(obs["m0019a"]["bto_sd_us"]); r = g("bto_residual_us:m0019a")
    r600 = np.where(np.isfinite(r), -0.5 * ((r / sd) ** 2 + np.log(2 * np.pi * sd ** 2)), -np.inf)
    base = col("m0011") if prefix else np.zeros(len(r))
    with np.errstate(divide="ignore"):
        surv = np.log1p(-np.clip(g("latent:inflight_p_breakup_to_m0019b"), 0, 1))
    D = {"D0": base, "D1": base + r600, "D2": col(prefix + "r600/no-offset"), "D3": col(prefix + "both/no-offset"), "D4": col(prefix + "both/startup-offset")}
    return D                                   # break-up factor removed (settling ruling)


def d5_stored(g, hpath, prefix, zero_floor=False):
    """R600 BTO + R600 BFO as recorded + R1200 BFO with Holland start-up offset, for stored engine rows, from the stored
    innovations (relative to the parent's prior bias mean) through the sequential bias chain; plus the survival factor."""
    bm, bv = parse_bias(hpath); par = g("parent").astype(int); M0, V0 = bm[par], bv[par]
    obs = {r["epoch_id"]: r for r in csv.DictReader(open(J.SATCOM_CSV))}; sdt = float(obs["m0019a"]["bto_sd_us"])
    N_ = lambda x, S: -0.5 * (x * x / S + np.log(2 * np.pi * S))
    m, v = M0.copy(), V0.copy()
    eps = ("m2315", "m0011") if prefix else ()
    try:
        [g(f"bfo_innovation_hz:{ep}") for ep in eps]
    except KeyError:
        return np.full(len(M0), -np.inf)               # single-arm compact runs: no 22:41 arm rows are used
    for ep in eps:                                     # core cruise bursts already in loglik:m0011; only update the bias here
        r = g(f"bfo_innovation_hz:{ep}") - (m - M0); S = v + SD_BFO ** 2; K = v / S; m = m + K * r; v = v * (1 - K)
    r29 = g("bfo_innovation_hz:m0019a") - (m - M0); S = v + SD_BFO ** 2; l29 = N_(r29, S); K = v / S; m1 = m + K * r29; v1 = v * (1 - K)
    i37 = g("bfo_innovation_hz:m0019b"); p37 = -2.0 - i37 - M0          # predicted BFO without bias
    acc = np.full(len(M0), -np.inf)
    for s2, ws in (zip(SEC0, WSEC0) if zero_floor else zip(SEC, WSEC)):
        rr = (-2.0 - s2) - (p37 + m1); acc = np.logaddexp(acc, np.log(ws) + N_(rr, v1 + SD_BFO ** 2))
    rb = g("bto_residual_us:m0019a"); bto = N_(rb, sdt ** 2)
    base = np.where(np.isfinite(g("loglik:m0011")), g("loglik:m0011"), -np.inf) if prefix else 0.0
    with np.errstate(divide="ignore"):
        surv = np.log1p(-np.clip(g("latent:inflight_p_breakup_to_m0019b"), 0, 1))
    out = base + bto + l29 + acc               # break-up factor removed
    return np.where(np.isfinite(out), out, -np.inf)

def d14_stored(g, hpath, prefix):
    """Both bursts with Holland's start-up offset, zero floor (R1200 offset U[0,130] Hz, R600 offset = that + U[0,6] Hz), for stored
    engine rows, from the stored innovations through the sequential bias chain (as d5_stored). R600 BTO included; R1200 BTO added by caller."""
    bm, bv = parse_bias(hpath); par = g("parent").astype(int); M0, V0 = bm[par], bv[par]
    obs = {r["epoch_id"]: r for r in csv.DictReader(open(J.SATCOM_CSV))}; sdt = float(obs["m0019a"]["bto_sd_us"])
    N_ = lambda x, S: -0.5 * (x * x / S + np.log(2 * np.pi * S))
    m, v = M0.copy(), V0.copy(); eps = ("m2315", "m0011") if prefix else ()
    try:
        [g(f"bfo_innovation_hz:{ep}") for ep in eps]
    except KeyError:
        return np.full(len(M0), -np.inf)
    for ep in eps:
        r = g(f"bfo_innovation_hz:{ep}") - (m - M0); S = v + SD_BFO ** 2; K = v / S; m = m + K * r; v = v * (1 - K)
    i29 = g("bfo_innovation_hz:m0019a") - (m - M0); p37 = -2.0 - g("bfo_innovation_hz:m0019b") - M0
    S = v + SD_BFO ** 2; K = v / S; v1 = v * (1 - K); acc = np.full(len(M0), -np.inf)
    for s2, ws in zip(SEC0, WSEC0):
        for d, wd in zip(FMS, WFMS):
            r29 = i29 - (s2 + d); m1 = m + K * r29
            acc = np.logaddexp(acc, np.log(ws * wd) + N_(r29, S) + N_((-2.0 - s2) - (p37 + m1), v1 + SD_BFO ** 2))
    bto = N_(g("bto_residual_us:m0019a"), sdt ** 2)
    base = np.where(np.isfinite(g("loglik:m0011")), g("loglik:m0011"), -np.inf) if prefix else 0.0
    out = base + bto + acc
    return np.where(np.isfinite(out), out, -np.inf)

def parse_bias(path):
    txt = gzip.open(path, "rt").read()
    m = np.array([float(x) for x in re.findall(r"\[row\.bias\]\s*\nmean_hz = (\S+)", txt)]); v = np.array([float(x) for x in re.findall(r"variance_hz2 = (\S+)", txt)])
    return m, v


def _cat(a, b):
    if isinstance(a, dict): return {k: _cat(a[k], b[k]) for k in a}
    return np.concatenate([np.asarray(a), np.asarray(b)])
def _take(a, ix):
    if isinstance(a, dict): return {k: _take(v, ix) for k, v in a.items()}
    return np.asarray(a)[ix]
def is_stage(rows, F, D, caus, ife_a1, ti, st29, st37, idx, bmean, bvar, Dst, R2):
    """Importance sampling of the alternate-configuration time stretch (exact, defensive mixture).
    Each alternate row (power loss before 00:19:29) is replaced by M replicates: donor drawn from its prior (uniform in group),
    ln s_t drawn from q = 0.25 prior + 0.75 g, where g is built from an approximate 00:19 BFO likelihood on a grid of ln s_t
    (vertical speed of the donor at the replayed phase, BFO slope from the row's own state). Weight p/q/M is exact, so the
    approximation affects efficiency only. Replicates are then flown and scored exactly like every other row."""
    from scipy.stats import t as tdist
    M = int(os.environ.get("A1GEN_IS_M", "8")); NG = int(os.environ.get("A1GEN_IS_NG", "960")); PF = float(os.environ.get("A1GEN_IS_PRIOR", "0.15"))
    sel = np.flatnonzero((F["grp"] > 0) & (rows["tP"] < T29)); n = len(sel)
    if n == 0: return rows, F, D, caus, ife_a1, ti, st29, st37, idx, {}
    c = K_INFL * S2K.S_ALT; lo, hi = np.log(ST_BOUNDS)
    Zt = tdist.cdf(hi / c, S2K.NU) - tdist.cdf(lo / c, S2K.NU)
    logp = lambda x: tdist.logpdf(x / c, S2K.NU) - np.log(c) - np.log(Zt)
    edges = np.linspace(lo, hi, NG + 1); xc = 0.5 * (edges[1:] + edges[:-1]); dx = edges[1] - edges[0]; sc = np.exp(xc)
    lp_c = logp(xc)
    # base BFO and slope per row from its own exactly flown state
    def bfo_at(st, ep, k, dv=0.0):
        return L.bfo_v(ep, st["lat"][k], st["lon"][k], np.clip(st["h"][k], 0, None), st["vn"][k], st["ve"][k], st["vu"][k] + dv)
    p29 = bfo_at(st29, "m0019a", sel); p37 = bfo_at(st37, "m0019b", sel)
    k29 = (bfo_at(st29, "m0019a", sel, 1000.0) - p29) / 1000.0; k37 = (bfo_at(st37, "m0019b", sel, 1000.0) - p37) / 1000.0
    vu29r, vu37r = st29["vu"][sel], st37["vu"][sel]
    lag29 = T29 - rows["tP"][sel]; lag37 = T37 - rows["tP"][sel]; h0 = rows["h0"][sel]
    grp = F["grp"][sel]; bm, bv = bmean[sel], bvar[sel]
    groups = {1: ALT_RUN, 2: ALT_STOP}
    cdfs = {}                                                          # (row, donor slot) -> cumulative g over grid
    for slot in (0, 1):
        G = np.zeros((n, NG), dtype=np.float32)
        for gk, lst in groups.items():
            kk = np.flatnonzero(grp == gk)
            if len(kk) == 0: continue
            r = lst[slot]; d = LIB[r]; m30 = d["t"] >= d["end"] - 30; vu_end = np.mean(d["vu"][m30])
            hc0 = np.interp(d["tau0"], d["t"], d["h"])
            for c0 in range(0, len(kk), 1000):
                ks = kk[c0:c0 + 1000]
                ta29 = d["tau0"] + lag29[ks, None] / sc[None, :]; ta37 = d["tau0"] + lag37[ks, None] / sc[None, :]
                v29 = np.where(ta29 <= d["end"], np.interp(ta29, d["t"], d["vu"]), vu_end)
                v37 = np.where(ta37 <= d["end"], np.interp(ta37, d["t"], d["vu"]), vu_end)
                h37 = np.interp(np.minimum(ta37, d["end"]), d["t"], d["h"]) + vu_end / 60 * np.maximum(ta37 - d["end"], 0)
                alive = (h0[ks, None] - sc[None, :] * (hc0 - h37)) > 0
                q29 = p29[ks, None] + k29[ks, None] * (v29 - vu29r[ks, None]); q37 = p37[ks, None] + k37[ks, None] * (v37 - vu37r[ks, None])
                l3 = bfo_ll(bm[ks, None], bv[ks, None], q29, q37, True, None)
                S29, S37 = 35.0 ** 2 + bv[ks, None] + SD_BFO ** 2, 33.0 ** 2 + bv[ks, None] + SD_BFO ** 2
                l4 = -0.5 * ((105.5 - q29 - bm[ks, None]) ** 2 / S29 + (-75.5 - q37 - bm[ks, None]) ** 2 / S37)
                g3 = np.where(alive, l3 + lp_c[None, :], -np.inf); g4 = np.where(alive, l4 + lp_c[None, :], -np.inf)
                def norm(gl):
                    mx = np.max(gl, axis=1, keepdims=True); ok = np.isfinite(mx[:, 0])
                    e = np.where(ok[:, None], np.exp(gl - np.where(ok[:, None], mx, 0)), 0.0); s = e.sum(1, keepdims=True)
                    return np.where(ok[:, None], e / np.maximum(s, 1e-300), 1.0 / NG)
                l5 = -0.5 * ((182.0 - q29 - bm[ks, None]) ** 2 / (bv[ks, None] + SD_BFO ** 2) + (-75.5 - q37 - bm[ks, None]) ** 2 / S37)
                g5 = np.where(alive, l5 + lp_c[None, :], -np.inf)
                G[ks] = (norm(g3) + norm(g4) + norm(g5)) / 3.0
        cdfs[slot] = np.cumsum(G, axis=1).astype(np.float32); del G
    # draw M replicates per row
    ridx = np.tile(sel, M); rowpos = np.tile(np.arange(n), M)
    slot = rng.integers(0, 2, M * n); runs = np.where(grp[rowpos] == 1, np.array(ALT_RUN)[slot], np.array(ALT_STOP)[slot])
    from_prior = rng.random(M * n) < PF
    x = np.empty(M * n)
    npr = from_prior.sum(); x[from_prior] = np.log(t_bounded(c, npr, *ST_BOUNDS))
    kq = np.flatnonzero(~from_prior); u = rng.random(len(kq)); cell = np.empty(len(kq), int)
    for sl in (0, 1):
        mm = np.flatnonzero(slot[kq] == sl)
        for c0 in range(0, len(mm), 20000):
            m = mm[c0:c0 + 20000]; C = cdfs[sl][rowpos[kq[m]]]
            cell[m] = np.minimum((C < u[m, None] * C[:, -1:]).sum(1), NG - 1)
    x[kq] = edges[cell] + rng.random(len(kq)) * dx
    gdens = np.empty(M * n)
    for sl in (0, 1):
        mm = np.flatnonzero(slot == sl)
        for c0 in range(0, len(mm), 20000):
            m = mm[c0:c0 + 20000]; C = cdfs[sl][rowpos[m]]; ci = np.clip(np.floor((x[m] - lo) / dx).astype(int), 0, NG - 1)
            mass = np.take_along_axis(C, ci[:, None], 1)[:, 0] - np.where(ci > 0, np.take_along_axis(C, np.maximum(ci - 1, 0)[:, None], 1)[:, 0], 0.0)
            gdens[m] = mass / dx
    lq = np.logaddexp(np.log(PF) + logp(x), np.log(1 - PF) + np.log(np.maximum(gdens, 1e-300)))
    logw = logp(x) - lq - np.log(M)
    # fly and score replicates in chunks
    times = {"m29": T29, "m37": T37, "m2106": T2106}; parts = []
    for c0 in range(0, M * n, 250000):
        ks = np.arange(c0, min(c0 + 250000, M * n)); rr = ridx[ks]
        rws = {k: v[rr] for k, v in rows.items()}
        Fr = fly(rws, times, run_override=runs[ks], st_override=np.exp(x[ks]))
        Dr, cr, ir, tr, s29, s37 = score(Fr, rws, bmean[rr], bvar[rr], {k: v[rr] for k, v in Dst.items()}, R2["ffinal"][idx[rr]])
        parts.append((rws, Fr, Dr, cr, ir, tr))
    rws = parts[0][0]; Fr = parts[0][1]; Dr = parts[0][2]; cr = parts[0][3]; ir = parts[0][4]; tr = parts[0][5]
    for p_ in parts[1:]:
        rws = _cat(rws, p_[0]); Fr = {k: _cat(Fr[k], p_[1][k]) for k in Fr}; Dr = _cat(Dr, p_[2]); cr = _cat(cr, p_[3]); ir = _cat(ir, p_[4]); tr = _cat(tr, p_[5])
    # extend S2 arrays: replicates appended, originals of replaced rows given zero weight
    base = len(R2["fam"]); newpos = base + np.arange(M * n); orig = idx[ridx]
    for key in ("fam", "sel", "lat", "lon", "arc", "timp", "cfg", "flown", "ffinal", "tP_n", "tP_a", "surv"):
        if key in R2 and np.ndim(R2[key]) == 1 and len(R2[key]) == base: R2[key] = np.r_[R2[key], np.asarray(R2[key])[orig]]
    lw_new = np.asarray(R2["lw"])[orig] + logw
    R2["lw"] = np.r_[R2["lw"], lw_new]; R2["lw"][idx[sel]] = -np.inf
    R2["cellsD"] = {k: np.r_[v, v[orig]] for k, v in R2["cellsD"].items()}
    R2["newc"] = {k: np.r_[v, v[orig]] for k, v in R2["newc"].items()}
    keepF = [k for k in F if k in Fr]
    F2 = {k: _cat(F[k], Fr[k]) for k in keepF}
    rows2 = {k: np.r_[rows[k], rws[k]] for k in rows}
    D2_ = _cat(D, Dr); c2_ = _cat(caus, cr); i2 = np.r_[ife_a1, ir]; t2 = np.r_[ti, tr]
    info = dict(is_rows=int(n), is_M=M, is_logw_q=[float(v) for v in np.quantile(logw + np.log(M), [0.01, 0.5, 0.99])], is_prior_frac=PF, is_grid=NG)
    return rows2, F2, D2_, c2_, i2, t2, F2["m29"], F2["m37"], np.r_[idx, newpos], info

def score(F, rows, bmean, bvar, Dst, ffinal):
    st29, st37 = F["m29"], F["m37"]
    def pred(st, ep):
        return L.bfo_v(ep, st["lat"], st["lon"], np.clip(st["h"], 0, None), st["vn"], st["ve"], st["vu"]), L.bto_v(ep, st["lat"], st["lon"], np.clip(st["h"], 0, None))
    p29, b29 = pred(st29, "m0019a"); p37, b37 = pred(st37, "m0019b")
    bto29 = -0.5 * (((18400.0 - b29) / SD_BTO) ** 2 + np.log(2 * np.pi * SD_BTO ** 2))
    bto37 = -0.5 * (((18380.0 - b37) / SD_BTO37) ** 2 + np.log(2 * np.pi * SD_BTO37 ** 2))   # corrected R1200 BTO (Davey), sd 43 us
    D = {"D0": np.zeros(len(rows["tP"])), "D1": bto29, "D2": bto29 + bfo_ll(bmean, bvar, p29, p37, False, None),
         "D3": bto29 + bfo_ll(bmean, bvar, p29, p37, True, None), "D4": bto29 + bfo_ll(bmean, bvar, p29, p37, True, "holland"),
         "D5": bto29 + bfo_ll(bmean, bvar, p29, p37, True, "r1200"),
         "D6": bto29 + bfo_ll(bmean, bvar, p29, p37, True, "r1200_0"),
         "D7": bto29 + bto37, "D8": bto29 + bto37 + bfo_ll(bmean, bvar, p29, p37, False, None)}
    for k_src, k_new in (("D3", "D9"), ("D4", "D10"), ("D5", "D11"), ("D6", "D12")): D[k_new] = D[k_src] + bto37   # both BTOs + the BFO cells
    D["D14"] = bto29 + bto37 + bfo_ll(bmean, bvar, p29, p37, True, "holland0")
    D["D13"] = np.zeros(len(rows["tP"]))                         # nothing after 00:11: no 00:19 data, no log-on term
    tP = rows["tP"]
    for k in ("D0", "D1", "D2"): D[k] = np.where(tP >= T29, Dst[k], D[k])        # powered at 00:19:29: stored engine value
    for k in ("D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "D11", "D12", "D13", "D14"): D[k] = np.where(tP >= T29, Dst[k], D[k])              # (T29 <= tP < T37 is rare; stored value used)
    ti = F["impact"]["t"]
    caus = {nm: cause_term(ti, tP, ffinal, lf, pf) for nm, (lf, pf) in CAUSES.items()}
    # IFE factor at 00:21:06: airborne, APU on (tP+60 s .. tP+60+840 s), link (gain >= 7 dBic at the analogue attitude)
    s21 = F["m2106"]; air21 = ti > T2106; apu = (T2106 > tP + 60) & (T2106 < tP + 900)
    link = np.ones(len(rows["tP"]), bool)   # attitude-dependent link set below
    # attitude: pitch from flight-path angle + 3 deg, bank from turn rate of the analogue (coordinated turn), heading from velocity
    gs = np.hypot(s21["ve"], s21["vn"]) * KT; gam = np.degrees(np.arctan2(s21["vu"] * 0.3048 / 60, np.maximum(gs, 1)))
    hd = np.degrees(np.arctan2(s21["ve"], s21["vn"])) % 360
    bank = np.nan_to_num(np.asarray(s21["bank"], float))
    th = np.radians(gam + 3); ph = np.radians(bank); ps = np.radians(hd)
    sat = L.sat_ned("m0019b", -37.0, 89.7)
    cp, sp, ct, st_, cf, sf = np.cos(ps), np.sin(ps), np.cos(th), np.sin(th), np.cos(ph), np.sin(ph)
    bx = ct*cp*sat[0] + ct*sp*sat[1] - st_*sat[2]
    by = (sf*st_*cp - cf*sp)*sat[0] + (sf*st_*sp + cf*cp)*sat[1] + sf*ct*sat[2]
    bz = (cf*st_*cp + sf*sp)*sat[0] + (cf*st_*sp - sf*cp)*sat[1] + cf*ct*sat[2]
    ang = lambda N: np.degrees(np.arccos(np.clip(bx*N[0] + by*N[1] + bz*N[2], -1, 1)))
    gmax = np.maximum(L.G(ang(L.NS)), L.G(ang(L.NP))); link = gmax >= 7.0
    ife_a1 = np.log1p(-0.5 * (air21 & apu & link))
    return D, caus, ife_a1, ti, st29, st37

def main():
    r2241, r0011, h2241, h0011, outp, seed = sys.argv[1:7]; seed = int(seed)
    T0_, T1_ = J.stop_unix(h2241), J.stop_unix(h0011); dlnz = J.stop_lnz(h0011) - J.stop_lnz(h2241)
    m1, g1, _ = J.load(r2241, seed); m2, g2, _ = J.load(r0011, seed)
    p1 = J.Prior(m1["config"]["hypotheses"]["end-of-flight"]["onset"]); p2 = J.Prior(m2["config"]["hypotheses"]["end-of-flight"]["onset"])
    # joiner selection and prior-ratio weights (as joined_v2.py)
    tk1 = g1("takeover_unix_s"); fo1 = g1("latent:realised_flameout_unix_s"); mech1 = g1("latent:onset_mechanism")
    s1 = (tk1 < T1_) & ((mech1 == 0) | (mech1 == 1)) & ~(np.isfinite(fo1) & (fo1 < J.T_M0011_BURST))
    tau1 = g1("latent:onset_unix_s"); P1 = tau1 + g1("latent:predicted_endurance_at_onset_s")
    with np.errstate(invalid="ignore"):
        lr1 = np.where(s1, p2.log_density(mech1, tau1, P1, T0_) - p1.log_density(mech1, tau1, P1, T0_), -np.inf)
    s1 = s1 & np.isfinite(lr1); lw1 = np.log(g1("weight")) + np.where(s1, lr1, 0.0)
    tau2 = g2("latent:onset_unix_s"); P2 = tau2 + g2("latent:predicted_endurance_at_onset_s"); mech2 = g2("latent:onset_mechanism")
    # FIX (3 Nov 2026): the alternate configuration (ap_loss_config 2) moves a flame-out-associated onset to the FIRST flame-out,
    # before the predicted exhaustion P. The onset prior of that mechanism is defined at P, so evaluating it at the moved onset gave
    # -inf and silently dropped 99.99 % of alternate rows (A1 and A2) in joined_v2.py. The configuration shift is a deterministic
    # consequence of the drawn configuration, not part of the onset prior: evaluate the prior at P for flame-out-associated rows.
    tau2 = np.where(mech2 == 2, P2, tau2)
    with np.errstate(invalid="ignore"):
        lr = p2.log_density(mech2, tau2, P2, T0_) - p2.log_density(mech2, tau2, P2, T1_)
    s2 = np.isfinite(lr) & (P2 >= T1_); lw2 = np.log(g2("weight")) + np.where(s2, lr, -np.inf)
    if os.environ.get("A1GEN_ONLY_FE") == "1":                       # single-arm mode: fuel exhaustion in cruise only (A1 + A2)
        s2 = s2 & (mech2 == 2); lw2 = np.where(s2, lw2, -np.inf)
    old1 = J.cells(m1, g1, "m0011+"); old2 = J.cells(m2, g2, "")
    lab1 = family_labels(g1("latent:onset_mechanism"), g1("latent:control_realised"), g1("latent:recovery_attempted")); lab2 = family_labels(g2("latent:onset_mechanism"), g2("latent:control_realised"), g2("latent:recovery_attempted"))
    fam1, fam2 = lab1["family4_code"], lab2["family4_code"]
    def old_cause(g):
        logon = m2["config"]["hypotheses"]["end-of-flight"]["logon"]; fo = g("latent:realised_flameout_unix_s"); lag = logon["logon_unix_s"] - fo
        lfe = lag_logpdf(lag); C1 = lfe + J.constraint_log_factor(g, logon, "fuel-exhaustion", "unpowered"); C2 = -np.log(W_S) + J.constraint_log_factor(g, logon, "other", "silent")
        surv = np.log1p(-np.clip(g("latent:inflight_p_breakup_to_m0019b"), 0, 1))
        return np.logaddexp(np.log(0.75) + C1, np.log(0.25) + C2), surv
    res = {}
    for arm, (g, old, fam, lw, sel) in {"S1": (g1, old1, fam1, lw1, s1), "S2": (g2, old2, fam2, lw2, s2)}.items():
        oc, surv = old_cause(g)
        cfg = g("latent:ap_loss_config"); ffirst = g("latent:first_flameout_unix_s"); ffinal = g("latent:realised_flameout_unix_s"); timp = g("unix_s")
        tP_n = ffinal; tP_a = np.where(np.isfinite(ffirst), ffirst, ffinal)
        newc = {}; newc2 = {}
        for nm, (lf, pf) in CAUSES.items():
            cn = cause_term(timp, tP_n, ffinal, lf, pf); ca = cause_term(timp, tP_a, ffinal, lf, pf)
            # A2 rows: configuration drawn by the engine (1 normal, 2 alternate); B rows (no draw): mixture 0.5/0.5
            mix = np.logaddexp(np.log(0.5) + cn, np.log(0.5) + ca)
            newc[nm] = np.where(cfg == 2, ca, np.where(cfg == 1, cn, mix))
            newc2[nm] = (cn, ca)
        cellsD = Dpart(m1 if arm == 'S1' else m2, g, 'm0011+' if arm == 'S1' else '')
        cellsD["D5"] = d5_stored(g, h2241 if arm == 'S1' else h0011, arm == 'S1')
        cellsD["D6"] = d5_stored(g, h2241 if arm == 'S1' else h0011, arm == 'S1', zero_floor=True)
        cellsD["D14"] = d14_stored(g, h2241 if arm == 'S1' else h0011, arm == 'S1')
        _r37 = g("bto_residual_us:m0019b"); _b37 = np.where(np.isfinite(_r37), -0.5 * ((_r37 / SD_BTO37) ** 2 + np.log(2 * np.pi * SD_BTO37 ** 2)), -np.inf)
        cellsD["D7"] = cellsD["D1"] + _b37; cellsD["D8"] = cellsD["D2"] + _b37
        for k_src, k_new in (("D3", "D9"), ("D4", "D10"), ("D5", "D11"), ("D6", "D12")): cellsD[k_new] = cellsD[k_src] + _b37
        cellsD["D14"] = cellsD["D14"] + _b37
        _m11 = g("loglik:m0011") if arm == 'S1' else None
        cellsD["D13"] = np.where(np.isfinite(_m11), _m11, -np.inf) if arm == 'S1' else np.zeros(len(_r37))   # data to 00:11 only, no survival factor
        res[arm] = dict(g=g, fam=fam, lw=lw, sel=sel, cellsD=cellsD, newc=newc, newc2=newc2, cfg=cfg, surv=surv,
                        flown=np.isfinite(g("latent:free_dynamics_started_s")), lat=g("latent_lat") if False else g("latitude_deg"), lon=g("longitude_deg"),
                        arc=g("arc_distance_nm"), timp=timp, tP_n=tP_n, tP_a=tP_a, ffinal=ffinal)
    # ---- A1 re-flight (S2 only) ----
    R2 = res["S2"]; a1 = (R2["fam"] == 1) & R2["sel"]
    idx = np.flatnonzero(a1); g = g2
    rows = dict(tP=g("takeover_unix_s")[idx], lat0=g("takeover_latitude_deg")[idx], lon0=g("takeover_longitude_deg")[idx], h0=g("takeover_altitude_ft")[idx],
                vE=g("latent:takeover_ground_velocity_east_mps")[idx], vN=g("latent:takeover_ground_velocity_north_mps")[idx],
                K=np.where(g("latent:ap_loss_config")[idx] == 2, 2, 1), gap=g("latent:predicted_endurance_at_onset_s")[idx], mass=g("mass_kg")[idx])
    bm, bv = parse_bias(h0011); par = g("parent")[idx].astype(int); bmean, bvar = bm[par], bv[par]
    F = fly(rows, {"m29": T29, "m37": T37, "m2106": T2106})
    Dst = {k: R2["cellsD"][k][idx] for k in R2["cellsD"]}
    D, caus, ife_a1, ti, st29, st37 = score(F, rows, bmean, bvar, Dst, R2["ffinal"][idx])
    tP = rows["tP"]
    if SPREAD == "v2" and os.environ.get("A1GEN_IS", "1") == "1":
        rows, F, D, caus, ife_a1, ti, st29, st37, idx, isinfo = is_stage(rows, F, D, caus, ife_a1, ti, st29, st37, idx, bmean, bvar, Dst, R2)
        tP = rows["tP"]
    newA1 = {nm: {k: D[k] + (0.0 if k == "D13" else caus[nm]) for k in D} for nm in caus}
    # ---- assemble per-cell log weights for the joined estimator ----
    S1, S2 = res["S1"], res["S2"]
    out = dict(seed=seed, T0=T0_, T1=T1_, dlnZ_filter=dlnz, n_a1=int(len(idx)), sig_t=SIG_T, sig_h=SIG_H, k_infl=K_INFL, spread=SPREAD, is_info=(isinfo if 'isinfo' in dir() else {}), steep_prior_share_normal=float(F["steep"][F["grp"] == 0].mean()) if (F["grp"] == 0).any() else None, s_t_q=[float(x) for x in np.quantile(F["s_t"][F["grp"] > 0], [0.05, 0.5, 0.95])] if (F["grp"] > 0).any() else None, cells={})
    fam = np.r_[S1["fam"], S2["fam"]]; lat = np.r_[S1["lat"], S2["lat"]].copy(); arc = np.r_[S1["arc"], S2["arc"]].copy(); tim = np.r_[S1["timp"], S2["timp"]].copy()
    cfgK = np.r_[np.where(S1["cfg"] == 2, 2, np.where(S1["cfg"] == 1, 1, 0)), np.where(S2["cfg"] == 2, 2, np.where(S2["cfg"] == 1, 1, 0))]
    flown = np.r_[S1["flown"], S2["flown"]]
    j = len(S1["fam"]) + idx                                               # A1 positions in the joined arrays
    lon = np.r_[S1["lon"], S2["lon"]].copy(); lat[j] = F["impact"]["lat"]; lon[j] = F["impact"]["lon"]; tim[j] = ti
    # signed distance from the 7th arc for the new A1 impacts: BTO residual / local gradient (as engine)
    btoI = L.bto_v("m0019a", F["impact"]["lat"], F["impact"]["lon"], np.zeros(len(idx)))
    btoI2 = L.bto_v("m0019a", F["impact"]["lat"] + 0.01, F["impact"]["lon"], np.zeros(len(idx))); btoI3 = L.bto_v("m0019a", F["impact"]["lat"], F["impact"]["lon"] + 0.01, np.zeros(len(idx)))
    grad = np.hypot((btoI2 - btoI) / (0.01 * 60), (btoI3 - btoI) / (0.01 * 60 * np.cos(np.radians(F["impact"]["lat"]))))
    arc[j] = (btoI - 18400.0) / grad
    ke = 0.5 * rows["mass"] * ((F["impact"]["ve"] ** 2 + F["impact"]["vn"] ** 2) * KT ** 2 + (F["impact"]["vu"] * 0.3048 / 60) ** 2)
    variants = {"headline": ("gamma", False, False), "two_stage_delay": ("two", False, False), "no_lost_control": ("gamma", True, False), "ife_factor": ("gamma", False, True)}
    dumps = {}
    for vn_, (lagname, drop_lost, ife) in variants.items():
        for k in S1["cellsD"]:
            c1 = S1["cellsD"][k] + (0.0 if k == "D13" else S1["newc"][lagname]); c2 = S2["cellsD"][k] + (0.0 if k == "D13" else S2["newc"][lagname])
            c2 = c2.copy(); c2[idx] = newA1[lagname][k]
            lwk = np.r_[np.where(S1["sel"], S1["lw"] + c1, -np.inf), S2["lw"] + dlnz + c2]
            if drop_lost: lwk = np.where(np.isin(fam, (2, 3)) & flown, -np.inf, lwk)
            if ife:
                adj = np.zeros(len(lwk)); air = (tim > T2106); apu_all = np.ones(len(lwk), bool)
                adj = np.where(np.isin(fam, (2, 3)), np.log1p(-0.5 * air), adj); adj[j] = ife_a1; lwk = lwk + adj
            fin = np.isfinite(lwk); s_ = lwk[fin].max(); p = np.where(fin, np.exp(lwk - s_), 0); Z = p.sum(); p /= Z
            cell = dict(lnZ=float(np.log(Z) + s_), ess=float(1 / np.sum(p * p)))
            for fname, codes in (("A1", (1,)), ("A2", (2,)), ("B", (3,))):
                kk = np.isin(fam, codes); sh = p[kk].sum(); cell[fname] = dict(share=float(sh), ess=float(sh ** 2 / max(np.sum(p[kk] ** 2), 1e-300)))
                if fname in ("A1", "A2"):
                    cell[fname]["alt_share_within"] = float(p[kk & (cfgK == 2)].sum() / max(sh, 1e-300))
            # configuration split for B (mixture): weight under each K
            if True:
                kb1 = np.flatnonzero(S1["fam"] == 3); kb2 = np.flatnonzero(S2["fam"] == 3)
                def kshare(S, kb, lwS, off):
                    cn, ca = S["newc2"][lagname]; base = (lwS + S["cellsD"][k])[kb]
                    return base + np.log(0.5) + cn[kb], base + np.log(0.5) + ca[kb]
                n1, a1_ = kshare(S1, kb1[S1["sel"][kb1]], S1["lw"], 0); n2, a2_ = kshare(S2, kb2, S2["lw"] + dlnz, 0)
                ln_n = logsumexp(np.r_[n1, n2]) if len(n1) + len(n2) else -np.inf; ln_a = logsumexp(np.r_[a1_, a2_]) if len(a1_) + len(a2_) else -np.inf
                cell["B"]["alt_share_within"] = float(1 / (1 + np.exp(ln_n - ln_a))) if np.isfinite(ln_a) else 0.0
            kk = p > 0; o = np.argsort(lat[kk]); cs = np.cumsum(p[kk][o]); cell["lat_q05_q50_q95"] = [float(lat[kk][o][np.searchsorted(cs, q)]) for q in (0.05, 0.5, 0.95)]
            out["cells"].setdefault(vn_, {})[k] = cell
            if vn_ == "headline":
                pick = rng.choice(len(p), size=6000, p=p)
                dumps[k] = np.c_[lat[pick], arc[pick], (tim[pick] - T29) / 60, fam[pick], cfgK[pick], lon[pick]]   # col 5 = lon (added 6 Nov)
    # A1 diagnostics
    a1w = np.exp(S2["lw"][idx] + dlnz + newA1["gamma"]["D3"] - np.max(S2["lw"][idx] + dlnz + newA1["gamma"]["D3"]))
    out["a1_diag"] = dict(group_share_prior={str(gk): float(np.mean(F["grp"] == gk)) for gk in (0, 1, 2)},
                          ke_GJ_q=[float(x) for x in np.nanpercentile(ke / 1e9, [5, 50, 95])], impact_min_after_tP_q=[float(x) for x in np.percentile((ti - tP) / 60, [5, 50, 95])],
                          vs29_q=[float(x) for x in np.percentile(st29["vu"], [5, 50, 95])], vs37_q=[float(x) for x in np.percentile(st37["vu"], [5, 50, 95])])
    np.savez_compressed(outp + ".npz", **dumps, a1_ke=ke.astype(np.float32), a1_lat=F["impact"]["lat"].astype(np.float32), a1_t=(ti - T29).astype(np.float32),
                        a1_grp=F["grp"].astype(np.int8), a1_st=F["s_t"].astype(np.float32), a1_sh=F["s_h"].astype(np.float32), a1_steep=F["steep"], a1_tP=(rows["tP"] - T29).astype(np.float32), a1_vs29=st29["vu"].astype(np.float32), a1_vs37=st37["vu"].astype(np.float32), a1_tsteep=(F["t_steep"]).astype(np.float32), a1_run=F["run"].astype(np.int8), a1_w_prior=np.exp(S2["lw"][idx] - S2["lw"][idx].max()).astype(np.float32),
                        a1_D={k: v.astype(np.float32) for k, v in D.items()} if False else np.zeros(1), a1_D3=(D["D3"] + caus["gamma"]).astype(np.float32), a1_D0=caus["gamma"].astype(np.float32),
                        a1_D2=(D["D2"] + caus["gamma"]).astype(np.float32), a1_D4=(D["D4"] + caus["gamma"]).astype(np.float32), a1_D1=(D["D1"] + caus["gamma"]).astype(np.float32))
    json.dump(out, open(outp + ".json", "w"), indent=1)
    print(json.dumps({k: out[k] for k in ("seed", "n_a1", "sig_t", "sig_h")}))
    for k, c in out["cells"]["headline"].items():
        print(k, "lnZ %.3f A1/A2/B %.3f/%.3f/%.3f  alt|A1 %.2f alt|A2 %.2f alt|B %.2f lat50 %.2f" % (c["lnZ"], c["A1"]["share"], c["A2"]["share"], c["B"]["share"], c["A1"]["alt_share_within"], c["A2"]["alt_share_within"], c["B"]["alt_share_within"], c["lat_q05_q50_q95"][1]))
if __name__ == "__main__":
    main()
