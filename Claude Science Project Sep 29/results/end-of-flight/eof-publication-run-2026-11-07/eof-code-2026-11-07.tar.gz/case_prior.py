"""Hierarchical lognormal prior for the dive build-up, fitted to the real accident cases and the Boeing 777 simulations.
Classes by crew input during the build-up: 'noinput' (no effective crew input: Adam Air 574, China Airlines 006, Boeing 777
alternate-power simulations 3, 4, 6, 10) and 'active' (crew input during the build-up). Steady descents and stalls do not reach a
dive and inform the non-dive (glide) family, not this kernel. Model per quantity: log y_i ~ N(mu_c, tau^2 + s_i^2),
mu_c ~ N(mu0, omega^2); mu0 ~ N(0, 3^2), omega, tau ~ HalfNormal(1). Random-walk Metropolis. Writes case-prior.json and the
leave-one-out test (pre-registered Test A)."""
import json, sys, numpy as np
from scipy.stats import norm
RNG = np.random.default_rng(20261107)
# (case, class, value, log-sd by data grade, source)
A8 = [("EgyptAir 990", "active", 1.08, 0.10, "master table 76db848a (NTSB AAB-02/01 rebuild)"),
      ("Atlas Air 3591", "active", 0.61, 0.20, "master table (estimate)"),
      ("SilkAir 185", "active", 0.94, 0.20, "master table (estimate, radar)"),
      ("flydubai 981", "active", 2.0, 0.20, "master table (estimate)"),
      ("Saratov 703", "active", 1.0, 0.20, "master table (estimate)"),
      ("Qantas 72", "active", 1.8, 0.20, "master table (estimate)"),
      ("TWA 841", "active", 0.88, 0.20, "master table (estimate)"),
      ("AirAsia 8501", "active", 0.93, 0.10, "master table (KNKT Fig. 22 digitised)"),
      ("China Eastern 5735", "active", 1.27, 0.10, "master table (NTSB DCA22WA102, integrated)"),
      ("Lauda Air 004", "active", 1.10, 0.20, "master table (estimate)"),
      ("Adam Air 574", "noinput", 1.45, 0.10, "master table (KNKT text values)"),
      ("Boeing 777 simulation 3", "noinput", 1.209, 0.10, "trace, max 8-s mean before first 15,000 ft/min + 10 s"),
      ("Boeing 777 simulation 4", "noinput", 0.455, 0.10, "trace"),
      ("Boeing 777 simulation 6", "noinput", 0.284, 0.10, "trace"),
      ("Boeing 777 simulation 10", "noinput", 0.434, 0.10, "trace")]
T15 = [("EgyptAir 990", "active", 12.0, 0.15, "uncontrolled-dive-cases f8cb4668: about 10-14 s"),
       ("Atlas Air 3591", "active", 13.0, 0.15, "f8cb4668: about 13 s (11-14)"),
       ("AirAsia 8501", "active", 9.0, 0.10, "dive-cases-additions 417b9f53: 9 s (KNKT Fig. 22)"),
       ("China Eastern 5735", "active", 8.5, 0.10, "417b9f53: about 8.5 s after autopilot disconnect"),
       ("TWA 841", "active", 18.5, 0.10, "f8cb4668: about 17-20 s"),
       ("Adam Air 574", "noinput", 15.0, 0.15, "piloted-dive-cases 3fd166a5: about 15 s after descent start"),
       ("China Airlines 006", "noinput", 70.0, 0.10, "f8cb4668: about 61-79 s from start of roll-off"),
       ("Boeing 777 simulation 3", "noinput", 265.0, 0.10, "trace: descent above pre-onset + 1,500 ft/min to 15,000 ft/min"),
       ("Boeing 777 simulation 4", "noinput", 143.0, 0.10, "trace"),
       ("Boeing 777 simulation 6", "noinput", 129.0, 0.10, "trace"),
       ("Boeing 777 simulation 10", "noinput", 146.0, 0.10, "trace")]
DON = [("Boeing 777 simulation 3", "noinput", 40.0, 0.10, "trace: first flame-out to descent onset"),
       ("Boeing 777 simulation 4", "noinput", 25.0, 0.10, "trace"),
       ("Boeing 777 simulation 6", "noinput", 28.0, 0.10, "trace"),
       ("Boeing 777 simulation 10", "noinput", 25.0, 0.10, "trace"),
       ("Adam Air 574", "noinput", 39.6, 0.10, "3fd166a5: autopilot disengage 06:57:36 to descent start 06:58:15.6"),
       ("China Airlines 006", "noinput", 68.0, 0.15, "f8cb4668: autopilot held about 61-76 s after No. 4 flame-out")]
CL = ["noinput", "active"]

def fit(data, n_iter=60000, burn=10000):
    y = np.log([d[2] for d in data]); s = np.array([d[3] for d in data]); c = np.array([CL.index(d[1]) for d in data])
    present = sorted(set(c)); two = len(present) == 2
    def logpost(th):
        mu = th[:2]; mu0, lw, lt = th[2], th[3], th[4]; om, ta = np.exp(lw), np.exp(lt)
        v = ta ** 2 + s ** 2
        lp = np.sum(norm.logpdf(y, mu[c], np.sqrt(v)))
        lp += norm.logpdf(mu0, 0, 3) + (np.sum(norm.logpdf(mu, mu0, om)) if two else norm.logpdf(mu[present[0]], mu0, om) + norm.logpdf(mu[1 - present[0]], mu0, om))
        lp += norm.logpdf(om, 0, 1) + lw + norm.logpdf(ta, 0, 1) + lt   # half-normal on scale, Jacobian of log
        return lp
    th = np.array([y[c == 0].mean() if (c == 0).any() else y.mean(), y[c == 1].mean() if (c == 1).any() else y.mean(), y.mean(), np.log(0.5), np.log(0.5)])
    lp = logpost(th); step = np.array([0.15, 0.15, 0.3, 0.3, 0.2]); keep = []; acc = 0
    for i in range(n_iter):
        pr = th + step * RNG.standard_normal(5); lpp = logpost(pr)
        if np.log(RNG.random()) < lpp - lp: th, lp = pr, lpp; acc += 1
        if i >= burn and i % 10 == 0: keep.append(th.copy())
    K = np.array(keep); return dict(mu_noinput=K[:, 0], mu_active=K[:, 1], mu0=K[:, 2], omega=np.exp(K[:, 3]), tau=np.exp(K[:, 4]), acc=acc / n_iter)

def pit(post, cls, yv, sv):
    mu = post["mu_" + cls]; sd = np.sqrt(post["tau"] ** 2 + sv ** 2); return float(np.mean(norm.cdf((np.log(yv) - mu) / sd)))

def main(out="case-prior.json", exclude=None):
    res = {"model": __doc__, "quantities": {}}
    for name, data in (("a8_g", A8), ("t15_s", T15), ("onset_delay_s", DON)):
        dd = [d for d in data if d[0] != exclude]
        P = fit(dd)
        q = {cls: [float(np.exp(np.quantile(P["mu_" + cls] + P["tau"] * RNG.standard_normal(len(P["tau"])), x))) for x in (0.05, 0.5, 0.95)] for cls in CL}
        res["quantities"][name] = dict(data=[list(d) for d in dd], acceptance=P["acc"],
                                       draws={k: P[k][::5].tolist() for k in ("mu_noinput", "mu_active", "tau")}, predictive_q05_q50_q95=q)
    if exclude is None:
        loo = {}
        for name, data in (("a8_g", A8), ("t15_s", T15), ("onset_delay_s", DON)):
            rows = []
            for i, d in enumerate(data):
                P = fit([x for j, x in enumerate(data) if j != i], n_iter=30000, burn=5000)
                rows.append(dict(case=d[0], cls=d[1], value=d[2], pit=pit(P, d[1], d[2], d[3])))
            out_n = sum(1 for r in rows if r["pit"] < 0.025 or r["pit"] > 0.975)
            loo[name] = dict(rows=rows, outside_95=out_n, n=len(rows), passed=bool(out_n <= 2))
        res["loo_test_A"] = loo
    json.dump(res, open(out, "w"), indent=1)
    return res

if __name__ == "__main__":
    r = main()
    for k, v in r["quantities"].items(): print(k, v["predictive_q05_q50_q95"], "acc %.2f" % v["acceptance"])
    for k, v in r["loo_test_A"].items(): print(k, "outside 95%:", v["outside_95"], "of", v["n"], "PASS" if v["passed"] else "FAIL", [(x["case"], round(x["pit"], 3)) for x in v["rows"]])
