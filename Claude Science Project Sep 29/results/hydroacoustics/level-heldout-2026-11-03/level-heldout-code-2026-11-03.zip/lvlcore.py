"""Held-out level tests of tl-chain-2026-10-27 (L1) and path-class level correction. 3 Nov 2026.
Pre-registration: level-heldout-prereg-2026-11-03.md (artifact bba2e3a7, v2 a8543449)."""
import numpy as np, pandas as pd, sqlite3, os
from scipy.stats import norm
from scipy.linalg import cho_factor, cho_solve
A='/Users/pete/.claude-science/orgs/9db41e8b-db54-4736-82b9-d77e2a9ad222/artifacts/proj_9cc1a5a85f63'
HERE=os.path.dirname(os.path.abspath(__file__))
IO=os.path.join(HERE,'io/indian-ocean-retest-run-2026-10-27/tables')
PSI=f'{A}/62c14bec-89bb-4434-9666-61f71a5cd6b7/v97e0f6e3_path-sections-index.csv'
DB=f'{A}/b3b0fe8f-b907-4214-9c02-18f9a4bf778c/v321ea0f6_hydro_data.sqlite'
ATL=f'{A}/f04a727c-placeholder'  # resolved at runtime via path arg
CLASSES=['clear deep path','ridge near the channel axis','ridge above the channel axis','blocked']
PRIOR={'b':30.0**2,'s':10.0**2,'a':100.0**2}
AIRGUN_SLOPE_SD=1.5; RECIP=1.2; N_EFF_BANDS=10
FAM_SRC={'FSST':4.978431469398728,'SJ':2.5985970746301783}   # 28 Oct sigma table, source-model spread (H0 col)
SRC_SLOPE_SD={}   # POST HOC sensitivity: family -> dB/oct source-shape slope sd (empty = prereg)

def build_rows(atl_csv):
    psi=pd.read_csv(PSI); pc=dict(zip(psi.name,psi.path_class)); rows=[]
    add=lambda **k: rows.append(k)
    sus=pd.read_csv(f'{IO}/sus_bands_frozen_chain.csv'); u=sus[sus.variant=='base']
    # observation (reading) sd of SUS rows: pooled residual sd^2 - band^2 - source^2 (27 Oct pooled table)
    pr=pd.read_csv(os.path.join(HERE,'me/model-error-2026-10-28/tables/pooled-residuals-all-cases.csv'))
    ps=pr[(pr.primary==True)&(pr.seabed_variant=='L1')]
    m=u.merge(ps[['case','station','band_hz','residual_sd_db']],left_on=['shot','station','fc_hz'],right_on=['case','station','band_hz'],how='left')
    obs={(x.shot,x.station,x.fc_hz):np.sqrt(max(x.residual_sd_db**2-x.band_sd_db**2-x.source_sd_db**2,0)) for _,x in m.iterrows()}
    for _,x in u.iterrows():
        path=f"{x.site}-H01W1_2003" if x.station=='H01W' else f"{x.site}-{x.station}"
        known=x.shot!='A11sus'
        if not known and x.station=='H08S': rt,nt='excluded','A11 to Diego Garcia South is land-blocked; TL from N x 2D corridor, not the 2D chain'
        elif not known: rt,nt='free_level','A11 charge size unknown; level free, slope only'
        else: rt,nt='level','route B primary; route A in r_alt_db'
        add(family='SUS 2003',event=x.shot,unit='SUS 2003',row_type=rt,station=x.station,station2='',path=path,path2='',
            path_class=pc.get(path,'?'),path_class2='',fc_hz=x.fc_hz,r_db=x.r_B_db,r_alt_db=x.r_A_db,alt_label='route A (Gaspin & Shuler scaled)',
            obs_sd_db=obs[(x.shot,x.station,x.fc_hz)],band_sd_db=np.hypot(x.band_sd_db,RECIP),
            src_sd_db=np.hypot(x.source_sd_db,(x.r_A_db-x.r_B_db)/2) if known else 0.0,charge_sd_db=1.0 if known else 0.0,
            source_model='SUS 1.8 lb, route B re-built pulse',group=x.shot if rt=='free_level' else '',obs_snr_db=x.obs_snr_db,note=nt)
    at=pd.read_csv(atl_csv); a1=at[(at.seabed_variant=='L1')&(at.primary==True)]
    for _,x in a1.iterrows():
        c=x.case
        if c.startswith('FSST'): fam,unit,src=('Ship shock trials 2016' if '2016' in c else 'Ship shock trials 2021'),'Ship shock trials',FAM_SRC['FSST']
        elif 'calibration charge' in c: fam,unit,src='San Juan charge 2017','San Juan charge',FAM_SRC['SJ']
        elif 'loss event' in c: fam,unit,src='San Juan loss event 2017','San Juan loss event',0
        elif 'F-35A' in c: fam,unit,src='F-35A crash 2019','F-35A crash',0
        else: continue
        srcfam='Ship shock trials' if c.startswith('FSST') else fam   # one source model for 2016 and 2021
        if x.test_type=='two_sided':
            add(family=srcfam,subfamily=fam,event=c,unit=unit,row_type='level',station=x.station,station2='',path=x.tl_name,path2='',path_class=pc.get(x.tl_name,'?'),path_class2='',
                fc_hz=x.band_hz,r_db=x.residual_db,r_alt_db=np.nan,alt_label='',obs_sd_db=x.meas_sd_db,band_sd_db=np.hypot(x.tl_band_sd_db,RECIP),
                src_sd_db=src,charge_sd_db=1.0,source_model=f'{x.source_model}, {x.src_depth_m:g} m',group='',obs_snr_db=x.snr_db,note='')
        elif x.test_type=='difference':
            dup=unit in ('Ship shock trials','San Juan charge')
            pN,pS=x.tl_name.split('/')
            add(family=srcfam,subfamily=fam,event=c,unit=unit,row_type='not_used_duplicate' if dup else 'difference',station=x.station.split('-')[0],station2=x.station.split('-')[1],
                path=pS,path2=pN,path_class=pc.get(pS,'?'),path_class2=pc.get(pN,'?'),fc_hz=x.band_hz,r_db=x.residual_db,r_alt_db=np.nan,alt_label='',
                obs_sd_db=x.meas_sd_db,band_sd_db=np.sqrt(max(x.residual_sd_db**2-x.meas_sd_db**2,0)),src_sd_db=0.0,charge_sd_db=0.0,source_model='cancels',
                group='',obs_snr_db=x.snr_db,note='implied by the level rows; not used twice' if dup else 'south minus north; source cancels')
    sh=pd.read_csv(f'{IO}/airgun_shape_bands.csv'); sh=sh[sh.seabed.str.startswith('L1')]
    for _,x in sh.iterrows():
        path=f"{x.case}-H01W_2001" if x.station=='H01W' else f"{x.case}-{x.station}"
        add(family='Airguns 2001 (Fig. 23)',event=x.case,unit='Airguns 2001',row_type='free_level',station=x.station,station2='',path=path,path2='',path_class=pc.get(path,'?'),path_class2='',
            fc_hz=x.fc_hz,r_db=x.r_db,r_alt_db=np.nan,alt_label='',obs_sd_db=2.0,band_sd_db=np.hypot(x.band_sd_db,RECIP),src_sd_db=0.0,charge_sd_db=0.0,
            source_model='EW0112 near-field shape; level free per site',group=x.case,obs_snr_db=np.nan,note=f'Fig. 23 read; obs sd 2 dB = figure-read uncertainty')
    fl=pd.read_csv(f'{IO}/airgun_detection_floor_bands.csv'); fl=fl[fl.seabed=='L1']
    for _,x in fl.iterrows():
        path=f"{x.case}-H01W_2001" if x.station=='H01W' else f"{x.case}-{x.station}"
        add(family='Airguns 2001 (floor)',event=x.case,unit='Airguns 2001 floor',row_type='floor_detected' if x.status=='detected' else 'floor_not_detected',
            station=x.station,station2='',path=path,path2='',path_class=pc.get(path,'?'),path_class2='',fc_hz=x.fc_hz,r_db=-x.M_theta0_db,r_alt_db=np.nan,
            alt_label='bound: detected => r >= r_db; not detected => r <= r_db',obs_sd_db=np.nan,band_sd_db=np.hypot(x.band_sd_db,RECIP),src_sd_db=x.source_sd_db,
            charge_sd_db=0.0,source_model='Tolstoy 2004 far field, 7.5 m; S >= N rule',group=x.case,obs_snr_db=np.nan,note='one-sided; r_db = noise floor minus predicted level')
    T=pd.DataFrame(rows)
    T['subfamily']=T.get('subfamily',pd.Series(index=T.index,dtype=object)).fillna(T.family)
    return T

def finish(T):
    T=T.reset_index(drop=True).copy()
    T['x']=np.log2(T.fc_hz/10); T['in_band']=T.fc_hz.between(5,40); T['rid']=np.arange(len(T))
    if 'x2' not in T: T['x2']=np.nan
    T['x2']=T.x2.fillna(T.x)
    if 'broadband' not in T: T['broadband']=False
    T['broadband']=T.broadband.fillna(False).astype(bool)
    return T

# ---------------- model ----------------
def row_struct(r):
    fx=[]; rx=[]; t=r['row_type']; x=r['x']
    fam=r['family']
    if t in ('level','free_level'):
        fx+=[('b',r['path_class'],1.0),('s',r['path_class'],x)]
        if t=='free_level': fx.append(('a',r['group'],1.0))
        rx.append(('path:'+r['path'],1.0,'tau',None)); rx.append((f"band:{r['path']}:{r['fc_hz']}",1.0,'sb',None))
        if r['src_sd_db']>0: rx.append(('fam:'+fam,r['src_sd_db'],'fix',1.0))
        if r['charge_sd_db']>0: rx.append(('evt:'+str(r['event']),1.0,'fix',r['charge_sd_db']**2))
        if fam.startswith('Airguns 2001 (Fig'): rx.append(('agslope',x,'fix',AIRGUN_SLOPE_SD**2))
        if fam in SRC_SLOPE_SD and t=='level': rx.append(('srcslope:'+fam,x,'fix',SRC_SLOPE_SD[fam]**2))
        rx.append(('meas:'+str(r['rid']),1.0,'fix',r['obs_sd_db']**2+r['band_sd_db']**2))
    elif t=='difference':
        x2=r['x2']
        fx+=[('b',r['path_class'],1.0),('s',r['path_class'],x),('b',r['path_class2'],-1.0),('s',r['path_class2'],-x2)]
        rx+=[('path:'+r['path'],1.0,'tau',None),('path:'+r['path2'],-1.0,'tau',None)]
        if r['broadband']:
            rx+=[('bandavg:'+r['path'],1.0,'sbavg',None),('bandavg:'+r['path2'],-1.0,'sbavg',None)]
            rx+=[(f"rmeas:{r['event']}:{r['station']}",1.0,'fix',r['meas_var1']),(f"rmeas:{r['event']}:{r['station2']}",-1.0,'fix',r['meas_var2']),
                 (f"cal:{r['station']}",1.0,'fix',r['cal_var1']),(f"cal:{r['station2']}",-1.0,'fix',r['cal_var2'])]
            rx.append(('meas:'+str(r['rid']),1.0,'fix',r['band_sd_db']**2))
        else:
            rx+=[(f"band:{r['path']}:{r['fc_hz']}",1.0,'sb',None),(f"band:{r['path2']}:{r['fc_hz']}",-1.0,'sb',None)]
            rx.append(('meas:'+str(r['rid']),1.0,'fix',r['obs_sd_db']**2+r['band_sd_db']**2))
    return fx,rx

def eligible_classes(D):
    ev={c:set() for c in CLASSES}
    for _,r in D.iterrows():
        if r.row_type=='level': ev[r.path_class].add(r.event)
        elif r.row_type=='difference' and r.path_class!=r.path_class2: ev[r.path_class].add(r.event); ev[r.path_class2].add(r.event)
    for g,gg in D[D.row_type=='free_level'].groupby('group'):
        cs=set(gg.path_class)
        if len(cs)>=2:
            for c in cs: ev[c].add(gg.event.iloc[0])
    return {c:len(v) for c,v in ev.items()}, ev

def _ck(mode,c,elig):
    if mode=='global': return 'global'
    return c if elig.get(c,0)>=3 else 'other'

def design(D,mode,elig):
    S=[row_struct(r) for _,r in D.iterrows()]; pn=[]; pidx={}
    for fx,_ in S:
        for k,c,_ in fx:
            key=(k,c if k=='a' else _ck(mode,c,elig))
            if key not in pidx: pidx[key]=len(pn); pn.append(key)
    X=np.zeros((len(D),len(pn)))
    for i,(fx,_) in enumerate(S):
        for k,c,v in fx: X[i,pidx[(k,c if k=='a' else _ck(mode,c,elig))]]+=v
    re={}
    for i,(_,rx) in enumerate(S):
        for nm,cf,vt,var in rx: re.setdefault((nm,vt,var),[]).append((i,cf))
    Zs={'tau':[],'sb':[],'sbavg':[],'fix':[]}; fv=[]
    for (nm,vt,var),lst in re.items():
        z=np.zeros(len(D))
        for i,cf in lst: z[i]+=cf
        Zs[vt].append(z)
        if vt=='fix': fv.append(var)
    Zs={k:(np.array(v).T if v else np.zeros((len(D),0))) for k,v in Zs.items()}
    return X,pn,Zs,np.array(fv),np.diag([PRIOR[k[0]] for k in pn])

def covR(Zs,fv,tau,sb):
    return (tau**2*Zs['tau']@Zs['tau'].T + sb**2*Zs['sb']@Zs['sb'].T + (sb**2/N_EFF_BANDS)*Zs['sbavg']@Zs['sbavg'].T
            + (Zs['fix']*fv)@Zs['fix'].T)

GRID=np.arange(0,20.01,0.25)
def fit(D,mode,elig,fixed_vc=None,grid=GRID):
    X,pn,Zs,fv,P=design(D,mode,elig); r=D.r_db.values; ll_best=np.nan
    if fixed_vc is None:
        base=(Zs['fix']*fv)@Zs['fix'].T + X@P@X.T
        TT=Zs['tau']@Zs['tau'].T; SB=Zs['sb']@Zs['sb'].T+Zs['sbavg']@Zs['sbavg'].T/N_EFF_BANDS
        best=(-np.inf,None)
        # coarse pass (1 dB) then the prereg 0.25 dB grid near the coarse optimum (same grid nodes)
        def ll(t,s):
            try: cf=cho_factor(base+t*t*TT+s*s*SB,lower=True)
            except Exception: return -np.inf
            return -0.5*(r@cho_solve(cf,r))-np.sum(np.log(np.diag(cf[0])))
        coarse=[(ll(t,s),t,s) for t in grid[::4] for s in grid[::4]]
        _,t0,s0=max(coarse)
        fine=[(ll(t,s),t,s) for t in grid if abs(t-t0)<=1.5 for s in grid if abs(s-s0)<=1.5]
        ll_best,tau,sb=max(fine)
    else: tau,sb=fixed_vc
    V=covR(Zs,fv,tau,sb); Vi=np.linalg.inv(V)
    C=np.linalg.inv(X.T@Vi@X+np.linalg.inv(P)); beta=C@X.T@Vi@r
    return dict(tau=tau,sb=sb,beta=dict(zip(pn,beta)),C=C,pn=pn,ll=ll_best,mode=mode,elig=elig)

def predict(Dh,fits,elig):
    n=len(Dh); S=[row_struct(r) for _,r in Dh.iterrows()]; use=[]
    for _,r in Dh.iterrows():
        cs=[r.path_class]+([r.path_class2] if r.row_type=='difference' else [])
        use.append('class' if all(elig.get(c,0)>=3 for c in cs) else 'global')
    m=np.zeros(n); Vp=np.zeros((n,n)); used_key=['']*n
    for mode in ['class','global']:
        f=fits[mode]; idx=[i for i in range(n) if use[i]==mode]
        if not idx: continue
        key={k:j for j,k in enumerate(f['pn'])}; Xh=np.zeros((n,len(f['pn'])))
        for i in idx:
            for k,c,v in S[i][0]:
                if k=='a': continue
                kk=(k,_ck(mode,c,elig))
                if kk in key: Xh[i,key[kk]]+=v
                else: raise KeyError(kk)
        b=np.array([f['beta'][k] for k in f['pn']]); m[idx]=(Xh@b)[idx]
        Vp[np.ix_(idx,idx)]=(Xh@f['C']@Xh.T)[np.ix_(idx,idx)]
    tau,sb=fits['global']['tau'],fits['global']['sb']
    _,_,Zs,fv,_=design(Dh,'global',elig); V=covR(Zs,fv,tau,sb)+Vp
    Tm=np.eye(n)
    for g in Dh[Dh.row_type=='free_level'].group.unique():
        ii=np.where((Dh.row_type=='free_level').values&(Dh.group==g).values)[0]
        Tm[np.ix_(ii,ii)]=np.eye(len(ii))-1.0/len(ii)
    r=Dh.r_db.values; Vt=Tm@V@Tm.T
    o=Dh.copy(); o['r_t']=Tm@r; o['m_t']=Tm@m; o['S']=np.sqrt(np.clip(np.diag(Vt),1e-12,None)); o['m_raw']=m; o['model_used']=use
    # secondary uncorrected sd: obs+band+source + 5.0^2 + 3.07^2 per path (difference: both paths)
    npath=np.where(o.row_type=='difference',2,1)
    o['S_unc_sec']=np.sqrt(o.S**2 - np.diag(Vp) - npath*(tau**2+sb**2) + npath*(5.0**2+3.07**2)).where(o.row_type!='free_level', o.S)
    return o,Vt

def crps(y,mu,s):
    z=(y-mu)/s; return s*(z*(2*norm.cdf(z)-1)+2*norm.pdf(z)-1/np.sqrt(np.pi))

def run_folds(D,unit_col='unit',log=print):
    res=[]; info=[]
    for u in D[unit_col].unique():
        tr=D[D[unit_col]!=u]; te=D[D[unit_col]==u]; el,_=eligible_classes(tr)
        fg=fit(tr,'global',el); fc=fit(tr,'class',el,fixed_vc=(fg['tau'],fg['sb']))
        o,_=predict(te,{'class':fc,'global':fg},el); o['fold']=u; res.append(o)
        d=dict(fold=u,tau=fg['tau'],sb=fg['sb'],b_global=fg['beta'][('b','global')],s_global=fg['beta'][('s','global')])
        for c in CLASSES: d['events_'+c]=el[c]
        for k,v in fc['beta'].items():
            if k[0] in 'bs': d[f'{k[0]}_{k[1]}']=v
        info.append(d); log(f"fold {u}: tau {fg['tau']} sb {fg['sb']} elig {el}")
    R=pd.concat(res); R['z']=(R.r_t-R.m_t)/R.S
    return R,pd.DataFrame(info)

def stats(g):
    z=g.z.values; e=np.abs(g.r_t-g.m_t)<=1.645*g.S
    return pd.Series(dict(n_bands=len(g),n_events=g.event.nunique(),mean_z=z.mean(),sd_z=z.std(ddof=1) if len(z)>1 else np.nan,
        cover90=e.mean(),crps_corrected=crps(g.r_t,g.m_t,g.S).mean(),crps_uncorrected_same_sd=crps(g.r_t,0*g.r_t,g.S).mean(),
        crps_uncorrected_provisional_sd=crps(g.r_t,0*g.r_t,g.S_unc_sec).mean()))

def grade(s):
    p1=abs(s.mean_z)<=0.5; p2=0.7<=s.sd_z<=1.4; p3=0.80<=s.cover90<=0.97
    return dict(P1_mean=('PASS' if p1 else 'FAIL'),P2_sd=('PASS' if p2 else 'FAIL'),P3_cover=('PASS' if p3 else 'FAIL'))

# ---------------- Royer 2016 station differences (prereg 2.3 + amendment A1) ----------------
ROYER_CAL={'H01W2':2.9}; OHAS_CAL=0.86
def cal_db(st): return ROYER_CAL.get(st,OHAS_CAL)
def cal_var(st): return 1.15**2+2.0**2 if st=='H01W2' else 0.5**2
READ_SD=2.0
REF_ORDER=['H01W2','SSEIR','SWAMS3','MAD','WKER','NCRO','SWAMS2','SWAMS1']
BANDS=np.array([5,6.3,8,10,12.5,16,20,25,31.5,40])
def band_pred(tlp, depth=10.0, spec_exp=0.0):
    """tlp: rows of one path (fc_hz, src_depth_m, tl_db, band_sd_db). Returns 10log10 sum_b w_b 10^(-TL/10), x_eff, mean band sd^2."""
    d=tlp.loc[(tlp.src_depth_m-depth).abs()==(tlp.src_depth_m-depth).abs().min()].set_index('fc_hz').reindex(BANDS)
    w=0.2316*BANDS*(BANDS/10.0)**spec_exp*10**(-d.tl_db.values/10)
    ok=np.isfinite(w)
    return 10*np.log10(w[ok].sum()), np.sum(w[ok]*np.log2(BANDS[ok]/10))/w[ok].sum(), np.nanmean(d.band_sd_db.values**2), ok.sum()

def royer_rows(sel, tl, path_of, class_of, depth=10.0, spec_exp=0.0, window_tab=None):
    """sel: selected measurable station energies (one per event/station). tl: Royer band TL table.
    path_of(event, station) -> path name in tl; class_of(path) -> path class."""
    rows=[]
    for e,g in sel.groupby('royer_event'):
        g=g.set_index('station')
        sts=[s for s in REF_ORDER if s in g.index]
        if len(sts)<2: continue
        ref=sts[0]; pr=path_of(e,ref)
        if pr is None: continue
        Lr,xr,vr,nr=band_pred(tl[tl.path==pr],depth,spec_exp)
        for s in sts[1:]:
            p=path_of(e,s)
            if p is None: continue
            Li,xi,vi,ni=band_pred(tl[tl.path==p],depth,spec_exp)
            Ei=g.loc[s,'E_db'] if window_tab is None else window_tab[(e,s)]
            Er=g.loc[ref,'E_db'] if window_tab is None else window_tab[(e,ref)]
            dobs=(Ei+cal_db(s))-(Er+cal_db(ref)); dpred=Li-Lr
            lab=g.label.iloc[0] if isinstance(g.label.iloc[0],str) else str(e)
            rows.append(dict(family='Royer 2016 events',subfamily='Royer 2016 events',event=f'Royer {lab}',unit=f'Royer event {lab}',row_type='difference',
                station=s,station2=ref,path=p,path2=pr,path_class=class_of(p),path_class2=class_of(pr),fc_hz=float(10*2**((xi+xr)/2)),x=xi,x2=xr,
                r_db=dobs-dpred,r_alt_db=np.nan,alt_label='',obs_sd_db=float(np.hypot(g.loc[s,'sd_db'],g.loc[ref,'sd_db'])),
                band_sd_db=float(np.sqrt((vi+vr+2*RECIP**2)/N_EFF_BANDS)),src_sd_db=0.0,charge_sd_db=0.0,
                source_model='cancels (flat source energy per Hz, 5-40 Hz)',group='',obs_snr_db=np.nan,broadband=True,
                meas_var1=float(g.loc[s,'sd_db']**2+READ_SD**2),meas_var2=float(g.loc[ref,'sd_db']**2+READ_SD**2),
                cal_var1=cal_var(s),cal_var2=cal_var(ref),
                note=f'5-40 Hz arrival energy difference {s} minus {ref}; observed {dobs:.2f} dB, predicted {dpred:.2f} dB; panels {g.loc[s,"kind"]}/{g.loc[ref,"kind"]}'))
    return pd.DataFrame(rows)
