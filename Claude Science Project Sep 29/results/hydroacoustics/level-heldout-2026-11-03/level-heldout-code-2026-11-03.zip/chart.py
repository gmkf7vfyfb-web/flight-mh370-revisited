import numpy as np, textwrap, matplotlib.pyplot as plt
import lvlcore as L
UNIT_LABEL={'SUS 2003':'Blackman 2003 deep charges (SUS)','San Juan charge':'San Juan calibration charge 2017',
 'Ship shock trials':'US Navy ship shock trials 2016 and 2021','San Juan loss event':'San Juan loss event 2017 (station difference)',
 'F-35A crash':'F-35A crash 2019 (station difference)','Airguns 2001':'Blackman 2001 airguns (level removed per site)'}
CLASS_LABEL={'clear deep path':'Clear deep path','ridge near the channel axis':'Ridge near the sound-channel axis',
 'ridge above the channel axis':'Ridge above the sound-channel axis','blocked':'Blocked path'}
def make_chart(H,fname,foot):
    units=list(UNIT_LABEL)+sorted(u for u in H.fold.unique() if u not in UNIT_LABEL)
    pal=list(plt.get_cmap('tab10').colors)+list(plt.get_cmap('Dark2').colors)
    cols=dict(zip(units,pal))
    H=H.copy(); H['panel']=np.where((H.row_type=='difference')&(H.path_class!=H.path_class2),'cross',H.path_class)
    panels=L.CLASSES+(['cross'] if (H.panel=='cross').any() else [])
    nr=2 if len(panels)<=4 else 3
    fig,axs=plt.subplots(nr,2,figsize=(7.2,3.6*nr+1.6))
    for ax in axs.flat[len(panels):]: ax.set_visible(False)
    for ax,c in zip(axs.flat,panels):
        g=H[H.panel==c]; name=CLASS_LABEL.get(c,'Station differences that join two path classes')
        if g.empty:
            ax.text(0.5,0.5,'No held-out rows.\nNo known-source level data\nexist on blocked paths.',ha='center',va='center',transform=ax.transAxes,fontsize=7)
            ax.set_xticks([]); ax.set_yticks([]); ax.set_title(f'{name}:\nnot tested',loc='left',fontsize=7.5); continue
        lo=min((g.m_t-1.645*g.S).min(),g.r_t.min())-2; hi=max((g.m_t+1.645*g.S).max(),g.r_t.max())+2
        ax.plot([lo,hi],[lo,hi],color='0.4',lw=0.8,zorder=1)
        for u,gg in g.groupby('fold'):
            ax.vlines(gg.m_t,gg.m_t-1.645*gg.S,gg.m_t+1.645*gg.S,color=cols[u],alpha=0.25,lw=1.2,zorder=2)
            ax.scatter(gg.m_t,gg.r_t,s=10,color=cols[u],edgecolor='none',zorder=3,label=UNIT_LABEL.get(u,u))
        cov=(np.abs(g.r_t-g.m_t)<=1.645*g.S).mean()
        ax.set_title(f'{name}:\n{cov:.0%} of {len(g)} held-out bands inside the 90 % interval',loc='left',fontsize=7.5)
        ax.set_xlim(lo,hi); ax.set_ylim(lo,hi); ax.set_aspect('equal')
        ax.set_xlabel('Predicted residual, source held out (dB)'); ax.set_ylabel('Observed residual (dB)')
    h,l=[],[]
    for ax in axs.flat:
        for a,b in zip(*ax.get_legend_handles_labels()):
            if b not in l: h.append(a); l.append(b)
    fb=0.205 if nr==2 else 0.17
    fig.legend(h,l,loc='upper left',ncol=2,frameon=False,fontsize=6.5,bbox_to_anchor=(0.03,fb-0.01),markerscale=1.5)
    fig.suptitle('Held-out test of the path-class level correction: observed against predicted band residuals',x=0.02,y=0.995,ha='left',fontsize=8.5)
    fig.text(0.02,0.005,'\n'.join(textwrap.wrap(foot,180)),fontsize=5.5,va='bottom',ha='left')
    fig.subplots_adjust(left=0.09,right=0.98,top=0.915,bottom=fb+0.055,hspace=0.42,wspace=0.30)
    fig.savefig(fname,dpi=300); return fig
