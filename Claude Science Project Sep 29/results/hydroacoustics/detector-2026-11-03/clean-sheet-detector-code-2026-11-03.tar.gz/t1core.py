"""Clean-sheet detector T1 (band-energy excess), core functions.

Definition (pre-registered with the detector, 3 Nov 2026):
  x(t)    pressure in Pa after instrument-response correction.
  y(t)    x band-passed 5-40 Hz (Butterworth, 4 poles, zero phase: sosfiltfilt).
  e1[n]   per-second band energy, sum over second n of y^2 * dt   (Pa^2 s).
  E_W(t)  window band energy, sum of e1 over [t, t+W)  (step 1 s).
  N_W(t)  noise energy level in the same window = running median of E_W over
          1801 s centred on the window (ignores flagged windows).
  T1(t)   = 10 log10( E_W(t) / N_W(t) )  dB.
  SNR_dB  = 10 log10( E_s / N_W )  where E_s is the band energy of the signal
          (total, all of the arrival) -- the schema definition.
  Alarm   = a run of T1 > threshold; runs closer than W seconds are one alarm.
  Detection of an injected arrival = any window that overlaps the 5-95 % energy
          span of the arrival has T1 > threshold.
"""
import numpy as np
import pandas as pd
from scipy.signal import butter, sosfiltfilt
from scipy.special import erfc

BAND = (5.0, 40.0)
MED_SPAN_S = 1801
WINDOWS = (10, 30, 60)


def bandpass(x, fs, band=BAND, order=4):
    sos = butter(order, [band[0], band[1]], btype="bandpass", fs=fs, output="sos")
    return sosfiltfilt(sos, x)


def per_second_energy(y, fs):
    n = int(len(y) // fs)
    ns = int(round(fs))
    return (y[: n * ns].reshape(n, ns) ** 2).sum(axis=1) / fs


def window_energy(e1, W):
    """E_W[t] = sum e1[t:t+W]; length len(e1)-W+1."""
    c = np.concatenate([[0.0], np.cumsum(e1)])
    return c[W:] - c[:-W]


def window_flags(flag1, W):
    c = np.concatenate([[0], np.cumsum(flag1.astype(int))])
    return (c[W:] - c[:-W]) > 0


def running_median(EW, bad, span=MED_SPAN_S, min_periods=600):
    s = pd.Series(np.where(bad, np.nan, EW))
    return s.rolling(span, center=True, min_periods=min_periods).median().values


def t1_series(e1, flag1, W):
    EW = window_energy(e1, W)
    bad = window_flags(flag1, W)
    NW = running_median(EW, bad)
    with np.errstate(divide="ignore", invalid="ignore"):
        T = 10 * np.log10(EW / NW)
    T[bad | ~np.isfinite(T)] = np.nan
    return T, NW


def count_alarms(T, thr_grid, W):
    """Number of alarms (declustered runs) per threshold. T has NaN for invalid windows."""
    out = np.zeros(len(thr_grid), int)
    Tv = np.where(np.isfinite(T), T, -np.inf)
    for i, thr in enumerate(thr_grid):
        idx = np.flatnonzero(Tv > thr)
        if idx.size == 0:
            continue
        out[i] = 1 + int(np.sum(np.diff(idx) > W))
    return out


def gamma2_envelope(t, d90):
    th = d90 / 4.3888
    g = np.where(t > 0, t / th ** 2 * np.exp(-t / th), 0.0)
    return g, th


def make_signal(rng, fs, d90, fc=5.0, n_exp=3.1, pad_s=10.0):
    """Unit band-energy (5-40 Hz) arrival: Gaussian noise with source spectrum
    flat to fc then (f/fc)^-n_exp (energy spectrum), gamma(k=2) intensity envelope
    with 90 % energy duration d90. Returns s (Pa, unit energy Pa^2 s), onset index,
    and t5, t95 (s after onset)."""
    th = d90 / 4.3888
    L = 8.0 * th + 2 * pad_s
    n = int(L * fs)
    t = np.arange(n) / fs - pad_s
    w = rng.standard_normal(n)
    F = np.fft.rfft(w)
    f = np.fft.rfftfreq(n, 1 / fs)
    amp = np.where(f <= fc, 1.0, (np.maximum(f, 1e-9) / fc) ** (-n_exp / 2))
    w = np.fft.irfft(F * amp, n)
    g, _ = gamma2_envelope(t, d90)
    s = bandpass(w * np.sqrt(g), fs)
    s /= np.sqrt((s ** 2).sum() / fs)
    return s, int(pad_s * fs), 0.35536 * th, 4.7439 * th


def Phi(z):
    return 0.5 * erfc(-z / np.sqrt(2))
