"""Clean-sheet detector T1: thresholds, P_D fits, pd_curves inputs (reproduction driver).
Consolidates the session's interactive steps. Inputs: blocks/ and blocks2/ (ims_blocks.py runs 1 and 2),
imos_out/ and imos_out2/ (imos_blocks.py runs 1 and 2), jobs_ims.csv, jobs_h11.csv.
Outputs to repro/: detector-thresholds.csv, pd-curve-fits.csv. Compare with out/.
Usage: python run_analysis.py
"""
import os, sys, glob, json
import numpy as np, pandas as pd
from scipy.ndimage import maximum_filter1d
from scipy.optimize import minimize
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import analyse as A

FINE = np.round(np.arange(0, 45.001, 0.05), 2)
RATES = {"1/day": 1 / 24.0, "1/hour": 1.0}
FORM = {"single": "raw_ims_single", "array": "raw_ims_array_incoherent", "envelope": "envelope_kadri"}
MODEIDX = {"single": [0, 1, 2], "array": [3], "envelope": [4, 5, 6]}
DURS = [15.0, 60.0]
rng = np.random.default_rng(20261103)


def fast_counts(T, W, grid=FINE):
    """Exact alarm count: alarms(u) = #{i: M_i <= u < T_i}, M_i = max T over the W previous windows."""
    Tv = np.where(np.isfinite(T), T, -np.inf)
    pad = np.concatenate([np.full(W, -np.inf), Tv])
    M = maximum_filter1d(pad, size=W, origin=(W - 1) // 2 - (W - 1))[: len(Tv)]
    v = Tv > M
    return np.searchsorted(np.sort(M[v]), grid, side="right") - np.searchsorted(np.sort(Tv[v]), grid, side="right")


def thr_boot(C, H, rate, scale=1.0, nb=1000):
    def th(c, h):
        r = c.sum(0) / h.sum() * scale; k = np.flatnonzero(r <= rate); return FINE[k[0]] if k.size else np.nan
    t0 = th(C, H); n = len(H)
    bs = [th(C[i], H[i]) for i in (rng.integers(0, n, n) for _ in range(nb))]
    return t0, np.nanpercentile(bs, 5), np.nanpercentile(bs, 95)


def fit_floor(x, y, p0):
    def nll(p):
        P = np.clip(p0 + (1 - p0) * A.Phi((x - p[0]) / np.exp(p[1])), 1e-12, 1 - 1e-12)
        return -(y * np.log(P) + (1 - y) * np.log(1 - P)).sum()
    b = pd.DataFrame(dict(b=np.round(x * 2) / 2, y=y)).groupby("b").y.mean()
    mu0 = b.index[np.argmin(np.abs(b.values - 0.5))]
    best = min((minimize(nll, [mu0, ls], method="Nelder-Mead", options=dict(xatol=1e-4, fatol=1e-3, maxiter=4000))
                for ls in (np.log(0.3), np.log(1.0), np.log(3.0))), key=lambda r: r.fun)
    return best.x[0], np.exp(best.x[1])


def station_of(jb):
    return jb.triad if not jb.triad.startswith("H11") else jb.triad + "_" + jb.block_id.split("_")[1]


def main():
    os.makedirs("repro", exist_ok=True)
    jobs = pd.concat([pd.read_csv("jobs_ims.csv"), pd.read_csv("jobs_h11.csv")])
    rows = []
    for jb in jobs.itertuples():
        if jb.role != "bg":
            continue
        z = np.load(f"blocks/{jb.block_id}.npz")
        for W in A.WINDOWS:
            for mode, sl in A.ims_series(z, W).items():
                for T in sl:
                    rows.append(dict(station=station_of(jb), block=jb.block_id, mode=mode, W=W, hours=np.isfinite(T).sum() / 3600, counts=fast_counts(T, W)))
    ims = pd.DataFrame(rows)
    out = []
    for (st, mode, W), g in ims.groupby(["station", "mode", "W"]):
        gb = g.groupby("block").agg(hours=("hours", "sum"), counts=("counts", lambda s: np.sum(np.stack(s.values), 0)))
        for fa, rate in RATES.items():
            t0, lo, hi = thr_boot(np.stack(gb.counts.values), gb.hours.values, rate)
            out.append(dict(station=st, data_form=FORM[mode], window_s=W, fa=fa, threshold_db=t0, thr_p05=lo, thr_p95=hi))
    # IMOS
    irows = []
    for p in sorted(glob.glob("imos_out/*.npz")):
        z = np.load(p); meta = json.loads(str(z["meta"])); L = z["rec_len"]; e = z["e1"].astype(float)
        offs = np.concatenate([[0], np.cumsum(L)]); g = os.path.basename(p)[5:-4]
        for r, m in enumerate(meta):
            er = e[offs[r]:offs[r + 1]]
            if (er <= 0).any():
                continue
            for wi, W in enumerate(A.WINDOWS):
                T = 10 * np.log10(A.window_energy(er, W) / z["refs"][wi][r])
                irows.append(dict(station=m["logger"], rec_s=len(er), block=g if m["src"] == "background" else m["logger"] + "_" + m["t0"][:10], W=W, hours=len(T) / 3600, counts=fast_counts(T, W)))
    imf = pd.DataFrame(irows)
    duty = imf.groupby("station").rec_s.mean() / 900.0
    for (st, W), g in imf.groupby(["station", "W"]):
        gb = g.groupby("block").agg(hours=("hours", "sum"), counts=("counts", lambda s: np.sum(np.stack(s.values), 0)))
        for fa, rate in RATES.items():
            t0, lo, hi = thr_boot(np.stack(gb.counts.values), gb.hours.values, rate, scale=duty[st])
            out.append(dict(station="IMOS" + st, data_form="raw_imos_duty_cycled", window_s=W, fa=fa, threshold_db=t0, thr_p05=lo, thr_p95=hi))
    thr = pd.DataFrame(out); thr.to_csv("repro/detector-thresholds.csv", index=False)
    TH = thr.set_index(["station", "data_form", "window_s", "fa"]).threshold_db
    # P_D fits (primary window and duration only, to keep the reproduction short)
    fits = []
    inj = {}
    for jb in jobs.itertuples():
        if jb.role != "bg":
            continue
        z = np.load(f"blocks2/{jb.block_id}.npz")
        if "inj_snr" in z.files:
            inj.setdefault(station_of(jb), []).append((z["inj_snr"], z["inj_maxT"], z["inj_max0"]))
    for st, L in inj.items():
        S = np.concatenate([x[0] for x in L]); M = np.concatenate([x[1] for x in L]); M0 = np.concatenate([x[2] for x in L])
        for mode, idx in MODEIDX.items():
            wi, di, W, D = 1, 0, 30, 15.0
            s = S[:, di, wi][:, idx].ravel(); m = M[:, di, wi][:, idx].ravel(); m0 = M0[:, di, wi][:, idx].ravel()
            ok = np.isfinite(s) & np.isfinite(m)
            for fa in RATES:
                th = TH[(st, FORM[mode], W, fa)]
                p0 = np.mean(m0[np.isfinite(m0)] > th)
                mu, sg = fit_floor(s[ok], (m[ok] > th).astype(float), p0)
                fits.append(dict(station=st, data_form=FORM[mode], window_s=W, duration_s=D, fa=fa, threshold_db=th, pd_floor=p0, snr50_db=mu, sigma_db=sg))
    pd.DataFrame(fits).to_csv("repro/pd-curve-fits.csv", index=False)
    print("done", len(thr), len(fits))


if __name__ == "__main__":
    main()
