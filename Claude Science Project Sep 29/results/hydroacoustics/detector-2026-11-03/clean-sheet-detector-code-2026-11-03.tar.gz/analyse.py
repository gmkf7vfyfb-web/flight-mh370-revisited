"""Thresholds from empirical alarm rates and P_D curves from the injection bench.
Writes: thresholds.csv, injection_results.csv (binned), pd_fits.csv, block_counts.pkl
"""
import sys, os, glob, json
import numpy as np, pandas as pd
from scipy.optimize import minimize
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from t1core import window_energy, window_flags, running_median, Phi, WINDOWS

COARSE = np.arange(0.0, 40.01, 0.25)
RATES = {"1/day": 1 / 24.0, "1/hour": 1.0}
MODES_IMS = {"single": ["e1", "e2", "e3"], "array": ["arr"], "envelope": ["v1", "v2", "v3"]}
RNG = np.random.default_rng(20261103)


def count_runs(T, thr, W):
    idx = np.flatnonzero(T > thr)
    if idx.size == 0:
        return 0
    return 1 + int(np.sum(np.diff(idx) > W))


def ims_series(z, W):
    """Return dict mode -> list of T1 arrays over the evaluation span (window starts)."""
    e1, env, flags, ok = z["e1"].astype(float), z["env"].astype(float), z["flags"], z["ok"]
    a, b = int(z["eval_start"]), int(z["eval_end"])
    out = {"single": [], "array": [], "envelope": []}
    good = [k for k in range(3) if ok[k]]
    for k in good:
        T, _ = t1_from(e1[k], flags[k], W)
        out["single"].append(T[a:b - W + 1])
        out["envelope"].append(env_t1(env[k], flags[k], W, a, b))
    if len(good) == 3:
        T, _ = t1_from(e1.mean(axis=0), flags.any(axis=0), W)
        out["array"].append(T[a:b - W + 1])
    return out


def t1_from(e, f, W):
    EW = window_energy(e, W); bad = window_flags(f, W)
    NW = running_median(EW, bad)
    with np.errstate(divide="ignore", invalid="ignore"):
        T = 10 * np.log10(EW / NW)
    T[bad | ~np.isfinite(T)] = np.nan
    return T, NW


def env_t1(v, f, W, a, b, pan=600):
    EW = window_energy(v, W); bad = window_flags(f, W)
    T = np.full(b - a - W + 1, np.nan)
    for p0 in range(a, b, pan):
        st = np.arange(p0, min(p0 + pan, b) - W + 1)
        if len(st) < pan // 2:
            continue
        ok = ~bad[st]
        if ok.sum() < len(st) // 2:
            continue
        ref = np.median(EW[st][ok])
        t = 10 * np.log10(EW[st] / ref); t[~ok] = np.nan
        T[st - a] = t
    return T


def counts_for(series_list, W, grid):
    c = np.zeros(len(grid)); hrs = 0.0
    for T in series_list:
        Tv = np.where(np.isfinite(T), T, -np.inf)
        hrs += np.isfinite(T).sum() / 3600.0
        for i, u in enumerate(grid):
            c[i] += count_runs(Tv, u, W)
    return c, hrs


def threshold_from(counts, hours, grid, rate, scale=1.0):
    r = counts.sum(axis=0) / hours.sum() * scale
    okk = np.flatnonzero(r <= rate)
    return grid[okk[0]] if okk.size else np.nan


def fit_probit(snr, det):
    m = np.isfinite(snr)
    x, y = snr[m].astype(float), det[m].astype(float)
    def nll(p):
        mu, ls = p
        P = np.clip(Phi((x - mu) / np.exp(ls)), 1e-9, 1 - 1e-9)
        return -(y * np.log(P) + (1 - y) * np.log(1 - P)).sum()
    i50 = np.argmin(np.abs(pd.Series(y).groupby(np.round(x)).transform("mean").values - 0.5))
    r = minimize(nll, [x[i50], np.log(2.0)], method="Nelder-Mead", options=dict(xatol=1e-4, fatol=1e-4, maxiter=4000))
    mu, s = r.x[0], np.exp(r.x[1])
    # curvature-based standard errors
    from scipy.optimize import approx_fprime
    h = 1e-3
    H = np.zeros((2, 2)); p0 = r.x
    for i in range(2):
        for j in range(2):
            e_i = np.eye(2)[i] * h; e_j = np.eye(2)[j] * h
            H[i, j] = (nll(p0 + e_i + e_j) - nll(p0 + e_i - e_j) - nll(p0 - e_i + e_j) + nll(p0 - e_i - e_j)) / (4 * h * h)
    try:
        C = np.linalg.inv(H); se_mu = np.sqrt(C[0, 0]); se_s = s * np.sqrt(C[1, 1])
    except Exception:
        se_mu = se_s = np.nan
    # empirical bins
    b = np.round(x)
    emp = pd.DataFrame(dict(b=b, y=y)).groupby("b").y.agg(["mean", "size"])
    fitb = Phi((emp.index.values - mu) / s)
    gap = np.max(np.abs(emp["mean"].values - fitb)[emp["size"].values >= 30]) if (emp["size"] >= 30).any() else np.nan
    return mu, s, se_mu, se_s, gap, emp
