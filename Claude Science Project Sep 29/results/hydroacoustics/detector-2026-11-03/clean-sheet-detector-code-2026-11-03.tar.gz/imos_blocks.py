"""IMOS logger (Curtin) records: T1 null statistics and injection bench.
Data: 14-day background records (1-15 Mar 2014 without 8 Mar; loggers 3250, 3274, 3376) and
event-day files OUTSIDE an exclusion span 7 Mar 23:00 - 8 Mar 07:30 UTC (all five loggers).
No record that starts inside the exclusion span is read, so no MH370 prediction window is used.
Usage: python imos_blocks.py <outdir> <nproc>
"""
import sys, os, glob, re, json, time, hashlib
import numpy as np, pandas as pd
from multiprocessing import Pool
from scipy.signal import resample_poly
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from t1core import bandpass, per_second_energy, make_signal, WINDOWS

H = "/Users/pete/Downloads/mh370-inputs/hydroacoustics/imos"
SENS = {"3315": -197.8, "3250": -197.7, "3376": -196.0, "3274": -196.0, "3275": -196.0}   # dB re V/Pa (metadata files)
GAIN = {  # system gain dB per band (dg_results_data_imos1d_calibration_gain)
    "3315": [27.04, 32.60, 34.98, 36.80, 38.22], "3376": [24.86, 32.71, 37.40, 39.62, 40.44],
    "3250": [26.31, 31.95, 35.03, 36.98, 38.64], "3274": [24.77, 32.67, 37.71, 39.94, 40.59],
    "3275": [24.83, 31.72, 36.02, 38.53, 39.36]}
GF = np.array([np.sqrt(2 * 5), np.sqrt(5 * 10), np.sqrt(10 * 20), np.sqrt(20 * 40), np.sqrt(40 * 80)])
FS = 250.0
EXCL = (pd.Timestamp("2014-03-07 23:00", tz="UTC"), pd.Timestamp("2014-03-08 07:30", tz="UTC"))
LEVELS = np.arange(-2, 56.01, 0.5)   # injected energy re noise power x 1 s (E/N0, dB); extended grid (run 2)
DURS = (15.0, 60.0)


def read_dat(path):
    with open(path, "rb") as f:
        hdr = [f.readline().decode("latin1") for _ in range(5)]
        start = f.tell()
        raw = f.read()
    k = raw.rfind(b"Record Marker")
    data = np.frombuffer(raw[: (k - 2) // 2 * 2], dtype=">u2").astype(float)
    m = re.search(r"Schedule \d (\d{4}/\d\d/\d\d \d\d:\d\d:\d\d)", hdr[1])
    t0 = pd.Timestamp(m.group(1).replace("/", "-"), tz="UTC")
    fs = float(re.search(r"Sample Rate (\d+)", hdr[2]).group(1))
    v = data * 5.0 / 65536.0
    return t0, fs, v - v.mean(), hdr


def to_pa_band(v, fs, logger):
    x = resample_poly(v, 1, int(round(fs / FS)))
    n = len(x)
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(n, 1 / FS)
    g = np.interp(np.log(np.maximum(f, 1.0)), np.log(GF), GAIN[logger])
    X /= 10 ** ((g + SENS[logger]) / 20) * 1e6   # sensitivity is dB re 1 V/uPa -> output Pa
    x = np.fft.irfft(X, n)
    return bandpass(x, FS)


def list_records():
    rows = []
    for lg in ["3250", "3274", "3376"]:
        for p in sorted(glob.glob(f"{H}/background/{lg}/2014*/*.DAT")):
            rows.append((lg, p, "background"))
    for lg, d in [("3315", "MH370/3315_PerthCanyon"), ("3376", "MH370/3376_PerthCanyon"), ("3250", "MH370/3250_ScottReef"),
                  ("3274", "Portland_MH370/3274_Portland"), ("3275", "Portland_MH370/3275_Portland")]:
        for p in sorted(glob.glob(f"{H}/{d}/*.DAT")):
            rows.append((lg, p, "eventday"))
    return rows


def process_group(args):
    key, recs, seed, outdir = args
    out = os.path.join(outdir, f"imos_{key}.npz")
    if os.path.exists(out):
        return key, "exists"
    rng = np.random.default_rng(seed)
    meta, E1, Y = [], [], []
    for lg, p, src in recs:
        t0, fs, v, hdr = read_dat(p)
        if EXCL[0] <= t0 < EXCL[1]:
            continue                      # never read MH370-period records
        y = to_pa_band(v, fs, lg)
        e = per_second_energy(y, FS)[1:-1]   # drop edge seconds (filter edge)
        y = y[int(FS): int(FS) * (len(e) + 1)]
        meta.append(dict(logger=lg, file=os.path.basename(p), src=src, t0=str(t0), n_s=len(e)))
        E1.append(e); Y.append(y)
    if not meta:
        return key, "empty"
    t0s = pd.to_datetime([m["t0"] for m in meta])
    order = np.argsort(t0s); meta = [meta[i] for i in order]; E1 = [E1[i] for i in order]; Y = [Y[i] for i in order]
    t0s = t0s[order]
    # neighbour-record noise reference: median E_W over the record and the records 15 min before and after
    nR = len(meta)
    nb = [[j for j in (r - 1, r, r + 1) if 0 <= j < nR and abs((t0s[j] - t0s[r]).total_seconds()) < 1000] for r in range(nR)]
    refs = {}
    for W in WINDOWS:
        EW = [np.convolve(e, np.ones(W), "valid") for e in E1]
        refs[W] = np.array([np.median(np.concatenate([EW[j] for j in nb[r]])) for r in range(nR)])
    nL = len(LEVELS)
    SNR = np.full((nR, len(DURS), len(WINDOWS), nL), np.nan, np.float32); MAXT = np.full_like(SNR, np.nan)
    MAX0 = np.full((nR, len(DURS), len(WINDOWS)), np.nan, np.float32)
    for r in range(nR):
        e, y = E1[r], Y[r]
        ns = len(e)
        for d, D in enumerate(DURS):
            s, i0, t5, t95 = make_signal(rng, FS, D)
            Ls = len(s) / FS
            lo, hi = 70, int(ns - Ls + 10 - 70)
            if hi <= lo:
                continue
            on = int(rng.integers(lo, hi))
            s0 = on * int(FS) - i0
            a_, b_ = max(s0, 0), min(s0 + len(s), len(y))
            ss_full = np.zeros(len(y)); ss_full[a_:b_] = s[a_ - s0: b_ - s0]
            secs = np.arange(len(y)) // int(FS)
            cross = np.bincount(secs, weights=y * ss_full / FS, minlength=ns)[:ns]
            sse = np.bincount(secs, weights=ss_full ** 2 / FS, minlength=ns)[:ns]
            Pn = refs[30][r] / 30.0
            amps = np.sqrt(10 ** (LEVELS / 10) * Pn)
            span_lo, span_hi = on + int(np.floor(t5)), on + int(np.ceil(t95))
            for w, W in enumerate(WINDOWS):
                wst = np.arange(span_lo - W + 1, span_hi + 1); wst = wst[(wst >= 0) & (wst + W <= ns)]
                c0 = np.concatenate([[0.0], np.cumsum(e)])
                MAX0[r, d, w] = np.max(10 * np.log10((c0[wst + W] - c0[wst]) / refs[W][r]))
                for l, a in enumerate(amps):
                    c = np.concatenate([[0.0], np.cumsum(e + 2 * a * cross + a * a * sse)])
                    MAXT[r, d, w, l] = np.max(10 * np.log10((c[wst + W] - c[wst]) / refs[W][r]))
                    SNR[r, d, w, l] = 10 * np.log10(a * a * sse.sum() / refs[W][r])
    np.savez_compressed(out, meta=json.dumps(meta), e1=np.concatenate(E1).astype(np.float32),
                        rec_len=np.array([len(e) for e in E1]), refs=np.array([refs[W] for W in WINDOWS]),
                        inj_snr=SNR, inj_maxT=MAXT, inj_max0=MAX0, levels=LEVELS, durs=np.array(DURS), windows=np.array(WINDOWS))
    return key, f"ok {nR}"


if __name__ == "__main__":
    outdir, nproc = sys.argv[1], int(sys.argv[2])
    os.makedirs(outdir, exist_ok=True)
    recs = list_records()
    groups = {}
    for lg, p, src in recs:
        day = os.path.basename(os.path.dirname(p)) if src == "background" else "eventday"
        groups.setdefault(f"{lg}_{day}", []).append((lg, p, src))
    jobs = [(k, v, 5000 + i, outdir) for i, (k, v) in enumerate(sorted(groups.items()))]
    t = time.time()
    with Pool(nproc) as pool:
        for i, (k, msg) in enumerate(pool.imap_unordered(process_group, jobs)):
            print(f"{i+1}/{len(jobs)} {k} {msg} {time.time()-t:.0f}s", flush=True)
