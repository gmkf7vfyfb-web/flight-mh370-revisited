"""Royer 2016 detection-outcome test and OHASISBIO P_D (pre-registration section 5.5).
Run on 3 Nov 2026 with tl_royer_bands.csv (artifact vadc493a6); H01W1 and H01W3 use the H01W2 loss.

Usage: python royer_loso.py <royer_tl_bands.csv> <hydro_data.sqlite> <pd_curves.json> <outdir>
TL table: one row per (path, band): columns station, fc_hz, tl_db, src_depth_m and EITHER royer_event
(Royer index 1-20) OR src_lat/src_lon (matched to the Royer event table within 0.05 deg). Rows with
tl_db NaN or a 'blocked' status mean no water path. Source depth used: 10 m if present, else the smallest.
Model: P(det k,s) = Phi((SL_k - TL_ks - N_s - 10 log10 W - c_f)/sigma_f)
  - IMS rows (H01W1-3): c_f = snr50 of the Cape Leeuwin curve (W 30 s, D 60 s, 1 per day), sigma_f =
    sqrt(sigma^2 + s_prop^2 + s_noise^2) fixed.
  - OHASISBIO rows: c_f, sigma_f free (one curve for all OHASISBIO sites).
  - SL_k free per event, prior N(median of initial SL, 20 dB).
Leave-one-station-out: fit on 9 receivers, predict the 10th. No water path -> P_pred = 0.01.
"""
import sys, json, sqlite3
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm

W = 30.0
S_PROP = 6.0
NOISE = {"H01W1": 104.28, "H01W2": 104.28, "H01W3": 104.28, "SSEIR": 102.6, "SWAMS3": 101.8, "SWAMS1": 103.3,
         "SWAMS2": 103.3, "MAD": 91.9, "NCRO": 105.0, "WKER": 106.7}
S_NOISE = {k: (1.17 if k.startswith("H01W") else 3.0) for k in NOISE}
N_EXP, FC = 3.1, 5.0


def band_frac(fc_b, fcorner=FC):
    lo, hi = fc_b * 2 ** (-1 / 6), fc_b * 2 ** (1 / 6)
    F = lambda f: np.where(f <= fcorner, f, fcorner + fcorner / (N_EXP - 1) * (1 - (f / fcorner) ** (1 - N_EXP)))
    return (F(hi) - F(lo)) / (fcorner * N_EXP / (N_EXP - 1))


def effective_tl(g):
    """Effective 5-40 Hz loss for the shared source shape: -10 log10 sum_b frac_b 10^(-TL_b/10) / sum_b frac_b."""
    g = g[(g.fc_hz >= 5) & (g.fc_hz <= 40)]
    if g.tl_db.isna().all() or len(g) == 0:
        return np.nan
    f = band_frac(g.fc_hz.values); t = g.tl_db.values; ok = np.isfinite(t)
    return -10 * np.log10(np.sum(f[ok] * 10 ** (-t[ok] / 10)) / np.sum(f[ok]))


def main(tl_path, db_path, pdc_path, outdir):
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    ev = pd.read_sql("select * from dg_royer_2016_royer_events", con)
    arr = pd.read_sql("select * from dg_royer_2016_royer_arrivals", con)
    arr["observed"] = arr.arrival_utc.notna().astype(int)
    tl = pd.read_csv(tl_path)
    if "royer_event" not in tl.columns:
        def match(r):
            d = np.hypot(ev.lat_deg - r.src_lat, (ev.lon_deg - r.src_lon) * np.cos(np.radians(r.src_lat)))
            return int(ev["index"].iloc[np.argmin(d)]) if d.min() < 0.05 else -1
        key = tl[["src_lat", "src_lon"]].drop_duplicates()
        key["royer_event"] = key.apply(match, axis=1)
        tl = tl.merge(key, on=["src_lat", "src_lon"])
    zs = 10.0 if (tl.src_depth_m == 10.0).any() else tl.src_depth_m.min()
    tl = tl[tl.src_depth_m == zs]
    stn = tl.station.astype(str).str.replace("_2014", "", regex=False)
    tl = tl.assign(station=stn)
    etl = tl.groupby(["royer_event", "station"]).apply(effective_tl).rename("tl_eff").reset_index()
    d = arr.rename(columns={"index": "royer_event"}).merge(etl, on=["royer_event", "station"], how="left")
    d["noise"] = d.station.map(NOISE); d["s_noise"] = d.station.map(S_NOISE)
    d["is_ims"] = d.station.str.startswith("H01W")
    pdc = json.load(open(pdc_path))
    c = pdc["stations"]["H01W"]["variants"]["W30_D60"]["1/day"]
    c_ims, s_ims = c["snr50_db"], np.sqrt(c["sigma_db"] ** 2 + S_PROP ** 2 + 1.17 ** 2)
    d["m0"] = -d.tl_eff - d.noise - 10 * np.log10(W)     # margin without SL
    events = sorted(d.royer_event.unique())

    def fit(dd):
        dd = dd[np.isfinite(dd.m0)]
        k = {e: i for i, e in enumerate(events)}
        idx = dd.royer_event.map(k).values; y = dd.observed.values; ims = dd.is_ims.values; m0 = dd.m0.values
        def nll(p):
            SL = p[:len(events)]; cO, lsO = p[-2], p[-1]
            z = np.where(ims, (SL[idx] + m0 - c_ims) / s_ims, (SL[idx] + m0 - cO) / np.exp(lsO))
            P = np.clip(norm.cdf(z), 1e-9, 1 - 1e-9)
            prior = ((SL - np.median(SL)) / 20.0) ** 2 / 2
            return -(y * np.log(P) + (1 - y) * np.log(1 - P)).sum() + prior.sum()
        # start: SL_k puts each event's IMS margin 5 dB above the IMS 50 % point (most events are seen at H01W);
        # OHASISBIO offset starts at the median OHASISBIO margin. sigma bounded to [0.5, 50] dB (numerical guard,
        # added after the first run diverged; not part of the pre-registered model).
        base = np.nanmedian(c_ims - m0[ims]) + 5.0 if ims.any() else 200.0
        sl0 = np.full(len(events), base)
        cO0 = float(np.median(sl0[idx][~ims] + m0[~ims])) if (~ims).any() else 0.0
        p0 = np.concatenate([sl0, [cO0, np.log(6.0)]])
        bnds = [(None, None)] * len(events) + [(None, None), (np.log(0.5), np.log(50.0))]
        r = minimize(nll, p0, method="L-BFGS-B", bounds=bnds)
        return r.x[:len(events)], r.x[-2], np.exp(r.x[-1]), k

    rows = []
    for s in d.station.unique():
        SL, cO, sO, k = fit(d[d.station != s])
        for rr in d[d.station == s].itertuples():
            if not np.isfinite(rr.m0):
                p = 0.01
            else:
                z = (SL[k[rr.royer_event]] + rr.m0 - (c_ims if rr.is_ims else cO)) / (s_ims if rr.is_ims else sO)
                p = float(norm.cdf(z))
            rows.append(dict(family="royer_2016", unit=f"ev{rr.royer_event}-{s}", station=s, royer_event=rr.royer_event,
                             tl_eff_db=rr.tl_eff, p_pred=p, observed=rr.observed, held_out_station=s))
    res = pd.DataFrame(rows)
    SL, cO, sO, k = fit(d)
    res.to_csv(f"{outdir}/royer-loso-predictions.csv", index=False)
    json.dump(dict(ohasisbio_snr50_db=float(cO), ohasisbio_sigma_eff_db=float(sO),
                   ohasisbio_sigma_db_excl_prop=float(np.sqrt(max(sO ** 2 - S_PROP ** 2 - 3.0 ** 2, 1.0))),
                   source_levels_db={str(e): float(SL[i]) for e, i in k.items()},
                   note="PROVISIONAL: anchored only through Cape Leeuwin picks; Royer events were selected by detection at >= 6 stations."),
              open(f"{outdir}/ohasisbio-pd-fit.json", "w"), indent=1)
    print(res.groupby("station").agg(n=("observed", "size"), det=("observed", "sum"), mean_p=("p_pred", "mean")))


if __name__ == "__main__":
    main(*sys.argv[1:5])
