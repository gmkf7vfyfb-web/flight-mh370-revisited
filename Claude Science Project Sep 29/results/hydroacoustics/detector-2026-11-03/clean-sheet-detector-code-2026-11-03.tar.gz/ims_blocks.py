"""Download open raw IMS hydrophone blocks (EarthScope FDSN, network IM, channel EDH),
correct the instrument response, compute the T1 per-second band energies for each element,
the Kadri-style vertex-envelope emulation, and run the injection bench inside the block.

Usage: python ims_blocks.py <jobs.csv> <outdir> <nproc>
jobs.csv columns: block_id, triad, t0_utc, dur_s, eval_start_s, eval_end_s, role, seed
Each injection is processed alone (no detector memory shared between injections).
"""
import sys, os, io, time, json, hashlib
import numpy as np, pandas as pd, requests
from multiprocessing import Pool
from obspy import read, read_inventory, UTCDateTime, Stream
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from t1core import bandpass, per_second_energy, window_energy, running_median, make_signal, WINDOWS

URL = "https://service.earthscope.org/fdsnws/dataselect/1/query"
INV = read_inventory(os.path.join(os.path.dirname(os.path.abspath(__file__)), "resp", "IM_H.xml"))
FS = 250.0
PRE_FILT = (2.0, 3.0, 45.0, 55.0)
DT_V = 0.0523          # Kadri Fig. 9 vertex spacing (median of digitised panels a-c)
LEVELS = np.arange(-2, 56.01, 0.5)   # injected energy re noise power x 1 s (E/N0, dB); extended grid (run 2)
DURS = (15.0, 60.0)    # 90 % energy durations of the injected arrival, s
N_INJ = 16


def fetch(sta, t0, t1):
    p = dict(net="IM", sta=sta, loc="*", cha="EDH", start=t0.strftime("%Y-%m-%dT%H:%M:%S"),
             end=t1.strftime("%Y-%m-%dT%H:%M:%S"))
    for k in range(4):
        try:
            r = requests.get(URL, params=p, timeout=300)
            if r.status_code in (200, 204):
                return r.status_code, r.content
        except Exception:
            pass
        time.sleep(5 + 10 * k)
    return -1, b""


def element_series(sta, T0, dur):
    code, data = fetch(sta, T0, T0 + dur)
    info = dict(station=sta, http=code, bytes=len(data), sha256=hashlib.sha256(data).hexdigest() if data else "")
    n = int(dur * FS)
    if code != 200 or not data:
        return None, np.ones(int(dur), bool), info
    st = read(io.BytesIO(data))
    st.merge(method=0, fill_value=None)
    tr = st[0]
    tr.trim(T0, T0 + (n - 1) / FS, pad=True, fill_value=None)
    d = tr.data
    mask = np.ma.getmaskarray(d) if np.ma.isMaskedArray(d) else np.zeros(len(d), bool)
    x = np.ma.filled(d.astype(float), np.nan) if np.ma.isMaskedArray(d) else d.astype(float)
    if len(x) < n:
        x = np.concatenate([x, np.full(n - len(x), np.nan)]); mask = np.concatenate([mask, np.ones(n - len(mask), bool)])
    x = x[:n]; mask = mask[:n] | ~np.isfinite(x)
    good = ~mask
    if good.sum() < 0.5 * n:
        return None, np.ones(int(dur), bool), info
    x[mask] = np.nanmedian(x[good])
    x -= x[good].mean()
    tr.data = x
    tr.stats.starttime = T0
    tr.remove_response(inventory=INV, output="DEF", pre_filt=PRE_FILT, taper=True, taper_fraction=0.002)
    y = bandpass(tr.data, FS)
    y[mask] = 0.0
    ns = int(dur)
    flag1 = mask[: ns * int(FS)].reshape(ns, int(FS)).any(axis=1)
    # dead or stuck data (constant raw counts over 1 s) also flagged
    raw = d[: ns * int(FS)]
    if not np.ma.isMaskedArray(raw):
        rs = raw.reshape(ns, int(FS)); flag1 |= (rs.max(axis=1) == rs.min(axis=1))
    # dilate flags by 10 s for filter ringing
    k = np.flatnonzero(flag1)
    for off in range(-10, 11):
        flag1[np.clip(k + off, 0, ns - 1)] = True
    info["n_flag_s"] = int(flag1.sum())
    return y, flag1, info


def vertex_bins(n):
    edges = np.floor(np.arange(n) / FS / DT_V).astype(int)
    starts = np.flatnonzero(np.diff(np.concatenate([[-1], edges])))
    return starts


def vertex_energy_per_second(y, starts, ns):
    v = np.maximum.reduceat(np.abs(y), starts)
    tsec = (starts / FS).astype(int)
    e = np.bincount(tsec, weights=v ** 2 * DT_V, minlength=ns)[:ns]
    return e


def process(job):
    out = os.path.join(OUTDIR, f"{job.block_id}.npz")
    if os.path.exists(out):
        return job.block_id, "exists"
    T0 = UTCDateTime(job.t0_utc); dur = int(job.dur_s)
    ns = dur
    Y, F, infos = [], [], []
    for el in "123":
        y, f1, info = element_series(job.triad + el, T0, dur)
        Y.append(y); F.append(f1); infos.append(info)
    ok = [y is not None for y in Y]
    e1 = np.full((3, ns), np.nan); env = np.full((3, ns), np.nan)
    flags = np.ones((3, ns), bool)
    starts = vertex_bins(ns * int(FS))
    for k in range(3):
        if ok[k]:
            e1[k] = per_second_energy(Y[k], FS); flags[k] = F[k]
            env[k] = vertex_energy_per_second(Y[k], starts, ns)
    res = dict(e1=e1.astype(np.float32), env=env.astype(np.float32), flags=flags, ok=np.array(ok),
               t0=str(T0), eval_start=job.eval_start_s, eval_end=job.eval_end_s, role=job.role,
               info=json.dumps(infos))
    if all(ok) and job.role == "bg":
        res.update(inject(job, Y, e1, env, flags, starts))
    np.savez_compressed(out, **res)
    return job.block_id, "ok %s" % ok


def inject(job, Y, e1, env, flags, starts):
    rng = np.random.default_rng(int(job.seed))
    ns = e1.shape[1]
    anyflag = flags.any(axis=0)
    arr = e1.mean(axis=0)
    # noise-only references (window start index)
    ref = {}
    for W in WINDOWS:
        badW = np.convolve(anyflag, np.ones(W), "valid") > 0
        ref[("arr", W)] = running_median(window_energy(arr, W), badW)
        for k in range(3):
            ref[(k, W)] = running_median(window_energy(e1[k], W), badW)
    nL, nW, nD = len(LEVELS), len(WINDOWS), len(DURS)
    modes = ["e1", "e2", "e3", "arr", "v1", "v2", "v3"]
    SNR = np.full((N_INJ, nD, nW, len(modes), nL), np.nan, np.float32)
    MAXT = np.full_like(SNR, np.nan); MAX0 = np.full((N_INJ, nD, nW, len(modes)), np.nan, np.float32)
    ONS = np.zeros((N_INJ, nD), np.int32)
    lo, hi = int(job.eval_start_s) + 120, int(job.eval_end_s) - 200
    pan = 600
    for i in range(N_INJ):
        for d, D in enumerate(DURS):
            s, i0, t5, t95 = make_signal(rng, FS, D)
            # choose onset second where no flags in the affected span
            for _ in range(50):
                on = int(rng.integers(lo, hi))
                a_, b_ = on - 80, on + int(len(s) / FS) + 80
                if not anyflag[a_:b_].any():
                    break
            else:
                continue
            ONS[i, d] = on
            s0 = on * int(FS) - i0          # sample index of signal array start
            seg = slice(s0, s0 + len(s))
            secs = np.arange(s0 // int(FS), (s0 + len(s)) // int(FS) + 1)
            # per-second cross sums for the linear modes
            ss = np.bincount((np.arange(len(s)) + s0) // int(FS) - secs[0], weights=s ** 2 / FS, minlength=len(secs))
            ns_k = [np.bincount((np.arange(len(s)) + s0) // int(FS) - secs[0], weights=Y[k][seg] * s / FS, minlength=len(secs)) for k in range(3)]
            Pn = ref[("arr", 30)][min(on, len(ref[("arr", 30)]) - 1)] / 30.0
            amps = np.sqrt(10 ** (LEVELS / 10) * Pn)
            span_lo, span_hi = on + int(np.floor(t5)), on + int(np.ceil(t95))
            for w, W in enumerate(WINDOWS):
                wst = np.arange(span_lo - W + 1, span_hi + 1)      # windows overlapping the 5-95 % span
                wst = wst[(wst >= 0) & (wst + W <= ns)]
                mid = min(max(on + int(0.5 * (t5 + t95)) - W // 2, 0), len(ref[("arr", W)]) - 1)
                for m, mode in enumerate(modes[:4]):
                    base = arr if mode == "arr" else e1[m]
                    nref = ref[("arr", W)] if mode == "arr" else ref[(m, W)]
                    if not np.isfinite(nref[mid]):
                        continue
                    c0 = np.concatenate([[0.0], np.cumsum(base)])
                    E0 = c0[wst + W] - c0[wst]
                    MAX0[i, d, w, m] = np.max(10 * np.log10(E0 / nref[wst]))
                    if mode == "arr":
                        nsx = (ns_k[0] + ns_k[1] + ns_k[2]) / 3.0
                    else:
                        nsx = ns_k[m]
                    for l, a in enumerate(amps):
                        add = np.zeros(ns); add[secs[0]: secs[0] + len(secs)] = (2 * a * nsx + a * a * ss)[: ns - secs[0]]
                        c = np.concatenate([[0.0], np.cumsum(base + add)])
                        E = c[wst + W] - c[wst]
                        MAXT[i, d, w, m, l] = np.max(10 * np.log10(E / nref[wst]))
                        SNR[i, d, w, m, l] = 10 * np.log10(a * a / nref[mid])
            # vertex-envelope modes: reference = median over the 10-min panel (noise-only windows)
            p0 = (on // pan) * pan
            for k in range(3):
                vv = env[k]
                y = Y[k]
                sec_lo = s0 // int(FS) - 1; sec_hi = (s0 + len(s)) // int(FS) + 1
                bsel = (starts >= sec_lo * int(FS)) & (starts < (sec_hi + 1) * int(FS))
                bst = starts[bsel]
                bend = np.append(starts[1:], ns * int(FS))[bsel]
                for l, a in enumerate(amps):
                    yy = y[bst[0]: bend[-1]].copy()
                    off = s0 - bst[0]
                    yy[off: off + len(s)] += a * s
                    vloc = np.maximum.reduceat(np.abs(yy), bst - bst[0])
                    tsec = (bst / FS).astype(int)
                    e_new = vv.astype(float).copy()
                    e_new[np.unique(tsec)] = 0.0
                    e_new += np.bincount(tsec, weights=vloc ** 2 * DT_V, minlength=ns)[:ns]
                    # partial-second edges: keep untouched parts approx (bins fully replaced)
                    for w, W in enumerate(WINDOWS):
                        pw = np.arange(p0, p0 + pan - W + 1)
                        pw = pw[(pw + W <= ns)]
                        cv = np.concatenate([[0.0], np.cumsum(vv)])
                        nref = np.median(cv[pw + W] - cv[pw])
                        wst = np.arange(span_lo - W + 1, span_hi + 1)
                        wst = wst[(wst >= p0) & (wst + W <= min(p0 + pan, ns))]
                        if len(wst) == 0:
                            continue
                        c = np.concatenate([[0.0], np.cumsum(e_new)])
                        E = c[wst + W] - c[wst]
                        MAXT[i, d, w, 4 + k, l] = np.max(10 * np.log10(E / nref))
                        # SNR for envelope form uses the raw-trace definition (true band energy / raw noise ref)
                        SNR[i, d, w, 4 + k, l] = 10 * np.log10(a * a / ref[(k, W)][mid]) if np.isfinite(ref[(k, W)][mid]) else np.nan
                        if l == 0:
                            E0 = cv[wst + W] - cv[wst]
                            MAX0[i, d, w, 4 + k] = np.max(10 * np.log10(E0 / nref))
    return dict(inj_snr=SNR, inj_maxT=MAXT, inj_max0=MAX0, inj_onset=ONS, levels=LEVELS,
                durs=np.array(DURS), windows=np.array(WINDOWS), modes=np.array(modes))


from collections import namedtuple
JobT = namedtuple('JobT', ['block_id','triad','t0_utc','dur_s','eval_start_s','eval_end_s','role','seed'])


def init(outdir):
    global OUTDIR
    OUTDIR = outdir


if __name__ == "__main__":
    jobs = pd.read_csv(sys.argv[1]); OUTDIR = sys.argv[2]; nproc = int(sys.argv[3])
    os.makedirs(OUTDIR, exist_ok=True)
    lim = int(sys.argv[4]) if len(sys.argv) > 4 else len(jobs)
    t0 = time.time()
    with Pool(nproc, initializer=init, initargs=(OUTDIR,)) as p:
        for i, (b, msg) in enumerate(p.imap_unordered(process, [JobT(**r) for r in jobs.head(lim).to_dict('records')])):
            print(f"{i+1}/{lim} {b} {msg} {time.time()-t0:.0f}s", flush=True)
