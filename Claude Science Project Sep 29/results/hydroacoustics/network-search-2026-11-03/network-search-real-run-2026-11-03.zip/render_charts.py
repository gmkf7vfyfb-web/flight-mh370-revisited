import sys, matplotlib
matplotlib.use('Agg')
import matplotlib as mpl, matplotlib.pyplot as plt
def apply_figure_style(sizes=(8, 7, 6)):
    b, s, t = sizes
    mpl.rcParams.update({'font.size': b, 'axes.titlesize': b, 'axes.labelsize': b, 'xtick.labelsize': t, 'ytick.labelsize': t,
                         'legend.fontsize': s, 'axes.spines.top': False, 'axes.spines.right': False, 'xtick.direction': 'out',
                         'ytick.direction': 'out', 'legend.frameon': False, 'savefig.dpi': 300, 'pdf.fonttype': 42, 'ps.fonttype': 42,
                         'axes.grid': False, 'axes.titleweight': 'normal'})
exec(open('make_charts2.py').read())
print(make_charts2(sys.argv[1]))
