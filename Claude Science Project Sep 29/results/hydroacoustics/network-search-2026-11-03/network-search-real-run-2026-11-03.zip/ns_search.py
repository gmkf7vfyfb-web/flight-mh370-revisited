"""First network detection search on the 8 March 2014 data held (source-grid method X18).
Implements prereg.json (ns-prereg-2026-11-03a) exactly. Inputs: level_correction.json and pd_curves.json in the shared
schemas, or the PROVISIONAL defaults written in the pre-registration.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numba
import numpy as np
import pandas as pd
from scipy import stats

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import ns_readers as R  # noqa: E402

PRE = json.loads((HERE / 'prereg.json').read_text())
A = R.A
TL_CSV = A / 'a11a80dd-d40d-4e82-9f71-1025c3fe656c/v3bbc0a2c_tl_dense_bands.csv'
SEC_CSV = A / '62c14bec-89bb-4434-9666-61f71a5cd6b7/v97e0f6e3_path-sections-index.csv'

STATIONS = ['H01W', 'H08S', 'SSEIR', 'SWAMS3', 'IMOS3315', 'IMOS3376', 'IMOS3250', 'IMOS3274', 'IMOS3275']
GROUPS = {g: v for g, v in PRE['nulls']['A_time_slide_primary']['groups'].items()}
NOISE_PRE = {k: v['noise_level_db'] for k, v in PRE['stations_primary'].items()}
BAND = {k: ((10.0, 40.0) if k.startswith('IMOS') else (5.0, 40.0)) for k in STATIONS}
V_KM_S, T_BIAS, T_SD = 1.480, -3.1, 8.6
IMPACT_S = np.arange(19 * 60 + 30, 45 * 60 + 1, 30.0)          # seconds after 00:00 UTC 8 Mar
LOGE = np.round(np.arange(1.0, 10.0 + 1e-9, 0.05), 2)
CORNERS = [5.0, 1.0, 0.2]
N_SLOPE = 3.1
SRC_DEPTH = 10.0


# ------------------------------------------------------------------ inputs
def provisional_level_correction():
    cls = ['clear deep path', 'ridge near the channel axis', 'ridge above the channel axis', 'blocked']
    d = dict(bias_db=0.0, slope_db_per_oct=0.0, sd_db=6.0, n_sources=0, n_bands=0)
    return {'version': 'PROVISIONAL (prereg default)', 'classes': {c: dict(d) for c in cls}, 'global': dict(d), 'notes': 'PROVISIONAL'}


def provisional_pd_curves(window_s=60.0):
    st = {}
    for k in STATIONS:
        st[k] = dict(data_form='', noise_level_db=NOISE_PRE[k], noise_sd_db=None,
                     fa={'1/day': dict(threshold_snr_db=10.0, snr50_db=10.0, sigma_db=3.0)}, basis='PROVISIONAL (prereg default)')
    return {'version': 'PROVISIONAL (prereg default)', 'detector': 'T1 band-energy excess', 'window_s': window_s, 'band_hz': [5, 40], 'stations': st}


def band_fraction(fb, flo, fhi, fc, n=N_SLOPE):
    lo, hi = max(fb * 2 ** (-1 / 6), flo), min(fb * 2 ** (1 / 6), fhi)
    if hi <= lo:
        return 0.0

    def F(f):  # integral of S from 0 to f
        return f if f <= fc else fc + fc ** n * (f ** (1 - n) - fc ** (1 - n)) / (1 - n)
    return (F(hi) - F(lo)) / (fc * n / (n - 1))


def load_paths():
    tl = pd.read_csv(TL_CSV)
    tl = tl[(tl.src_depth_m == SRC_DEPTH) & tl.station.isin(STATIONS)]
    pts = tl[['src_lat', 'src_lon']].drop_duplicates().sort_values('src_lat').reset_index(drop=True)
    return tl, pts


PATH_CLASS_CSV = A / '28956ab5-fd10-473a-bd16-4ea5d530e2a6/vb3106ff5_path-classes-royer-dense.csv'


def path_classes(pts, exact=True):
    """Class for each (arc point, station). Amendment A1 (3 Nov 2026, before the real run): exact class per dense path
    from path-classes-royer-dense.csv (project rule on each section). exact=False gives the original prereg fallback."""
    if exact:
        pc = pd.read_csv(PATH_CLASS_CSV)
        pc = pc[pc.set == 'dense'].set_index('name').path_class
        out = {}
        for k in STATIONS:
            for lat in pts.src_lat:
                nm = f'arc{abs(lat):.1f}S-{k}'
                out[(lat, k)] = pc[nm] if nm in pc.index else 'blocked'
        return out
    sec = pd.read_csv(SEC_CSV)
    sec = sec[sec.group == 'arc_sparse']
    out = {}
    for k in STATIONS:
        s = sec[sec.station == k]
        for lat in pts.src_lat:
            j = np.argmin(np.abs(s.src_lat.to_numpy() - lat))
            out[(lat, k)] = s.path_class.iloc[j]
    return out


def select_level_case(levc, case='primary'):
    """Return a level-correction dict with 'classes' and 'global' for the case: 'primary' = top level;
    otherwise levc['alternatives'][case]. An alternative with only global keys applies to every class."""
    if case == 'primary':
        d = levc
    else:
        d = levc['alternatives'][case]
    keys = ('bias_db', 'slope_db_per_oct', 'sd_db')
    glob = d.get('global') or {k: d[k] for k in keys if k in d}
    glob = {k: float(glob.get(k, 0.0)) for k in keys}
    cls = {c: {k: float(v.get(k, glob[k])) for k in keys} for c, v in (d.get('classes') or {}).items()}
    for c in ['clear deep path', 'ridge near the channel axis', 'ridge above the channel axis', 'blocked']:
        cls.setdefault(c, dict(glob))
    return {'version': f"{levc.get('version')} [{case}]", 'classes': cls, 'global': glob, 'notes': d.get('notes', '')}


def gain_tables(tl, pts, levc, pdc, W):
    """G[a,k,c] in dB such that SNR_pred(E) = 10 log10(E) + G; sd_model[a,k]; travel time tt[a,k]; avail[a,k]."""
    cls = path_classes(pts)
    nA, nK, nC = len(pts), len(STATIONS), len(CORNERS)
    G = np.full((nA, nK, nC), np.nan)
    sdm = np.full((nA, nK), np.nan)
    tt = np.full((nA, nK), np.nan)
    pclass = np.empty((nA, nK), dtype=object)
    for a, lat in enumerate(pts.src_lat):
        for k, st in enumerate(STATIONS):
            d = tl[(tl.src_lat == lat) & (tl.station == st)]
            pclass[a, k] = cls[(lat, st)]
            if d.empty:
                continue                                        # land path: missing
            lc = levc['classes'].get(cls[(lat, st)], levc['global'])
            N = pdc['stations'][st]['noise_level_db'] + 10 * np.log10(W)
            flo, fhi = BAND[st]
            for c, fc in enumerate(CORNERS):
                tot = 0.0
                for _, r in d.iterrows():
                    fr = band_fraction(r.fc_hz, flo, fhi, fc)
                    if fr <= 0:
                        continue
                    corr = lc['bias_db'] + lc['slope_db_per_oct'] * np.log2(r.fc_hz / 10.0)
                    tot += 10 ** ((170.8 + 10 * np.log10(fr) - r.tl_db + corr) / 10)
                G[a, k, c] = 10 * np.log10(tot) - N
            sdm[a, k] = lc['sd_db']
            tt[a, k] = d.range_km.iloc[0] / V_KM_S + T_BIAS
    return G, sdm, tt, pclass


# ------------------------------------------------------------------ data series
def load_series():
    ev = pd.read_pickle(HERE / 'imos_eventday_cache.pkl')
    S = {'H01W': R.h01w_composite(), 'H08S': R.kadri_series('H08S'),
         'SSEIR': R.royer_series('SSEIR', 'appendix'), 'SWAMS3': R.royer_series('SWAMS3', 'appendix')}
    for st in R.IMOS_CAL:
        S[st] = R.imos_series_from_cache(st, ev)
    return S


def load_imos_long():
    """Event day + 14-day background (3376, 3274, 3250), without duplicate times. For null B."""
    ev = pd.read_pickle(HERE / 'imos_eventday_cache.pkl')
    bg = pd.read_pickle(HERE / 'imos_background_cache.pkl')
    out = {}
    for st in R.IMOS_CAL:
        e = ev[ev.station == st]
        b = bg[bg.station == st]
        if len(b):
            b = b[(b.t0 + b.dt < e.t0.min()) | (b.t0 > e.t0.max() + e.dt.max())].copy()
            b['block'] = b.block + 100000
        c = pd.concat([e, b], ignore_index=True)
        out[st] = R.imos_series_from_cache(st, c)
    return out


@numba.njit(cache=True)
def _window_R(tc, dt, p, blk, ws, W, ref_half, excl, min_ref, cov_min):
    n = ws.size
    Rv = np.full(n, np.nan)
    Weff = np.zeros(n)
    for j in range(n):
        a = ws[j]
        b = a + W
        i0 = np.searchsorted(tc, a)
        i1 = np.searchsorted(tc, b)
        if i1 <= i0:
            continue
        cov = 0.0
        for i in range(i0, i1):
            cov += dt[i]
        if cov < cov_min * W:
            continue
        wc = 0.5 * (a + b)
        r0 = np.searchsorted(tc, wc - ref_half)
        r1 = np.searchsorted(tc, wc + ref_half)
        num = 0.0
        den = 0.0
        ok = True
        # distinct blocks inside the window
        for i in range(i0, i1):
            bi = blk[i]
            seen = False
            for q in range(i0, i):
                if blk[q] == bi:
                    seen = True
                    break
            if seen:
                continue
            # reference power for block bi
            cnt = 0
            for r in range(r0, r1):
                if blk[r] == bi and (tc[r] < a - excl or tc[r] > b + excl):
                    cnt += 1
            if cnt == 0:
                ok = False
                break
            ref = np.empty(cnt)
            rdt = 0.0
            m = 0
            for r in range(r0, r1):
                if blk[r] == bi and (tc[r] < a - excl or tc[r] > b + excl):
                    ref[m] = p[r]
                    rdt += dt[r]
                    m += 1
            if rdt < min_ref:
                ok = False
                break
            ref.sort()
            keep = int(np.floor(0.95 * cnt + 1e-9))
            if keep < 1:
                keep = 1
            pref = ref[:keep].mean()
            for i2 in range(i0, i1):
                if blk[i2] == bi:
                    num += p[i2] * dt[i2]
                    den += pref * dt[i2]
        if ok and den > 0:
            Rv[j] = num / den
            Weff[j] = cov
    return Rv, Weff


class Grid:
    """R on a 0.5-s grid of window starts for one station."""

    def __init__(self, s: R.BandSeries, W: float, step=0.5):
        o = np.argsort(s.t0 + s.dt / 2)
        self.tc = (s.t0 + s.dt / 2)[o]
        self.dt, self.p, self.blk = s.dt[o], (s.e / s.dt)[o], s.block[o].astype(np.int64)
        self.T0 = float(s.t0.min())
        self.T1 = float((s.t0 + s.dt).max())
        self.span = self.T1 - self.T0
        self.step = step
        self.ws0 = np.floor((self.T0 - W) / step) * step
        ws = np.arange(self.ws0, self.T1 + step, step)
        self.Rv, _ = _window_R(self.tc, self.dt, self.p, self.blk, ws, W, 300.0, 30.0, 60.0, 0.9)
        self.W = W

    def lookup(self, ws):
        idx = np.rint((np.asarray(ws) - self.ws0) / self.step).astype(np.int64)
        out = np.full(idx.shape, np.nan)
        m = (idx >= 0) & (idx < self.Rv.size)
        out[m] = self.Rv[idx[m]]
        return out

    def lookup_cyclic(self, ws, delta):
        x = self.T0 + np.mod(np.asarray(ws) + delta - self.T0, self.span)
        out = self.lookup(x)
        out[x + self.W > self.T1] = np.nan                   # crosses the wrap point -> missing
        return out


# ------------------------------------------------------------------ likelihoods
def snr_db(Rv):
    return 10 * np.log10(np.maximum(Rv - 1.0, 1e-3))


def binary_terms(G, sdm, pdc, W, fa='1/day'):
    """l1, l0 [a,k,c,e] = log(P_detect/p_fa), log((1-P_detect)/(1-p_fa)); PD [a,k,c,e]."""
    pfa = W / (86400.0 if fa == '1/day' else 3600.0)
    snr50 = np.array([pdc['stations'][k]['fa'][fa]['snr50_db'] for k in STATIONS])
    sig = np.array([pdc['stations'][k]['fa'][fa]['sigma_db'] for k in STATIONS])
    pred = 10 * LOGE[None, None, None, :] + G[..., None]                     # a,k,c,e
    stot = np.sqrt(sig[None, :] ** 2 + sdm ** 2)[:, :, None, None]
    PD = stats.norm.cdf((pred - snr50[None, :, None, None]) / stot)
    PD = np.where(np.isnan(PD), 0.0, PD)
    Pdet = pfa + (1 - pfa) * PD
    l1 = np.log(Pdet / pfa)
    l0 = np.log(np.clip(1 - Pdet, 1e-300, None) / (1 - pfa))
    return l1, l0, PD, pfa


def thresholds(pdc, fa='1/day'):
    return np.array([pdc['stations'][k]['fa'][fa]['threshold_snr_db'] for k in STATIONS])


class Graded:
    """log Lambda_k(R_obs, mu) table, mu = predicted SNR dB (bias included), spread sd_model."""
    LNR = np.linspace(np.log(0.05), np.log(1e4), 600)
    MU = np.arange(-40.0, 90.01, 0.5)

    def __init__(self, lnR_null, sd):
        x = lnR_null[np.isfinite(lnR_null)]
        n = x.size
        kde = stats.gaussian_kde(x)
        grid = np.linspace(np.log(1e-4), np.log(1e5), 4000)
        h = (1 - 1 / (n + 1)) * kde(grid)
        lo, hi = np.log(0.05), np.log(1e4)
        h += (1 / (n + 1)) * ((grid >= lo) & (grid <= hi)) / (hi - lo)
        self.grid, self.h, self.n = grid, h, n
        z, w = np.polynomial.hermite_e.hermegauss(40)
        w = w / w.sum()
        Rg = np.exp(self.LNR)
        g0R = self._g0(Rg)
        tab = np.empty((self.LNR.size, self.MU.size))
        for j, mu in enumerate(self.MU):
            s = 10 ** ((mu + sd * z) / 10)                                    # 40 signal ratios
            num = (self._g0(Rg[:, None] - s[None, :]) * w[None, :]).sum(1)
            tab[:, j] = np.log(np.maximum(num, 1e-300)) - np.log(g0R)
        self.tab = tab

    def _g0(self, x):
        out = np.zeros_like(x, dtype=float)
        m = x > 0
        out[m] = np.interp(np.log(x[m]), self.grid, self.h, left=0.0, right=0.0) / x[m]
        return out

    def loglam(self, Rv, mu):
        """Rv: [...], mu: [..., e] -> log Lambda [..., e]; nan R -> 0."""
        lr = np.clip(np.log(np.where(np.isfinite(Rv), Rv, 1.0)), self.LNR[0], self.LNR[-1])
        fi = (lr - self.LNR[0]) / (self.LNR[1] - self.LNR[0])
        mi = np.clip((mu - self.MU[0]) / (self.MU[1] - self.MU[0]), 0, self.MU.size - 1.000001)
        i0 = np.floor(fi).astype(int)
        i0 = np.clip(i0, 0, self.LNR.size - 2)
        tr = fi - i0
        j0 = np.floor(mi).astype(int)
        tm = mi - j0
        i0b = np.broadcast_to(i0[..., None], mu.shape)
        trb = np.broadcast_to(tr[..., None], mu.shape)
        T = self.tab
        v = ((1 - trb) * (1 - tm) * T[i0b, j0] + trb * (1 - tm) * T[i0b + 1, j0] + (1 - trb) * tm * T[i0b, j0 + 1] + trb * tm * T[i0b + 1, j0 + 1])
        return np.where(np.isfinite(Rv)[..., None], v, 0.0)


def network(Robs, avail, G, l1, l0, thr, graded=None, sdm=None, station_mask=None):
    """Robs[a,i,k] (nan = missing). Returns dict of arrays [a,i,c(,e)]."""
    obs = np.isfinite(Robs) & avail[:, None, :]
    if station_mask is not None:
        obs = obs & station_mask[None, None, :]
    D = (snr_db(np.where(obs, Robs, 1.0)) >= thr[None, None, :]) & obs
    # binary: sum_k obs*(D*l1 + (1-D)*l0) -> [a,i,c,e]
    o = obs.astype(float)
    d = D.astype(float)
    l1n = np.nan_to_num(l1)
    l0n = np.nan_to_num(l0)
    LL = np.einsum('aik,akce->aice', o * d, l1n) + np.einsum('aik,akce->aice', o * (1 - d), l0n)
    out = dict(obs=obs, D=D, LL=LL, S_bin=LL.max(-1))
    if graded is not None:
        LG = np.zeros_like(LL)
        for k in range(len(STATIONS)):
            if not obs[:, :, k].any():
                continue
            mu = 10 * LOGE[None, None, :] + np.nan_to_num(G[:, k, :], nan=-999)[:, :, None]   # a,c,e
            for sdv, gtab in graded[k].items():                                                # one table per level sd
                sel = np.isclose(np.nan_to_num(sdm[:, k], nan=-1), sdv)
                if not sel.any():
                    continue
                Rk = np.where(obs[sel, :, k], Robs[sel, :, k], np.nan)                           # a_sel,i
                for c in range(len(CORNERS)):
                    LG[sel, :, c, :] += gtab.loglam(Rk, np.broadcast_to(mu[sel][:, None, c, :], Rk.shape + (LOGE.size,)))
        out['LG'] = LG
        out['S_gr'] = LG.max(-1)
    return out


def upper_limits(net, PD):
    """exclusion90 from non-detecting observed stations; credible90 from binary LL with log-uniform prior."""
    nd = (net['obs'] & ~net['D']).astype(float)                         # a,i,k
    logsurv = np.einsum('aik,akce->aice', nd, np.log(np.clip(1 - PD, 1e-300, None)))
    hit = logsurv <= np.log(0.10)
    first = np.where(hit.any(-1), hit.argmax(-1), -1)
    excl = np.where(first >= 0, LOGE[np.clip(first, 0, None)], np.nan)

    def cred(LL):
        w = np.exp(LL - LL.max(-1, keepdims=True))
        cdf = np.cumsum(w, -1) / w.sum(-1, keepdims=True)
        return LOGE[(cdf >= 0.90).argmax(-1)]
    res = dict(log10E_excl90=excl, log10E_cred90=cred(net['LL']))
    if 'LG' in net:
        res['log10E_cred90_graded'] = cred(net['LG'])
    return res


# ------------------------------------------------------------------ nulls
def null_offsets(grids, n, seed):
    """Null A offsets: one per group per trial (prereg)."""
    rng = np.random.default_rng(seed)
    offs = np.zeros((n, len(STATIONS)))
    for g, members in GROUPS.items():
        ref = grids[members[0]]
        if members[0].startswith('IMOS'):
            kmax = int(min(grids[m].span for m in members) // 900) - 4
            ks = rng.integers(4, kmax + 1, size=n)
            d = ks * 900.0
        else:
            mmax = int(ref.span // 30) - 10
            ms = rng.integers(10, mmax + 1, size=n)
            d = ms * 30.0
        for m in members:
            offs[:, STATIONS.index(m)] = d
    return offs


def run_null_A(grids, WS, avail, G, l1, l0, thr, graded, offs, sdm, station_mask=None):
    nT = offs.shape[0]
    Sb = np.zeros((nT,) + WS.shape[:2] + (len(CORNERS),), dtype=np.float32)
    Sg = np.zeros_like(Sb)
    Rn_store = []
    for j in range(nT):
        Rn = np.full(WS.shape, np.nan)
        for k, st in enumerate(STATIONS):
            Rn[:, :, k] = grids[st].lookup_cyclic(WS[:, :, k], offs[j, k])
        Rn[~np.broadcast_to(avail[:, None, :], Rn.shape)] = np.nan
        net = network(Rn, avail, G, l1, l0, thr, graded=graded, sdm=sdm, station_mask=station_mask)
        Sb[j], Sg[j] = net['S_bin'], net['S_gr']
        Rn_store.append(Rn.astype(np.float32))
    return Sb, Sg, np.stack(Rn_store)


def run_null_B(long_grids, WS, avail, G, l1, l0, thr, graded, deltas, sdm):
    """Common shift of all IMOS loggers (no wrap); a logger without data at the shifted time is missing."""
    imos = np.array([s.startswith('IMOS') for s in STATIONS])
    Sb = np.zeros(len(deltas), dtype=np.float32)
    Sg = np.zeros_like(Sb)
    nobs = np.zeros(len(deltas), dtype=np.int64)
    for j, dlt in enumerate(deltas):
        Rn = np.full(WS.shape, np.nan)
        for k, st in enumerate(STATIONS):
            if imos[k]:
                Rn[:, :, k] = long_grids[st].lookup(WS[:, :, k] + dlt)
        Rn[~np.broadcast_to(avail[:, None, :], Rn.shape)] = np.nan
        net = network(Rn, avail, G, l1, l0, thr, graded=graded, sdm=sdm, station_mask=imos)
        Sb[j], Sg[j] = net['S_bin'].max(), net['S_gr'].max()
        nobs[j] = int(np.isfinite(Rn).sum())
    return Sb, Sg, nobs
