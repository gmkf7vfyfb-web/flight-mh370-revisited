# First network detection search, 8 March 2014 data held: pre-registration

Version ns-prereg-2026-11-03a. Written 3 Nov 2026 before any statistic in a predicted arrival window is computed.
The full rules are in prereg.json (same version). This note gives them in short form. Language: ASD-STE100.

## What is tested
- A source on the 7th arc (43 points, 41.0 to 20.0 S, every 0.5 deg). We do not sample offsets across the arc.
- Impact time 00:19:30 to 00:45:00 UTC, in steps of 30 s (52 times). Alternate-configuration dives reach the sea at about 00:20 to 00:22:20. Normal-configuration glides can last to about 00:40.
- Acoustic energy 10^1 to 10^10 J (steps of 0.05 in log10). Corner frequencies 5, 1 and 0.2 Hz. Source depth 10 m.

## Arrival time
- Onset = impact time + path length / 1.480 km/s - 3.1 s. The timing error is 8.6 s (1 sd).
- Reason: this rule fits 143 hydrophone picks of Royer's 20 events on the same day. The IDC rule (+10 s, sd 46 s) is for earthquakes with a seismic leg. We use it only to match earthquakes.

## Statistic at each station (T1)
- The window is 60 s, from 20 s before to 40 s after the predicted onset.
- R = energy in the window / (window length x local noise power). The local noise is the trimmed mean (top 5 % removed) of the same record or panel, within 300 s, without the window and 30 s each side.
- The observed signal-to-noise ratio is 10 log10(R - 1).
- Band: 5-40 Hz. IMOS loggers use 10-40 Hz, because of their 8 Hz high-pass filter.
- A window is observed only if data cover 90 % of it. Otherwise it is missing.

## Stations
- Cape Leeuwin (H01W): Kadri trace 00:27-00:57, Royer spectrogram at other times. Diego Garcia South (H08S): Kadri trace 01:00-01:20.
- OHASISBIO SSEIR and SWAMS3: Royer spectrograms 00:00-02:00.
- IMOS loggers 3315, 3376 (Perth Canyon), 3250 (Scott Reef), 3274, 3275 (Portland): raw records, 307 s in each 15 min.
- Not used: SWAMS1 (no data), SWAMS2, MAD, NCRO, WKER (only 3-min panels and no noise level), Diego Garcia North (blocked).

## Likelihood
- Primary: detection (signal-to-noise at or above the threshold) gives P_detect. Non-detection gives 1 - P_detect. P_detect includes the false-alarm probability.
- Secondary: the graded form uses the full value of R and the station's own noise distribution.
- A station with no data gives no evidence. Missing data is never a non-detection.
- The cell score is the highest log likelihood ratio over energy.

## Provisional inputs (dry run)
- Level correction: bias 0 dB, slope 0, sd 6 dB for every path class. Detection: 50 % at 10 dB, sigma 3 dB, threshold 10 dB, every station. Every dry-run output has the label PROVISIONAL.

## Upper limits
- 90 % exclusion: the lowest energy at which the probability of all the observed non-detections is 10 % or less.
- 90 % credible limit: with a log-uniform prior from 10^1 to 10^10 J. This limit depends on the prior.

## Null tests
- A (primary): 500 time slides. Each station group gets its own offset: at least 5 min for digitised data, at least 1 h in steps of 15 min for IMOS. Co-located loggers move together. Empirical p = (1 + number of null best scores >= observed) / 501.
- B (strict): all IMOS loggers move together by at least 3 h into the event day and the 14-day background.

## Known events
- We compare each listed window with Royer's picks and events, catalogued earthquakes, Diego Garcia South airgun shots, Kadri's transients and the CMST detections. We give a match likelihood and a chance-match rate.
- Royer's unexplained events, the CMST 01:34:50 event and Kadri's transients are candidates. We never use them to explain a candidate away. A match is a label, not an exclusion.
