"""Real run of the network detection search (prereg ns-prereg-2026-11-03a + A1 v83dd444b + A2 v5eb84cde).
usage: python run_search2.py --out DIR --level level_correction.json --pd pd_curves.json
         --case {zero_bias_wide,indian_ocean_posthoc,all_ocean_check} --stations {primary,ohasisbio_picks,no_royer_h01w}
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ns_readers as R  # noqa: E402
import ns_search as NS1  # noqa: E402
import ns_search2 as S  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument('--out', required=True)
ap.add_argument('--level', required=True)
ap.add_argument('--pd', required=True)
ap.add_argument('--case', default='zero_bias_wide')
ap.add_argument('--stations', default='primary')
ap.add_argument('--nnull', type=int, default=500)
ap.add_argument('--skip-null-b', action='store_true')
a = ap.parse_args()
out = Path(a.out)
out.mkdir(parents=True, exist_ok=True)
T0 = time.time()
log = lambda *x: print(f'[{time.time() - T0:7.1f}s]', *x, flush=True)  # noqa: E731

CASES = {'zero_bias_wide': ('zero_bias_wide', 'primary: zero bias, wide spread (sd 12.58 dB)'),
         'indian_ocean_posthoc': ('primary', 'sensitivity: Indian Ocean post hoc fit (spread x1.98)'),
         'all_ocean_check': ('all_ocean_class_fit', 'check only: failed all-ocean class fit')}
STMODE = {'primary': 'level data only (Cape Leeuwin, Diego Garcia South, 5 IMOS loggers)',
          'ohasisbio_picks': 'level data + OHASISBIO Royer picks with the post hoc picks curve (sensitivity)',
          'no_royer_h01w': 'level data without the Royer spectrogram part at Cape Leeuwin (sensitivity)'}
levc_raw = json.loads(Path(a.level).read_text())
pdc = json.loads(Path(a.pd).read_text())
levc = NS1.select_level_case(levc_raw, CASES[a.case][0])
W = float(pdc['window_s'])
W_START = -W / 3.0
RUN_LABEL = f"{CASES[a.case][1]}; stations: {STMODE[a.stations]}"
log(RUN_LABEL, '| level', levc['version'], '| pd', pdc['version'], '| W', W)

grids = S.build_grids(W, a.stations)
tl, pts = S.load_paths()
G, sdm, tt, pclass = S.gain_tables(tl, pts, levc, pdc, W)
avail = np.isfinite(G[:, :, 0])
lat = pts.src_lat.to_numpy()
nA, nI, nK, nC = len(pts), len(S.IMPACT_S), len(S.STATIONS), len(S.CORNERS)
WS = S.IMPACT_S[None, :, None] + np.nan_to_num(tt)[:, None, :] + W_START
bin_mask = np.array([(st in S.LEVEL_ST) or (a.stations == 'ohasisbio_picks' and st in S.PICK_ST) for st in S.STATIONS])
graded_st = S.LEVEL_ST
kH = S.STATIONS.index('H01W')


def mode_mask(Rn, Fn):
    if a.stations == 'no_royer_h01w':
        Rn[:, :, kH] = np.where(Fn[:, :, kH] == 1, np.nan, Rn[:, :, kH])
    return Rn


Robs, Fobs = S.lookup_all(grids, WS, avail)
Robs = mode_mask(Robs, Fobs)
FAS = ['1/day', '1/hour']
CT = {fa: S.curve_table(pdc, fa, grids, W) for fa in FAS}
BT = {fa: S.binary_terms(G, sdm, CT[fa][0]) for fa in FAS}
Tday = CT['1/day'][0]
l1, l0, Pdet = BT['1/day']
graded, f0 = S.graded_tables(grids, sdm, pdc, W, graded_st)
log('graded tables', {f'{k[0]}/{k[1]}': len(v) for k, v in f0.items()})
net = S.network(Robs, Fobs, avail, G, l1, l0, Tday, sdm, bin_mask, graded)
UL = S.upper_limits(net, Pdet, Tday, Fobs)
neth = S.network(Robs, Fobs, avail, G, BT['1/hour'][0], BT['1/hour'][1], CT['1/hour'][0], sdm, bin_mask)
ULh = S.upper_limits(neth, BT['1/hour'][2], CT['1/hour'][0], Fobs)
log('observed: S_gr', float(net['S_gr'].max()), 'S_bin', float(net['S_bin'].max()), 'S_bin 1/hour', float(neth['S_bin'].max()))

# ---------------------------------------------------------------- null A
offs = S.null_offsets(grids, a.nnull, 20261103)
SbA = np.zeros((a.nnull, nA, nI, nC), np.float32)
SgA = np.zeros_like(SbA)
SbAh = np.zeros(a.nnull, np.float32)
for j in range(a.nnull):
    Rn, Fn = S.lookup_all(grids, WS, avail, offs[j], cyclic=True)
    Rn = mode_mask(Rn, Fn)
    nj = S.network(Rn, Fn, avail, G, l1, l0, Tday, sdm, bin_mask, graded)
    SbA[j], SgA[j] = nj['S_bin'], nj['S_gr']
    SbAh[j] = S.network(Rn, Fn, avail, G, BT['1/hour'][0], BT['1/hour'][1], CT['1/hour'][0], sdm, bin_mask)['S_bin'].max()
log('null A done')
best_gr, best_bin, best_binh = float(net['S_gr'].max()), float(net['S_bin'].max()), float(neth['S_bin'].max())
mx_gr, mx_bin = SgA.reshape(a.nnull, -1).max(1), SbA.reshape(a.nnull, -1).max(1)
pval = lambda null, obs: (1 + int((null >= obs - 1e-9).sum())) / (1 + null.size)  # noqa: E731
p_gr, p_bin, p_binh = pval(mx_gr, best_gr), pval(mx_bin, best_bin), pval(SbAh, best_binh)
local_p_gr = (1 + (SgA >= net['S_gr'][None] - 1e-9).sum(0)) / (1 + a.nnull)
glob_p_cell = ((1 + (mx_gr[None, :] >= net['S_gr'].reshape(-1, 1) - 1e-9).sum(1)) / (1 + a.nnull)).reshape(net['S_gr'].shape)

# ---------------------------------------------------------------- null B (IMOS common shift)
nullB = {}
if not a.skip_null_b:
    lg = S.build_long_imos(W)
    imask = np.array([s in S.IMOS for s in S.STATIONS])
    gI = {k: v for k, v in graded.items() if S.STATIONS[k[0]] in S.IMOS}
    netI = S.network(Robs, Fobs, avail, G, l1, l0, Tday, sdm, imask, gI)
    oI_gr = float(np.where(np.isfinite(netI['S_gr']), netI['S_gr'], 0).max())
    oI_bin = float(netI['S_bin'].max())
    nobs0 = int((np.isfinite(Robs) & imask[None, None, :] & avail[:, None, :]).sum())
    deltas = np.arange(-8 * 86400, 7 * 86400 + 1, 900.0)
    deltas = deltas[np.abs(deltas) >= 3 * 3600]
    SbB, SgB, nobsB = [], [], []
    for dl in deltas:
        Rn = np.full(WS.shape, np.nan)
        Fn = np.zeros(WS.shape, np.int8)
        for k, st in enumerate(S.STATIONS):
            if st in S.IMOS:
                Rn[:, :, k], Fn[:, :, k] = lg[st].lookup(WS[:, :, k] + dl)
        Rn[~np.broadcast_to(avail[:, None, :], Rn.shape)] = np.nan
        nb = S.network(Rn, Fn, avail, G, l1, l0, Tday, sdm, imask, gI)
        SbB.append(nb['S_bin'].max())
        SgB.append(nb['S_gr'].max())
        nobsB.append(int(np.isfinite(Rn).sum()))
    SbB, SgB, nobsB = map(np.array, (SbB, SgB, nobsB))
    use = nobsB >= 0.5 * nobs0
    nullB = dict(observed_imos_window_count=nobs0, n_shifts=int(use.sum()), n_shifts_total=int(deltas.size),
                 observed_imos_S_gr=oI_gr, observed_imos_S_bin=oI_bin, p_graded=pval(SgB[use], oI_gr), p_binary=pval(SbB[use], oI_bin),
                 null_graded_p5_p50_p95=np.percentile(SgB[use], [5, 50, 95]).round(3).tolist())
    np.savez_compressed(out / 'null_B.npz', SbB=SbB, SgB=SgB, nobsB=nobsB, deltas=deltas)
    log('null B', nullB)
np.savez_compressed(out / 'null_A.npz', SbA=SbA, SgA=SgA, SbAh=SbAh, offs=offs, best_null_graded=mx_gr, best_null_binary=mx_bin)

# ---------------------------------------------------------------- known-event catalogue (as run_search.py)
def hms(s):
    h, m, x = [float(v) for v in s.split(':')]
    return h * 3600 + m * 60 + x


con = R.db_connect()
cat = []
pk = R.royer_picks()
for _, r in pk.iterrows():
    st = 'H01W' if str(r.station).startswith('H01W') else r.station
    cat.append(dict(station=st, t_s=r.arrival_s, sd_s=S.T_SD, source=f'Royer 2016 pick, event {r["index"]} {r.label or ""} ({r.event_class})'))
lab = R.royer_labelled()
for _, r in lab[lab.receiver.isin(S.STATIONS)].iterrows():
    sd = float(np.hypot(S.T_SD, r.err_time_s if np.isfinite(r.err_time_s) and r.err_time_s < 99 else 30.0))
    cat.append(dict(station=r.receiver, t_s=r.pred_s, sd_s=sd, source=f'Royer 2016 event {r.royer_event} {r.label or ""} ({r.source_class}) predicted arrival'))
ke = pd.read_sql('select event_id, source_class, place, size, pred_T_H01W_utc, pred_T_H08S_utc, path_H01W, path_H08S from known_event', con)
for _, r in ke.iterrows():
    for st, col, pcn in (('H01W', 'pred_T_H01W_utc', 'path_H01W'), ('H08S', 'pred_T_H08S_utc', 'path_H08S')):
        if r[col]:
            note = ' (IDC observed)' if '(observed)' in str(r[col]) else ' (IDC rule)'
            cat.append(dict(station=st, t_s=float(R.to_s([str(r[col]).split(' ')[0]])[0]), sd_s=46.0,
                            source=f'catalogued {r.source_class} {r.event_id} {r.place} {r["size"]} ({r[pcn]}){note}'))
for t in pd.read_sql('select t from dg_results_data_h08s_template_h08s_template_shots', con).t:
    cat.append(dict(station='H08S', t_s=float(t), sd_s=1.0, source='Diego Garcia South airgun shot (label only)'))
for _, r in pd.read_sql('select event_id, time_utc from dg_data_kadri_fig9_digitised_kadri_table1_transients', con).iterrows():
    cat.append(dict(station='H01W', t_s=hms(r.time_utc), sd_s=5.0, source=f'Kadri 2024 Table 1 transient {r.event_id} (candidate, not an explanation)'))
for tname, st in (('dg_cmst_2014_cmst2014_fig5_ha01_detections_digitised', 'H01W'), ('dg_cmst_2014_cmst2014_fig7_ha08s_detections_digitised', 'H08S')):
    for _, r in pd.read_sql(f'select t_utc_s, bearing_deg from {tname}', con).iterrows():
        cat.append(dict(station=st, t_s=float(r.t_utc_s), sd_s=5.0, source=f'CMST 2014 detection, bearing {r.bearing_deg:.1f} deg'))
cat.append(dict(station='H01W', t_s=hms('01:34:50'), sd_s=5.0, source='CMST 2014 Cape Leeuwin event 01:34:50 (candidate, not an explanation)'))
CAT = pd.DataFrame(cat)
CAT = CAT[np.isfinite(CAT.t_s)].reset_index(drop=True)
CAT.to_csv(out / 'known_event_catalogue_used.csv', index=False)


def matches(st, ws):
    c = CAT[CAT.station == st]
    if c.empty:
        return []
    d = np.maximum(0, np.maximum(ws - c.t_s.to_numpy(), c.t_s.to_numpy() - (ws + W)))
    m = d <= 3 * c.sd_s.to_numpy()
    return [dict(source=s_.replace(' nan ', ' '), t_s=float(t), dt_s=float(x), match_likelihood=float(np.exp(-0.5 * (x / sd) ** 2)))
            for s_, t, x, sd in zip(c.source[m], c.t_s[m], d[m], c.sd_s[m])]


def group_matches(ms):
    if not ms:
        return ''
    d = pd.DataFrame(ms)
    g = d.groupby('source').agg(n_m=('dt_s', 'size'), dt_min=('dt_s', 'min'), L_max=('match_likelihood', 'max')).sort_values('L_max', ascending=False)
    return '; '.join(f"{s_}{' x' + str(int(r.n_m)) if r.n_m > 1 else ''} (min dt {r.dt_min:.0f} s, L {r.L_max:.2f})" for s_, r in g.iterrows())


chance = {}
for st in S.LEVEL_ST:
    g = grids[st]
    pos = np.arange(g.T0, g.T1 - W, 30.0)
    okp = np.isfinite(g.lookup(pos)[0])
    chance[st] = float(np.mean([len(matches(st, p)) > 0 for p in pos[okp]])) if okp.any() else None


def fmt_t(s):
    s = float(s)
    return f'{int(s // 3600):02d}:{int(s % 3600 // 60):02d}:{s % 60:04.1f}'


# ---------------------------------------------------------------- tables
iE = net['LG'].argmax(-1)
rows = []
for ai in range(nA):
    for ii in range(nI):
        for c, fc in enumerate(S.CORNERS):
            rows.append(dict(arc_lat=lat[ai], impact_utc=fmt_t(S.IMPACT_S[ii]), corner_hz=fc,
                             n_stations_observed=int(net['obs'][ai, ii].sum()), n_detections_1day=int(net['D'][ai, ii].sum()),
                             n_detections_1hour=int(neth['D'][ai, ii].sum()),
                             log10E_excl90=UL['log10E_excl90'][ai, ii, c], log10E_excl90_1hour=ULh['log10E_excl90'][ai, ii, c],
                             log10E_cred90=UL['log10E_cred90'][ai, ii, c], log10E_cred90_graded=UL['log10E_cred90_graded'][ai, ii, c],
                             S_binary=float(net['S_bin'][ai, ii, c]), S_binary_1hour=float(neth['S_bin'][ai, ii, c]),
                             S_graded=float(net['S_gr'][ai, ii, c]),
                             log10E_at_S_graded=S.LOGE[iE[ai, ii, c]] if net['S_gr'][ai, ii, c] > 0 else np.nan,
                             global_p_graded=float(glob_p_cell[ai, ii, c]), local_p_graded=float(local_p_gr[ai, ii, c]), run=RUN_LABEL))
cells = pd.DataFrame(rows)
cells.to_csv(out / 'cells.csv', index=False)
cells[cells.S_graded > 0].sort_values('S_graded', ascending=False).to_csv(out / 'candidates_no_threshold.csv', index=False)


def cell_detail(ai, ii, c):
    e = iE[ai, ii, c]
    det = []
    for k, st in enumerate(S.STATIONS):
        if not (bin_mask[k] or st in graded_st):
            continue
        if not avail[ai, k]:
            det.append(dict(station=st, status='land path (missing)'))
            continue
        ws = WS[ai, ii, k]
        if not np.isfinite(Robs[ai, ii, k]):
            det.append(dict(station=st, status='no data in window (missing)', window_utc=fmt_t(ws)))
            continue
        mu = 10 * S.LOGE[e] + G[ai, k, c]
        f = int(Fobs[ai, ii, k])
        rec = dict(station=st, status='observed', data_form=('Royer spectrogram' if (st == 'H01W' and f == 1) else S.CURVE_ENTRY.get((st, f), 'Royer picks')),
                   path_class=pclass[ai, k], window_utc=fmt_t(ws), window_end_utc=fmt_t(ws + W), T1_db=float(10 * np.log10(Robs[ai, ii, k])),
                   snr_pred_db_at_best_E=float(mu), detected_1day=bool(net['D'][ai, ii, k]), detected_1hour=bool(neth['D'][ai, ii, k]),
                   known_event_matches=matches(st, ws), chance_match_rate=chance.get(st))
        if (k, f) in graded:
            sdv = float(np.round(sdm[ai, k], 6))
            rec['graded_log_lr'] = float(graded[(k, f)][sdv].loglam(np.array([Robs[ai, ii, k]]), np.array([[mu]]))[0, 0])
            x = f0[(st, f)]
            rec['station_p'] = float((1 + (x >= Robs[ai, ii, k]).sum()) / (1 + x.size))
        det.append(rec)
    return det


best = []
for flat in np.argsort(-net['S_gr'].ravel()):
    ai, ii, c = np.unravel_index(flat, net['S_gr'].shape)
    if net['S_gr'][ai, ii, c] <= 0 or len(best) >= 20:
        break
    best.append(dict(rank=len(best) + 1, arc_lat=float(lat[ai]), impact_utc=fmt_t(S.IMPACT_S[ii]), corner_hz=S.CORNERS[c],
                     S_graded=float(net['S_gr'][ai, ii, c]), log10E_at_max=float(S.LOGE[iE[ai, ii, c]]),
                     global_p_graded=float(glob_p_cell[ai, ii, c]), local_p_graded=float(local_p_gr[ai, ii, c]),
                     stations=cell_detail(ai, ii, c), run=RUN_LABEL))
(out / 'best_cells.json').write_text(json.dumps(best, indent=1, default=float))
# best binary cells (1/day and 1/hour)
bb = {}
for nm, nt in (('1/day', net), ('1/hour', neth)):
    ai, ii, c = np.unravel_index(nt['S_bin'].argmax(), nt['S_bin'].shape)
    bb[nm] = dict(S=float(nt['S_bin'][ai, ii, c]), arc_lat=float(lat[ai]), impact_utc=fmt_t(S.IMPACT_S[ii]), corner_hz=S.CORNERS[c],
                  detections=[S.STATIONS[k] for k in range(nK) if nt['D'][ai, ii, k]])

sw = []
for k, st in enumerate(S.LEVEL_ST):
    if not avail[:, k].any():
        continue
    lo, hi = np.nanmin(WS[avail[:, k], :, k]), np.nanmax(WS[avail[:, k], :, k])
    pos = np.arange(np.floor(lo), hi + 0.1, 2.5)
    rv, fv = grids[st].lookup(pos)
    if st == 'H01W' and a.stations == 'no_royer_h01w':
        rv = np.where(fv == 1, np.nan, rv)
    t1 = 10 * np.log10(np.where(np.isfinite(rv), rv, np.nan))
    idx = np.flatnonzero(np.isfinite(rv) & (rv >= 3.0))
    keep = [i for i in idx if t1[i] >= np.nanmax(t1[max(0, i - int(W / 5)):i + int(W / 5) + 1])]
    for i in keep:
        f = int(fv[i])
        x = f0.get((st, f), np.array([]))
        thr_d, thr_h = CT['1/day'][0]['thr'][f, k], CT['1/hour'][0]['thr'][f, k]
        sw.append(dict(station=st, data_form=('Royer spectrogram' if (st == 'H01W' and f == 1) else S.CURVE_ENTRY[(st, f)]),
                       window_start_utc=fmt_t(pos[i]), window_end_utc=fmt_t(pos[i] + W), T1_db=float(t1[i]),
                       station_p=float((1 + (x >= rv[i]).sum()) / (1 + x.size)) if x.size else np.nan, n_noise_windows=int(x.size),
                       above_1day=bool(t1[i] >= thr_d), above_1hour=bool(t1[i] >= thr_h), threshold_1day_db=thr_d, threshold_1hour_db=thr_h,
                       matches=group_matches(matches(st, pos[i])), run=RUN_LABEL))
pd.DataFrame(sw).to_csv(out / 'station_windows.csv', index=False)

summ = dict(run=RUN_LABEL, case=a.case, stations_mode=a.stations, prereg='ns-prereg-2026-11-03a + A1 (v83dd444b) + A2 (v5eb84cde)',
            level_correction=levc['version'], level_by_class=levc['classes'], pd_curves=pdc['version'], window_s=W,
            curves_1day={st: {q: float(CT['1/day'][0][q][0, k]) for q in ('thr', 'snr50', 'sig', 'floor', 'p0')} for k, st in enumerate(S.STATIONS)},
            curve_notes=CT['1/day'][1], n_cells=int(net['S_gr'].size),
            observed_fraction_by_station={st: float((np.isfinite(Robs[:, :, k]) & avail[:, None, k]).mean()) for k, st in enumerate(S.STATIONS)},
            detections_1day_by_station={st: int(net['D'][:, :, k].sum()) for k, st in enumerate(S.STATIONS)},
            detections_1hour_by_station={st: int(neth['D'][:, :, k].sum()) for k, st in enumerate(S.STATIONS)},
            best_graded=dict(S=best_gr, empirical_p=p_gr, null_p50=float(np.median(mx_gr)), null_p95=float(np.percentile(mx_gr, 95)),
                             cell={k: v for k, v in best[0].items() if k != 'stations'} if best else None),
            best_binary_1day=dict(**bb['1/day'], empirical_p=p_bin, null_fraction_above_zero=float((mx_bin > 1e-9).mean())),
            best_binary_1hour=dict(**bb['1/hour'], empirical_p=p_binh, null_fraction_above_zero=float((SbAh > 1e-9).mean())),
            null_A_n=a.nnull, null_B=nullB, chance_match_rate=chance,
            excl90_finite_fraction={str(fc): float(np.isfinite(UL['log10E_excl90'][:, :, c]).mean()) for c, fc in enumerate(S.CORNERS)},
            excl90_min_log10E={str(fc): (float(np.nanmin(UL['log10E_excl90'][:, :, c])) if np.isfinite(UL['log10E_excl90'][:, :, c]).any() else None) for c, fc in enumerate(S.CORNERS)},
            excl90_1hour_finite_fraction={str(fc): float(np.isfinite(ULh['log10E_excl90'][:, :, c]).mean()) for c, fc in enumerate(S.CORNERS)},
            excl90_1hour_min_log10E={str(fc): (float(np.nanmin(ULh['log10E_excl90'][:, :, c])) if np.isfinite(ULh['log10E_excl90'][:, :, c]).any() else None) for c, fc in enumerate(S.CORNERS)},
            cred90_graded_median_log10E={str(fc): float(np.median(UL['log10E_cred90_graded'][:, :, c])) for c, fc in enumerate(S.CORNERS)},
            cred90_graded_min_log10E={str(fc): float(np.min(UL['log10E_cred90_graded'][:, :, c])) for c, fc in enumerate(S.CORNERS)},
            P50_log10E_corner5={st: [float(S.LOGE[np.argmax(Pdet[0, ai, k, 0] >= 0.5)]) if Pdet[0, ai, k, 0].max() >= 0.5 else None for ai in range(nA)]
                                for k, st in enumerate(S.STATIONS) if bin_mask[k]},
            arc_lat=lat.tolist(), runtime_s=time.time() - T0)
(out / 'summary.json').write_text(json.dumps(summ, indent=1, default=float))
np.savez_compressed(out / 'grids_for_charts.npz', excl=UL['log10E_excl90'], exclh=ULh['log10E_excl90'], cred=UL['log10E_cred90'],
                    credg=UL['log10E_cred90_graded'], S_gr=net['S_gr'], S_bin=net['S_bin'], lat=lat, impact_s=S.IMPACT_S,
                    corners=np.array(S.CORNERS), null_best_gr=mx_gr, null_best_bin=mx_bin, best_gr=best_gr, best_bin=best_bin, p_gr=p_gr, p_bin=p_bin)
log('done', RUN_LABEL)
