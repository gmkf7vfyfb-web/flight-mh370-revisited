"""Charts for the real run (A2). Run in the python kernel that has apply_figure_style.
make_charts2(run_dir) -> [map png, null png]"""
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np


def _t(s):
    return f'{int(s // 3600):02d}:{int(s % 3600 // 60):02d}'


def _common(summ):
    lb = summ['level_by_class']
    sds = sorted({round(v['sd_db'], 2) for v in lb.values()})
    bs = sorted({round(v['bias_db'], 2) for v in lb.values()})
    return (f"Run: {summ['run']}. Model error: bias {', '.join(f'{b:+.1f}' for b in bs)} dB, sd {', '.join(f'{s:.1f}' for s in sds)} dB "
            f"({summ['level_correction']}); path type per path (project rule). Detection curves {summ['pd_curves']}: threshold at one false alarm per day "
            f"(Cape Leeuwin trace 15.7 dB, Cape Leeuwin spectrogram part uses the raw-hydrophone curve 17.0 dB, Diego Garcia South trace 20.3 dB, "
            f"IMOS 14.2-30.2 dB; IMOS 3275 set to 20.05 dB, its own lower bound). Diego Garcia South noise: between-shot level 100.43 dB, conversion not measured. "
            f"Window 30 s (10 s before to 20 s after the predicted onset). Arrival: path length / 1.480 km/s - 3.1 s (sd 8.6 s). "
            f"Source on the 7th-arc line only (cross-arc offsets not sampled), 10 m depth, flat spectrum to the corner then f^-3.1. "
            f"Sound model RAM, frozen chain tl-chain-2026-10-27. Stations: Cape Leeuwin (Kadri trace 00:27-00:57, Royer spectrogram 00:01-02:03), "
            f"Diego Garcia South (Kadri trace 01:00-01:20), IMOS loggers 3315, 3376, 3250, 3274, 3275 (307 s per 15 min, 10-40 Hz). "
            f"OHASISBIO not in the primary likelihood (picks curve not identified). Missing data are no evidence, not non-detections. "
            f"Pre-registration {summ['prereg']}.")


def make_charts2(run_dir, tag=''):
    out = Path(run_dir)
    z = np.load(out / 'grids_for_charts.npz')
    summ = json.loads((out / 'summary.json').read_text())
    apply_figure_style(sizes=(8, 7, 6))  # noqa: F821
    lat, ts, corners = z['lat'], z['impact_s'], z['corners']
    common = _common(summ)

    fig, axs = plt.subplots(3, 3, figsize=(7.2, 8.4), sharex=True, sharey=True, gridspec_kw=dict(wspace=0.06, hspace=0.2))
    cmap = mpl.colormaps['viridis'].copy()
    cmap.set_bad('#d9d9d9')
    norm = mpl.colors.Normalize(5, 10)
    dt = ts[1] - ts[0]
    ext = [ts[0] - dt / 2, ts[-1] + dt / 2, lat[0] - 0.25, lat[-1] + 0.25]
    rows = [('excl', '90 % exclusion,\none false alarm per day'), ('exclh', '90 % exclusion,\none false alarm per hour'),
            ('credg', '90 % credible limit,\ngraded statistic')]
    for r, (key, rlab) in enumerate(rows):
        for c, fc in enumerate(corners):
            ax = axs[r, c]
            im = ax.imshow(np.ma.masked_invalid(z[key][:, :, c]), origin='lower', aspect='auto', extent=ext, cmap=cmap, norm=norm,
                           interpolation='nearest')
            if r == 0:
                ax.set_title(f'Corner frequency {fc:g} Hz', loc='left')
            xt = np.arange(20 * 60, 45 * 60 + 1, 300)
            ax.set_xticks(xt)
            ax.set_xticklabels([_t(x) if x % 600 == 0 else '' for x in xt])
            if c == 0:
                ax.set_ylabel(f'{rlab}\n7th-arc latitude')
                ax.set_yticks([-40, -35, -30, -25, -20])
                ax.set_yticklabels(['40 S', '35 S', '30 S', '25 S', '20 S'])
            if r == 2:
                ax.set_xlabel('Impact time (UTC, 8 Mar 2014)')
    fig.subplots_adjust(bottom=0.25, top=0.92, left=0.13, right=0.86)
    cax = fig.add_axes([0.885, 0.35, 0.016, 0.5])
    cb = fig.colorbar(im, cax=cax)
    cb.set_label('Upper limit on acoustic energy (J)')
    cb.set_ticks([5, 6, 7, 8, 9, 10])
    cb.set_ticklabels(['10$^5$', '10$^6$', '10$^7$', '10$^8$', '10$^9$', '10$^{10}$'])
    ex, exh = summ['excl90_finite_fraction'], summ['excl90_1hour_finite_fraction']
    fr = max(float(v) for v in ex.values())
    ttl = ('With one false alarm per day, the data held set almost no energy limit below 10$^{10}$ J' if fr < 0.05 else
           f"With one false alarm per day, the data held set a limit below 10$^{{10}}$ J at up to {100 * fr:.0f} % of cells")
    fig.suptitle(f'{tag}{ttl}', x=0.06, ha='left', fontsize=8)
    foot = ("Grey: no limit below 10^10 J. Rows 1-2: lowest energy at which the chance of all observed non-detections, relative to no signal, is 10 % or less "
            f"(cells with a limit, 5 / 1 / 0.2 Hz: per day {100 * ex['5.0']:.0f} / {100 * ex['1.0']:.0f} / {100 * ex['0.2']:.0f} %, "
            f"per hour {100 * exh['5.0']:.0f} / {100 * exh['1.0']:.0f} / {100 * exh['0.2']:.0f} %). Row 3: 90 % point of the posterior from the graded statistic "
            "with a log-uniform prior on 10^1-10^10 J (depends on the prior). The detector track found that a blind one-per-day scan misses the real F-35A "
            "arrival at Wake Island, which a one-per-hour scan detects. 43 arc points (41-20 S, 0.5 deg) x 52 impact times (00:19:30-00:45:00, 30 s). " + common)
    fig.text(0.06, 0.005, foot, wrap=True, ha='left', va='bottom', fontsize=5.5)
    p1 = out / 'upper-limit-map.png'
    fig.savefig(p1, dpi=300)
    plt.close(fig)

    nB = np.load(out / 'null_B.npz')
    nbB = summ['null_B']
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.8), gridspec_kw=dict(wspace=0.3))
    ax = axs[0]
    ax.hist(z['null_best_gr'], bins=30, color='#9ecae1', edgecolor='white')
    ax.axvline(float(z['best_gr']), color='#08306b', lw=1.5)
    ax.text(float(z['best_gr']), ax.get_ylim()[1] * 0.95, f"  observed best {float(z['best_gr']):.2f}\n  empirical p = {float(z['p_gr']):.2f}",
            va='top', fontsize=7, color='#08306b')
    ax.set_xlabel('Best network score in the search (log likelihood ratio)')
    ax.set_ylabel('Number of time-slide trials')
    ax.set_title('All stations used: time slides of 5 min or more', loc='left')
    ax = axs[1]
    sg = nB['SgB'][nB['nobsB'] >= 0.5 * nbB['observed_imos_window_count']]
    assert sg.size == nbB['n_shifts']
    ax.hist(sg, bins=30, color='#c7e9c0', edgecolor='white')
    ax.axvline(nbB['observed_imos_S_gr'], color='#00441b', lw=1.5)
    ax.text(nbB['observed_imos_S_gr'], ax.get_ylim()[1] * 0.95, f"  observed best {nbB['observed_imos_S_gr']:.2f}\n  empirical p = {nbB['p_graded']:.2f}",
            va='top', fontsize=7, color='#00441b')
    ax.set_xlabel('Best score, IMOS loggers only (log likelihood ratio)')
    ax.set_ylabel('Number of shifts')
    ax.set_title('IMOS loggers: common shifts of 3 h or more', loc='left')
    pg = float(z['p_gr'])
    ttl = ('The best score on 8 March 2014 is typical of scores with no coherent signal' if pg > 0.1 else
           f'The best score on 8 March 2014 is higher than most time-slide scores (p = {pg:.3f})')
    fig.suptitle(f'{tag}{ttl}', x=0.06, ha='left', fontsize=8)
    cell = summ['best_graded'].get('cell') or {}
    b1, bh = summ['best_binary_1day'], summ['best_binary_1hour']
    foot = (f"Left: {summ['null_A_n']} time slides; each station group (Perth Canyon pair and Portland pair kept together) gets its own offset "
            "(digitised data: 5 min or more, cyclic in its own span; IMOS: multiples of 15 min, 1 h or more). Best observed cell: "
            f"{cell.get('arc_lat', '')} deg, impact {cell.get('impact_utc', '')}, corner {cell.get('corner_hz', '')} Hz. Score = highest log likelihood ratio "
            "over energy, graded statistic (window energy over median reference energy, against each station's own noise distribution). Threshold statistic: "
            f"best {b1['S']:.2f} (p = {b1['empirical_p']:.2f}) at one false alarm per day, {bh['S']:.2f} (p = {bh['empirical_p']:.2f}) per hour. Right: all IMOS "
            "loggers shifted together by multiples of 15 min, 3 h or more, into 8 Mar and the 14-day background (3376, 3274, 3250); "
            f"{nbB['n_shifts']} shifts with at least half of the observed window count. " + common)
    fig.text(0.06, 0.005, foot, wrap=True, ha='left', va='bottom', fontsize=5.5)
    fig.subplots_adjust(bottom=0.45, top=0.86, left=0.09, right=0.98)
    p2 = out / 'null-distribution.png'
    fig.savefig(p2, dpi=300)
    plt.close(fig)
    return [p1, p2]
