"""Network detection search, real run: prereg ns-prereg-2026-11-03a + amendments A1 (v83dd444b) and A2 (v5eb84cde).
Differences from ns_search.py (dry run) are those listed in A2: 30-s window, T1 = 10 log10(E_W / median E_W) with
median reference windows, detection curves per data form with floor and noise sd, OHASISBIO picks form (sensitivity).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numba
import numpy as np
import pandas as pd
from scipy import stats

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import ns_readers as R  # noqa: E402
import ns_search as NS1  # noqa: E402  (band_fraction, Graded, select_level_case, loaders)

LEVEL_ST = ['H01W', 'H08S', 'IMOS3315', 'IMOS3376', 'IMOS3250', 'IMOS3274', 'IMOS3275']
PICK_ST = ['SSEIR', 'SWAMS3', 'SWAMS1', 'SWAMS2', 'MAD', 'NCRO', 'WKER']
STATIONS = LEVEL_ST + PICK_ST
GROUPS = {'H01W': ['H01W'], 'H08S': ['H08S'], 'PerthCanyon': ['IMOS3315', 'IMOS3376'], 'ScottReef': ['IMOS3250'],
          'Portland': ['IMOS3274', 'IMOS3275'], 'SWAMS': ['SWAMS1', 'SWAMS2', 'SWAMS3'], 'SSEIR': ['SSEIR'], 'MAD': ['MAD'],
          'NCRO': ['NCRO'], 'WKER': ['WKER']}
IMOS = [s for s in STATIONS if s.startswith('IMOS')]
BAND = {k: ((10.0, 40.0) if k.startswith('IMOS') else (5.0, 40.0)) for k in STATIONS}
V_KM_S, T_BIAS, T_SD = NS1.V_KM_S, NS1.T_BIAS, NS1.T_SD
IMPACT_S, LOGE, CORNERS = NS1.IMPACT_S, NS1.LOGE, NS1.CORNERS
PICK_SPAN = (0.0, 11400.0)          # Royer analysed span taken as 00:00-03:10 UTC (A2 item 11)
PICK_R = 1.0e6                      # R value that encodes "a pick is in the window"
IMOS_RECORDED_FRACTION = 0.339
CURVE_ENTRY = {('H01W', 0): 'H01W_envelope', ('H01W', 1): 'H01W', ('H08S', 0): 'H08S_envelope', ('H08S', 1): 'H08S_envelope'}
for s in IMOS:
    CURVE_ENTRY[(s, 0)] = CURVE_ENTRY[(s, 1)] = s
POSTHOC_PICKS = dict(snr50_db=27.9, sigma_db=20.0, pd_floor=0.0)


# ------------------------------------------------------------------ geometry and predicted level
def load_paths():
    tl = pd.read_csv(NS1.TL_CSV)
    tl = tl[(tl.src_depth_m == NS1.SRC_DEPTH) & tl.station.isin(STATIONS)]
    pts = tl[['src_lat', 'src_lon']].drop_duplicates().sort_values('src_lat').reset_index(drop=True)
    return tl, pts


def path_classes(pts):
    pc = pd.read_csv(NS1.PATH_CLASS_CSV)
    pc = pc[pc.set == 'dense'].set_index('name').path_class
    return {(lat, k): pc.get(f'arc{abs(lat):.1f}S-{k}', 'blocked') for k in STATIONS for lat in pts.src_lat}


def noise_level(pdc, st):
    e = pdc['stations'][CURVE_ENTRY.get((st, 0), f'OHASISBIO_{st}')]
    return float(e['noise_level_db']), float(e.get('noise_sd_db') or 0.0)


def gain_tables(tl, pts, levc, pdc, W):
    cls = path_classes(pts)
    nA, nK, nC = len(pts), len(STATIONS), len(CORNERS)
    G = np.full((nA, nK, nC), np.nan)
    sdm = np.full((nA, nK), np.nan)
    tt = np.full((nA, nK), np.nan)
    pclass = np.empty((nA, nK), dtype=object)
    for a, lat in enumerate(pts.src_lat):
        for k, st in enumerate(STATIONS):
            pclass[a, k] = cls[(lat, st)]
            d = tl[(tl.src_lat == lat) & (tl.station == st)]
            if d.empty:
                continue
            lc = levc['classes'].get(cls[(lat, st)], levc['global'])
            N = noise_level(pdc, st)[0] + 10 * np.log10(W)
            flo, fhi = BAND[st]
            for c, fc in enumerate(CORNERS):
                tot = 0.0
                for _, r in d.iterrows():
                    fr = NS1.band_fraction(r.fc_hz, flo, fhi, fc)
                    if fr > 0:
                        corr = lc['bias_db'] + lc['slope_db_per_oct'] * np.log2(r.fc_hz / 10.0)
                        tot += 10 ** ((170.8 + 10 * np.log10(fr) - r.tl_db + corr) / 10)
                G[a, k, c] = 10 * np.log10(tot) - N
            sdm[a, k] = lc['sd_db']
            tt[a, k] = d.range_km.iloc[0] / V_KM_S + T_BIAS
    return G, sdm, tt, pclass


# ------------------------------------------------------------------ T1 statistic on a grid of window starts
@numba.njit(cache=True)
def _t1_grid(tc, dt, e, blk, ws, W, half, gap, ref_every, same_block, min_ref):
    n = ws.size
    cdt = np.zeros(tc.size + 1)
    ce = np.zeros(tc.size + 1)
    for i in range(tc.size):
        cdt[i + 1] = cdt[i] + dt[i]
        ce[i + 1] = ce[i] + e[i]
    E = np.full(n, np.nan)
    B = np.full(n, -1, dtype=np.int64)
    for j in range(n):
        i0 = np.searchsorted(tc, ws[j])
        i1 = np.searchsorted(tc, ws[j] + W)
        if i1 <= i0:
            continue
        if cdt[i1] - cdt[i0] < 0.9 * W:
            continue
        if blk[i0] != blk[i1 - 1]:
            continue
        E[j] = ce[i1] - ce[i0]
        B[j] = blk[i0]
    Rv = np.full(n, np.nan)
    step = ws[1] - ws[0]
    hw = int(half / step)
    gw = int((W + gap) / step)
    buf = np.empty(2 * hw // ref_every + 4)
    for j in range(n):
        if np.isnan(E[j]):
            continue
        m = 0
        lo = max(0, j - hw)
        hi = min(n - 1, j + hw)
        # reference starts on a coarse lattice (every ref_every grid steps)
        r = lo - (lo % ref_every)
        while r <= hi:
            if r >= lo and abs(r - j) >= gw and not np.isnan(E[r]):
                if (not same_block) or B[r] == B[j]:
                    buf[m] = E[r]
                    m += 1
            r += ref_every
        if m >= min_ref:
            med = np.median(buf[:m])
            if med > 0:
                Rv[j] = E[j] / med
    return Rv, B


class GridT1:
    def __init__(self, s: R.BandSeries, W: float, imos: bool, form_split=None, step=0.5):
        o = np.argsort(s.t0 + s.dt / 2)
        tc = (s.t0 + s.dt / 2)[o]
        self.T0, self.T1 = float(s.t0.min()), float((s.t0 + s.dt).max())
        self.span, self.W, self.step = self.T1 - self.T0, W, step
        self.ws0 = np.floor((self.T0 - W) / step) * step
        ws = np.arange(self.ws0, self.T1 + step, step)
        half = 1207.0 if imos else 300.0
        self.Rv, B = _t1_grid(tc, s.dt[o], s.e[o], s.block[o].astype(np.int64), ws, W, half, 30.0, 10, not imos, 10)
        self.form = np.zeros(ws.size, dtype=np.int8) if form_split is None else (B >= form_split).astype(np.int8)
        self.kind = 'level'

    def _idx(self, x):
        idx = np.rint((np.asarray(x) - self.ws0) / self.step).astype(np.int64)
        ok = (idx >= 0) & (idx < self.Rv.size)
        return idx, ok

    def lookup(self, ws):
        idx, ok = self._idx(ws)
        R_ = np.full(idx.shape, np.nan)
        F = np.zeros(idx.shape, dtype=np.int8)
        R_[ok] = self.Rv[idx[ok]]
        F[ok] = self.form[idx[ok]]
        return R_, F

    def lookup_cyclic(self, ws, delta):
        x = self.T0 + np.mod(np.asarray(ws) + delta - self.T0, self.span)
        R_, F = self.lookup(x)
        R_[x + self.W > self.T1] = np.nan
        return R_, F


class PicksStation:
    """Royer 2016 picks at one OHASISBIO station (A2 item 11)."""

    def __init__(self, times, W):
        self.t = np.sort(np.asarray(times, float))
        self.T0, self.T1 = PICK_SPAN
        self.span, self.W = self.T1 - self.T0, W
        self.kind = 'picks'
        self.p0 = max(len(self.t) * W / self.span, 1e-4)

    def lookup(self, ws):
        ws = np.asarray(ws, float)
        i0 = np.searchsorted(self.t, ws)
        i1 = np.searchsorted(self.t, ws + self.W)
        R_ = np.where(i1 > i0, PICK_R, 1.0)
        R_ = np.where((ws >= self.T0) & (ws + self.W <= self.T1), R_, np.nan)
        return R_, np.zeros(ws.shape, dtype=np.int8)

    def lookup_cyclic(self, ws, delta):
        x = self.T0 + np.mod(np.asarray(ws) + delta - self.T0, self.span)
        R_, F = self.lookup(x)
        R_[x + self.W > self.T1] = np.nan
        return R_, F


def build_grids(W, stations_mode):
    ev = pd.read_pickle(HERE / 'imos_eventday_cache.pkl')
    grids = {'H01W': GridT1(R.h01w_composite(), W, imos=False, form_split=10), 'H08S': GridT1(R.kadri_series('H08S'), W, imos=False)}
    for st in IMOS:
        grids[st] = GridT1(R.imos_series_from_cache(st, ev), W, imos=True)
    pk = R.royer_picks()
    pk['st'] = np.where(pk.station.str.startswith('H01W'), 'H01W', pk.station)
    for st in PICK_ST:
        grids[st] = PicksStation(pk[pk.st == st].arrival_s.to_numpy(), W)
    return grids


def build_long_imos(W):
    lg = NS1.load_imos_long()
    return {k: GridT1(v, W, imos=True) for k, v in lg.items()}


# ------------------------------------------------------------------ detection curves
def curve_table(pdc, fa, grids, W):
    """Per station k and form f: thr, snr50, sigma (incl. noise sd), floor, p0. Arrays [f, k]."""
    nK = len(STATIONS)
    T = {q: np.full((2, nK), np.nan) for q in ('thr', 'snr50', 'sig', 'floor', 'p0')}
    notes = {}
    for k, st in enumerate(STATIONS):
        for f in (0, 1):
            if st in PICK_ST:
                nsd = noise_level(pdc, st)[1]
                T['thr'][f, k] = 10 * np.log10(PICK_R) / 2
                T['snr50'][f, k] = POSTHOC_PICKS['snr50_db']
                T['sig'][f, k] = np.hypot(POSTHOC_PICKS['sigma_db'], nsd)
                T['floor'][f, k] = 0.0
                T['p0'][f, k] = grids[st].p0
                notes[st] = 'post hoc picks curve (A2 item 3/11)'
                continue
            ent = pdc['stations'][CURVE_ENTRY[(st, f)]]
            c = dict(ent['fa'][fa])
            if st == 'IMOS3275' and fa == '1/day':           # A2 item 4 / 9
                shift = 20.05 - c['threshold_snr_db']
                c['threshold_snr_db'] = 20.05
                c['snr50_db'] = c['snr50_db'] + shift
                notes[st] = f'threshold 20.05 dB (own lower bound), snr50 moved by {shift:+.3f} dB'
            pfa = W / (86400.0 if fa == '1/day' else 3600.0)
            if st.startswith('IMOS'):
                pfa /= IMOS_RECORDED_FRACTION
            T['thr'][f, k] = c['threshold_snr_db']
            T['snr50'][f, k] = c['snr50_db']
            T['sig'][f, k] = np.hypot(c['sigma_db'], float(ent.get('noise_sd_db') or 0.0))
            T['floor'][f, k] = float(c.get('pd_floor') or 0.0)
            T['p0'][f, k] = max(T['floor'][f, k], pfa)
    return T, notes


def binary_terms(G, sdm, T):
    """l1, l0, Pdet: [f, a, k, c, e]."""
    pred = 10 * LOGE[None, None, None, None, :] + G[None, ..., None]
    stot = np.sqrt(T['sig'][:, None, :] ** 2 + sdm[None] ** 2)[..., None, None]
    PD = stats.norm.cdf((pred - T['snr50'][:, None, :, None, None]) / stot)
    PD = np.nan_to_num(PD)
    fl = T['floor'][:, None, :, None, None]
    p0 = T['p0'][:, None, :, None, None]
    Pdet = np.maximum(fl + (1 - fl) * PD, p0)
    l1 = np.log(Pdet / p0)
    l0 = np.log(np.clip(1 - Pdet, 1e-300, None) / (1 - p0))
    return l1, l0, Pdet


def graded_tables(grids, sdm, pdc, W, graded_stations):
    tabs, f0 = {}, {}
    for k, st in enumerate(STATIONS):
        if st not in graded_stations:
            continue
        g = grids[st]
        R_, F = g.lookup(np.arange(g.T0, g.T1 - W, 30.0))
        nsd = noise_level(pdc, st)[1]
        for f in (0, 1):
            x = R_[np.isfinite(R_) & (F == f)]
            if x.size < 10:
                continue
            f0[(st, f)] = x
            sds = np.unique(np.round(sdm[np.isfinite(sdm[:, k]), k], 6))
            tabs[(k, f)] = {float(s): NS1.Graded(np.log(x), float(np.hypot(s, nsd))) for s in sds}
    return tabs, f0


# ------------------------------------------------------------------ network
def network(Robs, Fobs, avail, G, l1, l0, T, sdm, bin_mask, graded=None):
    obs = np.isfinite(Robs) & avail[:, None, :] & bin_mask[None, None, :]
    thr = np.where(Fobs == 0, T['thr'][0][None, None, :], T['thr'][1][None, None, :])
    D = obs & (10 * np.log10(np.where(obs, Robs, 1.0)) >= thr)
    LL = 0.0
    for f in (0, 1):
        m = (Fobs == f)
        LL = LL + np.einsum('aik,akce->aice', (obs & D & m).astype(float), np.nan_to_num(l1[f])) \
                + np.einsum('aik,akce->aice', (obs & ~D & m).astype(float), np.nan_to_num(l0[f]))
    out = dict(obs=obs, D=D, LL=LL, S_bin=LL.max(-1))
    if graded is not None:
        LG = np.zeros_like(LL)
        gobs = np.isfinite(Robs) & avail[:, None, :]
        for (k, f), tabs in graded.items():
            mk = gobs[:, :, k] & (Fobs[:, :, k] == f)
            if not mk.any():
                continue
            mu = 10 * LOGE[None, None, :] + np.nan_to_num(G[:, k, :], nan=-999)[:, :, None]
            for sdv, gt in tabs.items():
                sel = np.isclose(np.nan_to_num(sdm[:, k], nan=-1), sdv)
                if not sel.any():
                    continue
                Rk = np.where(mk[sel], Robs[sel, :, k], np.nan)
                for c in range(len(CORNERS)):
                    LG[sel, :, c, :] += gt.loglam(Rk, np.broadcast_to(mu[sel][:, None, c, :], Rk.shape + (LOGE.size,)))
        out['LG'] = LG
        out['S_gr'] = LG.max(-1)
        out['gobs'] = gobs
    return out


def upper_limits(net, Pdet, T, Fobs):
    nd = net['obs'] & ~net['D']
    ls = 0.0
    for f in (0, 1):
        ratio = np.log(np.clip(1 - Pdet[f], 1e-300, None)) - np.log(1 - T['p0'][f])[None, :, None, None]
        ls = ls + np.einsum('aik,akce->aice', (nd & (Fobs == f)).astype(float), ratio)
    hit = ls <= np.log(0.10)
    first = np.where(hit.any(-1), hit.argmax(-1), -1)
    excl = np.where(first >= 0, LOGE[np.clip(first, 0, None)], np.nan)

    def cred(L):
        w = np.exp(L - L.max(-1, keepdims=True))
        cdf = np.cumsum(w, -1) / w.sum(-1, keepdims=True)
        return LOGE[(cdf >= 0.90).argmax(-1)]
    res = dict(log10E_excl90=excl, log10E_cred90=cred(net['LL']))
    if 'LG' in net:
        res['log10E_cred90_graded'] = cred(net['LG'])
    return res


def lookup_all(grids, WS, avail, deltas=None, cyclic=True):
    nA, nI, nK = WS.shape
    Rn = np.full(WS.shape, np.nan)
    Fn = np.zeros(WS.shape, dtype=np.int8)
    for k, st in enumerate(STATIONS):
        if st not in grids:
            continue
        if deltas is None:
            r, f = grids[st].lookup(WS[:, :, k])
        elif cyclic:
            r, f = grids[st].lookup_cyclic(WS[:, :, k], deltas[k])
        else:
            r, f = grids[st].lookup(WS[:, :, k] + deltas[k])
        Rn[:, :, k], Fn[:, :, k] = r, f
    Rn[~np.broadcast_to(avail[:, None, :], Rn.shape)] = np.nan
    return Rn, Fn


def null_offsets(grids, n, seed):
    rng = np.random.default_rng(seed)
    offs = np.zeros((n, len(STATIONS)))
    for g, members in GROUPS.items():
        if members[0].startswith('IMOS'):
            kmax = int(min(grids[m].span for m in members) // 900) - 4
            d = rng.integers(4, kmax + 1, size=n) * 900.0
        else:
            mmax = int(min(grids[m].span for m in members) // 30) - 10
            d = rng.integers(10, mmax + 1, size=n) * 30.0
        for m in members:
            offs[:, STATIONS.index(m)] = d
    return offs
