"""Unit tests for ns_readers (run: python test_readers.py). Each test prints PASS/FAIL with its numbers.
No test opens a predicted arrival window of the 8 March 2014 search: IMOS level tests use only records with the
role 'pre-registered background' from the earlier noise study; Kadri/Royer level tests use whole-panel medians that
are already published in the data store."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
import ns_readers as R  # noqa: E402

RESULTS = []


def check(name, ok, **vals):
    RESULTS.append(dict(test=name, passed=bool(ok), **{k: (float(v) if isinstance(v, (np.floating, float, int)) else str(v)) for k, v in vals.items()}))
    print(('PASS ' if ok else 'FAIL ') + name, vals)


def t_synthetic_band_power():
    rng = np.random.default_rng(1)
    sig = 0.01
    x = rng.normal(0, sig, int(6000 * 120))
    flat = (np.array([0.0, 3000.0]), np.array([0.0, 0.0]))          # G = 0 dB, S_h = 0 dB -> output in V^2
    ts, out = R.band_power_from_volts(x, 0.0, flat, bands=((10, 40),))
    expect = sig ** 2 / 3000.0 * 30.0                                # one-sided PSD x 30 Hz
    got = np.mean(out[(10, 40)])
    check('F0 synthetic white noise: 10-40 Hz band power', abs(10 * np.log10(got / expect)) < 0.1, got_db=10 * np.log10(got), expect_db=10 * np.log10(expect))
    # a tone of amplitude a at 20 Hz in 60 s: energy a^2/2 * 60 recovered by the hop sum
    t = np.arange(int(6000 * 120)) / 6000
    a = 0.05
    y = a * np.sin(2 * np.pi * 20 * t) * ((t > 30) & (t < 90))
    ts, out = R.band_power_from_volts(y, 0.0, flat, bands=((10, 40),))
    e = out[(10, 40)].sum() * 0.5
    check('F0 synthetic 60 s tone: energy recovered', abs(10 * np.log10(e / (a ** 2 / 2 * 60))) < 0.2, got=e, expect=a ** 2 / 2 * 60)


def t_imos_headers_and_duty():
    for st in R.IMOS_CAL:
        seg = R.imos_segments(st)
        h = R.read_header(seg.path.iloc[0])
        fs = int(h[2].split('Sample Rate')[1].split('Duration')[0])
        lf = int(h[3].split('LF=')[1][:3])
        dur = seg.duration_s.median()
        spacing = np.median(np.diff(seg.t_start_s))
        conv_a = np.allclose(R.to_s(seg.t_start_logger) - seg.clock_err_s, seg.t_start_s, atol=0.01)
        check(f'{st} header and duty cycle', fs == 6000 and lf == 8 and abs(dur - 307) < 0.5 and abs(spacing - 900) < 1 and conv_a,
              fs=fs, hp_corner_hz=lf, record_s=dur, spacing_s=spacing, duty=dur / spacing, clock_convention_A=conv_a,
              n_records=len(seg), first=seg.t_start_utc.iloc[0], last=seg.t_end_utc.iloc[-1])


def t_imos_levels():
    with R.db_connect() as con:
        v = pd.read_sql("select site_id, band_label, value from v_noise_8mar2014 where site_id like 'IMOS%' and statistic='median' "
                        "and averaging like '1 s%'", con)
    for st in R.IMOS_CAL:
        seg = R.imos_segments(st)
        b = seg[seg.role == 'pre-registered background']
        g = R.imos_gain(st)
        lev = {(10, 20): [], (20, 40): []}
        for p in b.path:
            _, out = R.imos_record_band_power(p, st, g, bands=tuple(lev), hop_s=1.0)
            for k in lev:
                lev[k].append(out[k] / (k[1] - k[0]))
        for k, x in lev.items():
            got = 10 * np.log10(np.median(np.concatenate(x)))
            ref = v[(v.site_id == st) & (v.band_label == f'{k[0]}-{k[1]} Hz')].value.iloc[0]
            check(f'{st} median 1-s PSD {k[0]}-{k[1]} Hz vs data store', abs(got - ref) < 0.1, got=got, store=ref, n_records=len(b))


def t_kadri():
    for st, (t0, t1), ref, tol in [('H01W', (1620, 3420), 104.285, 0.1), ('H08S', (3600, 4800), None, None)]:
        k = R.kadri_series(st)
        c = k.coverage()
        ok_cov = abs(c.t_start_s.min() - t0) < 2 and abs(c.t_end_s.max() - t1) < 2
        lv = 10 * np.log10(k.e / k.dt)
        if st == 'H01W':
            med = np.median(lv)
            check('Kadri Cape Leeuwin coverage and median 1-s level (panels a-c)', ok_cov and abs(med - ref) < tol,
                  start_s=c.t_start_s.min(), end_s=c.t_end_s.max(), median_db=med, store_db=ref, bins=len(lv))
        else:
            med_d = np.median(lv[k.block == 0])
            check('Kadri Diego Garcia South coverage and panel d median 1-s level (full)', ok_cov and abs(med_d - 102.335) < 0.3,
                  start_s=c.t_start_s.min(), end_s=c.t_end_s.max(), median_d_db=med_d, store_db=102.335, bins=len(lv))


def t_royer():
    for st in ['H01W', 'SSEIR', 'SWAMS3']:
        r = R.royer_series(st, 'appendix')
        o = np.argsort(r.t0)
        overlap = np.any(r.t0[o][1:] < (r.t0 + r.dt)[o][:-1] - 1e-6)
        c = r.coverage()
        check(f'Royer {st} appendix spectrogram coverage, no double time', (not overlap) and c.t_start_s.min() < 65 and c.t_end_s.max() > 6800,
              start_s=c.t_start_s.min(), end_s=c.t_end_s.max(), covered_s=c.covered_s.sum(), median_bin_s=np.median(r.dt))
    for st in ['MAD', 'NCRO', 'WKER', 'SWAMS2']:
        r = R.royer_series(st, 'fig')
        c = r.coverage()
        check(f'Royer {st} event panels read (short, centred on Royer events)', len(c) >= 1, panels=len(c), covered_s=c.covered_s.sum(),
              spans=';'.join(f'{a:.0f}-{b:.0f}' for a, b in zip(c.t_start_s, c.t_end_s)))
    h = R.h01w_composite()
    o = np.argsort(h.t0)
    overlap = np.any(h.t0[o][1:] < (h.t0 + h.dt)[o][:-1] - 1e-6)
    kad = (h.t0 >= 1620) & (h.t0 < 3420)
    check('Cape Leeuwin composite: Kadri 00:27-00:57, Royer elsewhere, no double time', (not overlap) and np.all(h.block[kad] < 10),
          bins=len(h.t0), covered_s=h.dt.sum())
    p = R.royer_picks()
    lab = R.royer_labelled()
    hyd = lab[lab.receiver_kind.isin(['OHASISBIO hydrophone', 'IMS hydrophone element'])].dropna(subset=['resid_obs_minus_pred_s'])
    med, sd = hyd.resid_obs_minus_pred_s.median(), hyd.resid_obs_minus_pred_s.std()
    check('Royer picks and labelled set; timing rule residuals', len(lab) == 840 and abs(med + 3.1) < 0.05 and abs(sd - 8.6) < 0.05,
          picks_with_time=len(p), labelled_rows=len(lab), hydrophone_residuals=len(hyd), median_s=med, sd_s=sd,
          speed_km_s=float(np.median(lab.dist_km / (lab.pred_s - R.to_s(lab.origin_utc)))))


if __name__ == '__main__':
    t_synthetic_band_power()
    t_imos_headers_and_duty()
    t_imos_levels()
    t_kadri()
    t_royer()
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('reader_tests.json')
    out.write_text(json.dumps(RESULTS, indent=1))
    print(f"{sum(r['passed'] for r in RESULTS)}/{len(RESULTS)} passed")
