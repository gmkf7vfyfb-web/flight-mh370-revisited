#!/bin/sh
# Real run, amendment A2 (v5eb84cde): R1-R5 in parallel.
# usage: sh run_final2.sh <level_correction.json> <pd_curves.json> <out_root>
LEV="$1"; PD="$2"; ROOT="$3"
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT"
export OMP_NUM_THREADS=3 OPENBLAS_NUM_THREADS=3 MKL_NUM_THREADS=3
run() { python "$DIR/run_search2.py" --out "$ROOT/$1" --level "$LEV" --pd "$PD" --case "$2" --stations "$3" --nnull 500 > "$ROOT/$1.log" 2>&1; }
run R1_primary zero_bias_wide primary &
run R2_indian_ocean_posthoc indian_ocean_posthoc primary &
run R3_all_ocean_check all_ocean_check primary &
run R4_ohasisbio_picks zero_bias_wide ohasisbio_picks &
run R5_no_royer_h01w zero_bias_wide no_royer_h01w &
wait
tail -n 1 "$ROOT"/*.log
