"""Readers for the first network detection search on the 8 March 2014 data held.

Every reader returns a BandSeries: band energy per time bin for one station, with its coverage blocks.
  t0   : bin start, seconds after 2014-03-08T00:00:00Z (true UTC)
  dt   : bin length, s
  e    : band energy in the bin (units given in .units; uPa^2 s unless stated)
  block: integer id of the contiguous block that the bin belongs to (record, panel)
Read-only use of all inputs. No values are invented: a time with no data has no bin.
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import signal

A = Path('/Users/pete/.claude-science/orgs/9db41e8b-db54-4736-82b9-d77e2a9ad222/artifacts/proj_9cc1a5a85f63')
DB = A / 'b3b0fe8f-b907-4214-9c02-18f9a4bf778c/v321ea0f6_hydro_data.sqlite'
INPUTS = Path('/Users/pete/Downloads/mh370-inputs/hydroacoustics')
T_REF = pd.Timestamp('2014-03-08T00:00:00Z')

FS = 6000.0
Q = 12                 # 6000 Hz -> 500 Hz
FS_D = FS / Q
IMOS_CAL = {  # Curtin metadata files (MH370/3315_3250_3376__MetaData.txt, Portland_MH370/MetaData_3274_3275.txt)
    'IMOS3315': dict(cal='MH370/Calibration/52946955.DAT', sens_db=-197.8),
    'IMOS3250': dict(cal='MH370/Calibration/5236BCF7.DAT', sens_db=-197.7),
    'IMOS3376': dict(cal='MH370/Calibration/529482AC.DAT', sens_db=-196.0),
    'IMOS3274': dict(cal='Portland_MH370/calibration/54E49F6D.DAT', sens_db=-196.0),
    'IMOS3275': dict(cal='Portland_MH370/calibration/54E4975C.DAT', sens_db=-196.0),
}
KADRI_K = {'H01W': 5.193951, 'H08S': 5.230143}   # noise_fix_calibration: PP/RMS, causal 4-pole 5-40 Hz, 'held' set


def db_connect():
    return sqlite3.connect(f'file:{DB}?mode=ro', uri=True)


def to_s(ts) -> np.ndarray:
    """ISO strings / Timestamps -> seconds after 2014-03-08T00:00Z."""
    t = pd.to_datetime(pd.Series(ts).astype(str).str.replace('Z', '', regex=False), utc=True, format='ISO8601')
    return ((t - T_REF).dt.total_seconds()).to_numpy()


@dataclass
class BandSeries:
    station: str
    form: str
    band_hz: tuple
    t0: np.ndarray
    dt: np.ndarray
    e: np.ndarray
    block: np.ndarray
    units: str = 'uPa^2 s'
    calibration_state: str = ''
    provenance: list = field(default_factory=list)

    def coverage(self) -> pd.DataFrame:
        """One row per block: start, end, covered seconds."""
        d = pd.DataFrame(dict(block=self.block, t0=self.t0, t1=self.t0 + self.dt, dt=self.dt))
        g = d.groupby('block').agg(t_start_s=('t0', 'min'), t_end_s=('t1', 'max'), covered_s=('dt', 'sum')).reset_index()
        g['station'] = self.station
        g['form'] = self.form
        return g

    def concat(self, other: 'BandSeries', block_offset: int | None = None) -> 'BandSeries':
        off = (self.block.max() + 1) if block_offset is None else block_offset
        return BandSeries(self.station, self.form + '+' + other.form, self.band_hz,
                          np.r_[self.t0, other.t0], np.r_[self.dt, other.dt], np.r_[self.e, other.e],
                          np.r_[self.block, other.block + off], self.units,
                          self.calibration_state + ' | ' + other.calibration_state, self.provenance + other.provenance)


# ---------------------------------------------------------------- IMOS raw loggers (form F2)
def read_volts(path) -> np.ndarray:
    """Port of Curtin load_loggerdatanew.m: 5 header lines, big-endian uint16, footer from 'Record'; volts, mean removed."""
    raw = Path(path).read_bytes()
    pos = 0
    for _ in range(5):
        pos = raw.index(b'\n', pos) + 1
    tail = raw[-1000:]
    footer_bytes = 1000 - tail.index(b'Record')
    end = len(raw) - footer_bytes - 2
    n = (end - pos) // 2
    x = np.frombuffer(raw, dtype='>u2', count=n, offset=pos).astype(np.float64) * (5.0 / 65536)
    return x - x.mean()


def read_header(path) -> list[str]:
    raw = Path(path).read_bytes()[:2000]
    return raw.decode('latin-1').split('\n')[:5]


def imos_gain(station: str):
    """System gain G(f), dB, from the logger's pre-deployment white-noise record (input -90 dB re 1 V^2/Hz)."""
    x = signal.resample_poly(read_volts(INPUTS / 'imos' / IMOS_CAL[station]['cal']), 1, Q)
    f, p = signal.welch(x, fs=FS_D, window='hann', nperseg=int(4 * FS_D), noverlap=int(2 * FS_D), detrend='constant')
    return f, 10 * np.log10(p) + 90.0


def imos_record_band_power(path, station, gain, bands=((10, 40), (5, 40)), win_s=1.0, hop_s=0.5):
    """Calibrated band power (uPa^2) per hop for one record. 1-s Hann periodograms, 0.5-s hop, per-bin gain.
    dB re 1 uPa^2/Hz = 10 log10(V^2/Hz) - G(f) - S_h  (module convention, imos_noise.py line 117)."""
    return band_power_from_volts(read_volts(path), IMOS_CAL[station]['sens_db'], gain, bands, win_s, hop_s)


def band_power_from_volts(volts, sens_db, gain, bands=((10, 40), (5, 40)), win_s=1.0, hop_s=0.5):
    fg, G = gain
    x = signal.resample_poly(volts, 1, Q)
    nper, nhop = int(win_s * FS_D), int(hop_s * FS_D)
    f, tt, Z = signal.stft(x, fs=FS_D, window='hann', nperseg=nper, noverlap=nper - nhop, detrend=False,
                           boundary=None, padded=False, scaling='psd')
    P = np.abs(Z) ** 2
    P[1:-1] *= 2.0                                       # one-sided density
    cal = 10 ** ((np.interp(f, fg, G) + sens_db) / 10)
    Pu = P / cal[:, None]                                # uPa^2/Hz
    df = f[1] - f[0]
    out = {}
    for lo, hi in bands:
        m = (f >= lo) & (f < hi)
        out[(lo, hi)] = Pu[m].sum(axis=0) * df           # uPa^2
    t_start = tt - win_s / 2                             # window start, s after record start
    return t_start, out


def imos_segments(station: str, which=('mh370_day',)) -> pd.DataFrame:
    sid = station.replace('IMOS', 'imos')
    with db_connect() as con:
        seg = pd.read_sql(f"select * from segment where dataset_id in ({','.join(repr(sid + '_' + w) for w in which)})", con)
    seg['t_start_s'] = to_s(seg.t_start_utc)
    seg['path'] = seg.file_path.str.replace('INPUTS:', str(INPUTS) + '/', regex=False)
    return seg.sort_values('t_start_s').reset_index(drop=True)


def imos_series_from_cache(station: str, cache: pd.DataFrame, band=(10, 40)) -> BandSeries:
    c = cache[cache.station == station]
    col = f'p_{band[0]}_{band[1]}'
    return BandSeries(station, 'IMOS raw logger', band, c.t0.to_numpy(), c.dt.to_numpy(), (c[col] * c.dt).to_numpy(),
                      c.block.to_numpy(), 'uPa^2 s',
                      'calibrated: per-bin system gain from pre-deployment record + hydrophone sensitivity; '
                      'clock drift-corrected (true UTC = logger - e(t)); 8 Hz hardware high-pass, so band 10-40 Hz',
                      ['hydro_data.sqlite segment table', 'INPUTS:imos raw .DAT'])


# ---------------------------------------------------------------- Kadri 2024 Fig. 9 digitised traces (form F3)
KADRI_PANELS = {'H01W': ['a_h01w', 'b_h01w', 'c_h01w'], 'H08S': ['d_h08s', 'e_h08s']}


def kadri_series(station: str, bin_s=1.0) -> BandSeries:
    """1-s energy from digitised vertices: RMS = (max-min in the bin)/k (fix C1 method); e = RMS^2 * bin (uPa^2 s).
    One block per panel (panels can differ in amplitude scale)."""
    rows = []
    with db_connect() as con:
        for b, pnl in enumerate(KADRI_PANELS[station]):
            d = pd.read_sql(f'select utc, pressure_pa from dg_data_kadri_fig9_digitised_kadri_2024_figure9_panel_{pnl}', con)
            t = to_s(d.utc)
            t_start = np.floor(t.min())
            idx = np.floor((t - t_start) / bin_s).astype(int)
            g = pd.DataFrame(dict(i=idx, p=d.pressure_pa.to_numpy())).groupby('i').p.agg(['max', 'min', 'size'])
            g = g[g['size'] >= 3]                          # need vertices to form a peak-to-peak value
            rms_upa = (g['max'] - g['min']) / KADRI_K[station] * 1e6
            rows.append(pd.DataFrame(dict(t0=t_start + g.index.to_numpy() * bin_s, dt=bin_s, e=rms_upa.to_numpy() ** 2 * bin_s, block=b,
                                          panel=pnl)))
    r = pd.concat(rows, ignore_index=True)
    return BandSeries(station, 'Kadri 2024 Fig. 9 digitised trace', (5, 40), r.t0.to_numpy(), r.dt.to_numpy(), r.e.to_numpy(),
                      r.block.to_numpy(), 'uPa^2 s',
                      f'vertex peak-to-peak / k (k={KADRI_K[station]}, fix C1); envelope resolution only (~15 vertices/s)',
                      [f'dg_data_kadri_fig9_digitised_kadri_2024_figure9_panel_{p}' for p in KADRI_PANELS[station]])


# ---------------------------------------------------------------- Royer 2016 digitised spectrogram bands (form F4)
def royer_tables(con=None) -> list[str]:
    with db_connect() as c:
        t = pd.read_sql("select name from sqlite_master where type='table' and name like 'dg_royer_2016_spectrograms_%'", c).name
    return t.tolist()


def royer_series(station: str, which='appendix') -> BandSeries:
    """Band power from the 5-40 Hz band-mean PSD read from Royer's spectrogram colours: P = 10^(psd/10) * 35 Hz.
    Colour readings are about 1.9-3.0 dB below the true level at H01W (Royer noise calibration note); the search uses
    ratios to the local noise in the same panel, so the offset cancels. One block per panel."""
    key = {'H01W': 'h01w2', 'SSEIR': 'sseir', 'SWAMS3': 'swams3', 'SWAMS2': 'swams2', 'MAD': 'mad', 'NCRO': 'ncro', 'WKER': 'wker'}[station]
    tabs = [t for t in royer_tables() if (f'_{key}_' in t) and (which in t)]
    rows = []
    tabs = sorted(tabs)
    nominal = []
    for tname in tabs:
        hh = re.findall(r'_(\d{4})_(\d{4})_band$', tname)[0]
        nominal.append(tuple(int(h[:2]) * 3600 + int(h[2:]) * 60 for h in hh))
    with db_connect() as con:
        for b, tname in enumerate(tabs):
            d = pd.read_sql(f'select t_utc_s, psd_db_5_40 from {tname}', con).dropna().sort_values('t_utc_s')
            # panels overlap by ~3 min at each join: keep each time once (cut at the next panel's nominal start)
            later = [n[0] for n in nominal if n[0] > nominal[b][0]]
            if later:
                d = d[d.t_utc_s < min(later)]
            t = d.t_utc_s.to_numpy()
            dt = np.diff(t)
            dt = np.r_[dt, np.median(dt)]
            dt = np.minimum(dt, 3 * np.median(dt))
            if later:
                dt = np.minimum(dt, min(later) - t)
            rows.append(pd.DataFrame(dict(t0=t, dt=dt, e=10 ** (d.psd_db_5_40.to_numpy() / 10) * 35.0 * dt, block=b, panel=tname)))
    r = pd.concat(rows, ignore_index=True)
    return BandSeries(station, f'Royer 2016 spectrogram ({which})', (5, 40), r.t0.to_numpy(), r.dt.to_numpy(), r.e.to_numpy(),
                      r.block.to_numpy(), 'uPa^2 s (colour reading, uncalibrated offset)',
                      'spectrogram colour reading, 70-100 dB re 1 uPa^2/Hz colour scale (saturates); ~1.42 s bins', sorted(tabs))


def h01w_composite() -> BandSeries:
    """Cape Leeuwin: Kadri trace where it exists (00:27-00:57), Royer H01W2 appendix spectrogram elsewhere. Never both."""
    k = kadri_series('H01W')
    r = royer_series('H01W', 'appendix')
    k0, k1 = k.t0.min(), (k.t0 + k.dt).max()
    keep = ((r.t0 + r.dt) <= k0) | (r.t0 >= k1)
    r2 = BandSeries(r.station, r.form, r.band_hz, r.t0[keep], r.dt[keep], r.e[keep], r.block[keep], r.units, r.calibration_state, r.provenance)
    return k.concat(r2, block_offset=10)


# ---------------------------------------------------------------- Royer picks and labelled arrivals
def royer_picks() -> pd.DataFrame:
    with db_connect() as con:
        a = pd.read_sql('select * from dg_royer_2016_royer_arrivals', con)
        ev = pd.read_sql('select * from dg_royer_2016_royer_events', con)
    a = a.dropna(subset=['arrival_utc']).copy()
    a['arrival_s'] = a.arrival_s_after_T0.astype(float)   # T0 = 2014-03-08 00:00:00 UTC
    return a.merge(ev[['index', 'lat_deg', 'lon_deg', 'type_text']], on='index', how='left')


def royer_labelled() -> pd.DataFrame:
    with db_connect() as con:
        d = pd.read_sql('select * from royer_event_labelled', con)
    d['pred_s'] = to_s(d.pred_arrival_utc)
    d['obs_s'] = np.where(d.royer_observed_utc.notna(), to_s(d.royer_observed_utc.fillna('2014-03-08T00:00:00')), np.nan)
    return d
