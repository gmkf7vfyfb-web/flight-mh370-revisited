"""Figures for the IMS open-March background note. Usage (inside the python kernel with figure-style loaded):
exec(open('scripts/figures.py').read()); make_all(OUTDIR)"""
import numpy as np, pandas as pd, matplotlib.pyplot as plt, textwrap, json
from pathlib import Path

NAMES = {"H01W": "Cape Leeuwin (H01W)", "H08S": "Diego Garcia South (H08S)"}
COL = {"H01W": "#1f4e9c", "H08S": "#b8322a"}
CLOCK_TXT = {"H01W": "00:25-02:20 UTC", "H08S": "00:45-02:50 UTC"}

def footnote(fig, plain, tech, y0=0.0, width=170):
    a = "\n".join(textwrap.wrap("Plain: " + plain, width)); b = "\n".join(textwrap.wrap("Technical: " + tech, width))
    fig.text(0.01, y0, a + "\n\n" + b, ha="left", va="top", fontsize=6.5, color="#444444")

def fig_noise(O, fn):
    NQ = pd.read_csv(O / "ims-march-noise-percentiles.csv"); BLz = np.load(O / "blackman_curves_used.npz")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.2), sharey=True)
    for ax, st in zip(axs, ("H01W", "H08S")):
        q = NQ[(NQ.source == "blocks") & (NQ.station == st) & (NQ.element == "all") & (NQ.subset == "clock_window") & (NQ.quantity == "psd_1hz_db_re_1uPa2_per_Hz")]
        f = q.freq_hz.values
        ax.fill_between(f, q.p5, q.p95, color=COL[st], alpha=0.15, lw=0, label="March 2015-2019, 5-95 %")
        ax.fill_between(f, q.p25, q.p75, color=COL[st], alpha=0.3, lw=0, label="March 2015-2019, 25-75 %")
        ax.plot(f, q.p50, color=COL[st], lw=1.6, label="March 2015-2019, median")
        B = BLz[st]; ax.plot(BLz["f"], np.nanmedian(B, 0), color="#333333", lw=1.1, ls="--", label="2003 median (Blackman et al. 2004; 23 panels H01W, 19 H08S)")
        sp = 96.2 - 10 * np.log10(35.0); ax.plot([5, 40], [sp, sp], color="#888888", lw=1.3, ls=":", label="previous stand-in (Perth Canyon logger)")
        ax.set_xscale("log"); ax.set_xlim(1, 100); ax.set_xticks([1, 2, 5, 10, 20, 50, 100]); ax.set_xticklabels(["1", "2", "5", "10", "20", "50", "100"])
        ax.set_xlabel("Frequency (Hz)"); ax.set_title(f"{NAMES[st]}: noise in the arrival window", loc="left")
        n = int(q.n_minutes.iloc[0]); ax.text(0.98, 0.97, f"n = {n:,} element-minutes", transform=ax.transAxes, ha="right", va="top", fontsize=6.5)
    axs[0].set_ylabel("Noise power spectral density\n(dB re 1 µPa²/Hz)")
    h1, l1 = axs[0].get_legend_handles_labels(); h2, l2 = axs[1].get_legend_handles_labels()
    l1 = [x.replace("March 2015-2019", "Cape Leeuwin") for x in l1]; l2 = [x.replace("March 2015-2019", "Diego Garcia South") for x in l2]
    fig.legend(h1[:3] + h2[:3] + h1[3:], l1[:3] + l2[:3] + l1[3:], frameon=False, fontsize=6.5, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.33))
    fig.tight_layout(rect=(0, 0.33, 1, 1))
    return fig

def save(fig, path, plain, tech, y0=0.2):
    footnote(fig, plain, tech, y0=y0)
    fig.savefig(path, dpi=300, bbox_inches="tight")

def fig_tod(O):
    NQ = pd.read_csv(O / "ims-march-noise-percentiles.csv")
    BS = {"H01W": 101.64, "H08S": 95.49}
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True)
    for ax, st in zip(axs, ("H01W", "H08S")):
        q = NQ[(NQ.source == "fulldays") & (NQ.station == st) & (NQ.element == "all") & NQ.subset.str.startswith("hour_")].copy()
        q["h"] = q.subset.str[5:].astype(int) + 0.5; q = q.sort_values("h")
        a0, a1 = {"H01W": (25, 140), "H08S": (45, 170)}[st]
        ax.axvspan(a0 / 60, a1 / 60, color="#dddddd", lw=0, label=f"arrival window {CLOCK_TXT[st]}")
        ax.fill_between(q.h, q.p25, q.p75, color=COL[st], alpha=0.3, lw=0, label="25-75 %")
        ax.plot(q.h, q.p50, color=COL[st], marker="o", ms=2.5, lw=1.2, label="median")
        ax.axhline(BS[st], color="#333333", ls="--", lw=1, label="2003 median (Blackman et al. 2004)")
        ax.axhline(96.2, color="#888888", ls=":", lw=1.3, label="previous stand-in (Perth Canyon logger)")
        ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 4)); ax.set_xlabel("Hour of day (UTC)")
        nd = int(q.n_minutes.max() // 60 // 3) if len(q) else 0
        ax.set_title(f"{NAMES[st]}: 5-40 Hz level through 8 March", loc="left")
        ax.margins(y=0.08)
    axs[0].set_ylabel("Band level 5-40 Hz\n(dB re 1 µPa)")
    h1, l1 = axs[0].get_legend_handles_labels(); h2, l2 = axs[1].get_legend_handles_labels()
    l1 = [x if not x.startswith(("25", "median")) else "Cape Leeuwin " + x for x in l1]; l2 = [x if not x.startswith(("25", "median")) else "Diego Garcia South " + x for x in l2]
    hh = [h1[0], h2[0], h1[1], h1[2], h2[1], h2[2], h1[3], h1[4]]; ll = [l1[0].replace("arrival window", "Cape Leeuwin arrival window"), l2[0].replace("arrival window", "Diego Garcia South arrival window"), l1[1], l1[2], l2[1], l2[2], l1[3], l1[4]]
    fig.legend(hh, ll, frameon=False, fontsize=6.5, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.33))
    fig.tight_layout(rect=(0, 0.33, 1, 1))
    return fig

def fig_bearing(O, src="blocks", stat="D1_540"):
    V = pd.read_pickle(O / "windows_all_valid.pkl.gz")
    S = pd.read_csv(O.parent / "bearing-sectors.csv")
    order = ["Antarctic sector (ice likely)", "Antarctic and arc sectors overlap", "periodic 5-15 s (airgun train or fin whale)",
             "periodic 40-200 s (whale song or repeating source)", "T-phase (catalogue match)", "T-phase-like (no catalogue match)", "unknown"]
    cmap = {"Antarctic sector (ice likely)": "#6baed6", "Antarctic and arc sectors overlap": "#9e9ac8", "periodic 5-15 s (airgun train or fin whale)": "#fd8d3c",
            "periodic 40-200 s (whale song or repeating source)": "#74c476", "T-phase (catalogue match)": "#8c6d31", "T-phase-like (no catalogue match)": "#bd9e39", "unknown": "#969696"}
    fig, axs = plt.subplots(2, 1, figsize=(7.2, 4.6), sharex=True)
    for ax, st in zip(axs, ("H01W", "H08S")):
        g = V[(V.source == src) & (V.station == st) & (V.stat == stat) & V.good_bearing & (V.p_same < 0.3)]
        bins = np.arange(0, 361, 5)
        bottom = np.zeros(len(bins) - 1)
        for c in order:
            h, _ = np.histogram(g[g["class"] == c].baz, bins=bins)
            if h.sum() == 0: continue
            ax.bar(bins[:-1], h, width=5, align="edge", bottom=bottom, color=cmap[c], lw=0, label=c)
            bottom += h
        r = S[(S.triad == st) & (S.sector == "arc_20_40S")].iloc[0]
        ax.axvspan(r.az_min, r.az_max, color="#f2d7d5", lw=0, zorder=0, label="bearing sector of the 7th arc, 20-40 S")
        ax.set_yscale("symlog", linthresh=1); ax.set_ylabel("Windows per 5° bin")
        ax.set_yticks([0, 1, 10, 100, 1000]); ax.set_yticklabels(["0", "1", "10", "100", "1000"])
        hrs = (V[(V.source == src) & (V.station == st) & (V.stat == stat)].shape[0]) * 55 / 3600
        ax.set_title(f"{NAMES[st]}: direction of coherent arrivals at the screen level (p < 0.3)", loc="left")
        ax.text(0.99, 0.95, f"n = {len(g):,} windows in {hrs:,.0f} h", transform=ax.transAxes, ha="right", va="top", fontsize=6.5)
    axs[1].set_xlabel("Back-azimuth at the station (degrees from north)"); axs[1].set_xlim(0, 360); axs[1].set_xticks(range(0, 361, 45))
    h, l = axs[0].get_legend_handles_labels(); h2, l2 = axs[1].get_legend_handles_labels()
    seen = {}
    for a, b in zip(h + h2, l + l2): seen.setdefault(b, a)
    fig.legend(seen.values(), seen.keys(), frameon=False, fontsize=6.5, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.075))
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    return fig

def fig_rates(O, src="blocks", stat="D1_540"):
    V = pd.read_pickle(O / "windows_all_valid.pkl.gz"); FA = pd.read_csv(O / "ims-march-false-alarm-rates.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3))
    levels = [(0.3, "screen p < 0.3"), (0.1, "mark p < 0.1"), (0.05, "report p < 0.05")]
    for ax, st in zip(axs, ("H01W", "H08S")):
        for j, (basis, mk, lab) in enumerate((("same_season", "o", "thresholds from March 2015-2019"), ("standin_2014", "s", "thresholds from the 2014 stand-in null"))):
            pc = "p_same" if basis == "same_season" else "p_standin"
            for i, (lv, ln) in enumerate(levels):
                g = V[(V.source == src) & (V.station == st) & (V.stat == stat) & V.in_clock_window]
                d = g.assign(hit=(g[pc] < lv) & g.in_arc_sector).groupby("day").agg(k=("hit", "sum"), n=("hit", "size"))
                rate = d.k / (d.n * 55 / 3600)
                x = i + (j - 0.5) * 0.36
                jit = (np.random.default_rng(1).random(len(rate)) - 0.5) * 0.14
                ax.scatter(x + jit, rate, s=5, color=COL[st] if j == 0 else "#777777", alpha=0.45, lw=0, marker=mk)
                row = FA[(FA.source == src) & (FA.station == st) & (FA.statistic == stat) & (FA.p_basis == basis) & (FA.p_threshold == lv) & (FA.time_subset == "clock_window") & (FA.bearing_condition == "arc_sector_20_40S")]
                if row.empty: continue
                r = row.iloc[0]
                lo, hi = r.rate_daybootstrap90_lo, r.rate_daybootstrap90_hi
                ax.vlines(x, lo, hi, color="black", lw=0.9)
                ax.plot([x - 0.05, x + 0.05], [lo] * 2, color="black", lw=0.9); ax.plot([x - 0.05, x + 0.05], [hi] * 2, color="black", lw=0.9)
                ax.plot(x, r.rate_per_h, mk, color="black", ms=4, mfc="white" if j else "black", label=lab if i == 0 else None, zorder=5)
        ax.set_xticks(range(3)); ax.set_xticklabels([l for _, l in levels], fontsize=6.5)
        ax.set_title(f"{NAMES[st]}\nwindow {CLOCK_TXT[st]}", loc="left")
        ax.set_ylabel("Arrivals per hour from the\ndirection of the 7th arc (20-40 S)"); ax.set_yscale("symlog", linthresh=0.1); ax.set_ylim(-0.01, 8)
        ax.set_yticks([0, 0.1, 0.3, 1, 3]); ax.set_yticklabels(["0", "0.1", "0.3", "1", "3"])
    from matplotlib.lines import Line2D
    hh = [Line2D([], [], marker="o", color="black", ls="none", ms=4), Line2D([], [], marker="s", color="black", mfc="white", ls="none", ms=4),
          Line2D([], [], marker="o", color="#999999", ls="none", ms=3, alpha=0.6)]
    fig.legend(hh, ["mean rate, thresholds from March 2015-2019 data (bar: 90 % day bootstrap)", "mean rate, thresholds from the 2014 stand-in null (bar: 90 % day bootstrap)", "one day"],
               frameon=False, fontsize=6.5, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 0.33))
    fig.tight_layout(rect=(0, 0.33, 1, 1))
    return fig
