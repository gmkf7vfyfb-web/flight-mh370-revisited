"""Aggregate the processed IMS March station-days: noise percentiles, detections table, false-alarm rates.
EXPLORATORY. Nothing here returns a likelihood to the composer.
Usage: python analyse.py <out_dir> <tag1>=<run_dir1> [<tag2>=<run_dir2> ...]
Sources: 'blocks' = 00:00-04:00 UTC of every available March day (primary for detections and rates; the null pool is
the same clock hours); 'fulldays' = complete 8 March days (time-of-day noise and an all-day sensitivity)."""
import sys, glob, json, numpy as np, pandas as pd
from pathlib import Path
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
SRC = dict(a.split("=", 1) for a in sys.argv[2:])
ROOT = Path(__file__).resolve().parent.parent
TO_C = np.array([2, 2.5, 3.15, 4, 5, 6.3, 8, 10, 12.5, 16, 20, 25, 31.5, 40, 50, 63, 80])
TO_BW = TO_C * (10 ** 0.05 - 10 ** -0.05)
CLOCK = {"H01W": (25, 140), "H08S": (45, 170)}          # minutes after 00:00 UTC, [start, end)
SECT = pd.read_csv(ROOT / "out" / "bearing-sectors.csv")
ARC = {r.triad: (r.az_min, r.az_max) for r in SECT[SECT.sector == "arc_20_40S"].itertuples()}
ARC_S = {r.triad: (r.az_min, r.az_max) for r in SECT[SECT.sector == "arc_20_40S_88_110E"].itertuples()}
A2035 = {r.triad: (r.az_min, r.az_max) for r in SECT[SECT.sector == "arc_20_35S"].itertuples()}
A3540 = {r.triad: (r.az_min, r.az_max) for r in SECT[SECT.sector == "arc_35_40S"].itertuples()}
ANT = {r.triad: (r.az_min, r.az_max) for r in SECT[SECT.sector == "antarctic_55_66S_30_150E"].itertuples()}
EARLIER = {"H01W": (248.0, 298.0)}                      # sector quoted in the brief from earlier work
LEVELS = [(0.3, "screen"), (0.1, "mark"), (0.05, "report")]
GOOD = dict(cc_min=0.3, closure_s=0.02, vmin=1.3, vmax=1.9)

def in_sec(b, s):
    return (b >= s[0]) & (b <= s[1])

# ------------------------------------------------------------------ load
Ws = []
noise = {}
for tag, run in SRC.items():
    for f in sorted(glob.glob(str(Path(run) / "days" / "*_windows.pkl.gz"))):
        w = pd.read_pickle(f); w["source"] = tag; Ws.append(w)
    for f in sorted(glob.glob(str(Path(run) / "days" / "*_noise.npz"))):
        st, day = Path(f).name.split("_")[:2]
        z = np.load(f); noise[(tag, st, day)] = {k: z[k] for k in z.files}
W = pd.concat(Ws, ignore_index=True)
W["year"] = W.day.str[:4].astype(int)
W["good_bearing"] = (W.cc_min >= GOOD["cc_min"]) & (W.closure_s.abs() <= GOOD["closure_s"]) & W.v_app_kms.between(GOOD["vmin"], GOOD["vmax"])

# ------------------------------------------------------------------ noise percentiles
Q = [5, 25, 50, 75, 95]
rows = []
def addq(st, el, subset, qty, x, arr, src=None):
    arr = arr[np.isfinite(arr).all(1)] if arr.ndim == 2 else arr[np.isfinite(arr)]
    if len(arr) == 0: return
    P = np.percentile(arr, Q, axis=0)
    for j, xv in enumerate(x):
        rows.append(dict(source=src, station=st, element=el, subset=subset, quantity=qty, freq_hz=xv, n_minutes=len(arr),
                         **{f"p{q}": (P[i, j] if arr.ndim == 2 else P[i]) for i, q in enumerate(Q)}))
nstats = {}
for src, st in [(a, b) for a in SRC for b in ("H01W", "H08S")]:
    a0, a1 = CLOCK[st]
    mins = np.arange(1440)
    for el in [f"{st}{i}" for i in (1, 2, 3)] + ["all"]:
        P1, TO, SPL, HR = [], [], [], []
        for (tg, s, day), d in noise.items():
            if s != st or tg != src: continue
            for e in ([el] if el != "all" else [f"{st}{i}" for i in (1, 2, 3)]):
                if f"{e}_psd1" not in d: continue
                P1.append(d[f"{e}_psd1"]); TO.append(d[f"{e}_to"]); SPL.append(d[f"{e}_spl540"]); HR.append(mins)
        if not P1: continue
        P1, TO, SPL, HR = np.concatenate(P1), np.concatenate(TO), np.concatenate(SPL), np.concatenate(HR)
        CW = (HR >= a0) & (HR < a1)
        subs = (("all_day", np.ones(len(HR), bool)), ("clock_window", CW), ("rest_of_day", ~CW)) if src == "fulldays" else \
               (("block_00_04", HR < 240), ("clock_window", CW), ("block_outside_window", (HR < 240) & ~CW))
        for subset, m in subs:
            addq(st, el, subset, "psd_1hz_db_re_1uPa2_per_Hz", np.arange(1, 101), P1[m], src)
            addq(st, el, subset, "third_octave_spl_db_re_1uPa", TO_C, TO[m], src)
            addq(st, el, subset, "third_octave_mean_psd_db_re_1uPa2_per_Hz", TO_C, TO[m] - 10 * np.log10(TO_BW), src)
            addq(st, el, subset, "band_spl_5_40Hz_db_re_1uPa", [np.nan], SPL[m][:, None], src)
        for h in range(24):
            m = (HR // 60) == h
            addq(st, el, f"hour_{h:02d}", "band_spl_5_40Hz_db_re_1uPa", [np.nan], SPL[m][:, None], src)
        nstats[(src, st, el)] = dict(n_min=int(np.isfinite(SPL).sum()))
NQ = pd.DataFrame(rows)
NQ.to_csv(OUT / "ims-march-noise-percentiles.csv", index=False)

# ------------------------------------------------------------------ references: Blackman 2003 and the stand-in
BD = ROOT / "repo/Claude Science Project Sep 29/engine/hypotheses/hydroacoustics/results-data/blackman_noise"
z = np.load(BD / "blackman_noise_curves.npz"); pan = pd.read_csv(BD / "blackman_noise_panels.csv")
okp = pan[pan.status == "ok"]; fB = z["f"]
BL = {s: np.array([z[f"{r.station}_p{r.page}_i{r.image}_r{r.row}"] for r in okp[okp.station == s].itertuples()]) for s in ("H01W", "H08S", "H08N")}
STANDIN_SPL = 96.2         # IMOS 3376 '2b' background median 5-40 Hz SPL (blackman_noise_offsets.json definition)
STANDIN_PSD = STANDIN_SPL - 10 * np.log10(35.0)
ref = []
for src, st in [(a, b) for a in SRC for b in ("H01W", "H08S")]:
    M = BL[st]; m540 = (fB >= 5) & (fB < 40)
    b_spl = np.nanmedian(10 * np.log10(np.nansum(10 ** (M[:, m540] / 10), 1) * 0.5))
    b_curve = np.nanmedian(M, 0)
    for el in (f"{st}1", "all"):
        q = NQ[(NQ.source == src) & (NQ.station == st) & (NQ.element == el)]
        for subset in ("all_day", "clock_window", "rest_of_day", "block_00_04"):
            s = q[(q.subset == subset) & (q.quantity == "band_spl_5_40Hz_db_re_1uPa")]
            if s.empty: continue
            s = s.iloc[0]
            ref.append(dict(source=src, station=st, element=el, subset=subset, quantity="band SPL 5-40 Hz (dB re 1 uPa)", band="5-40 Hz",
                            march_p5=s.p5, march_p25=s.p25, march_p50=s.p50, march_p75=s.p75, march_p95=s.p95,
                            blackman2003_median=b_spl, standin_imos3376=STANDIN_SPL,
                            diff_march_minus_blackman=s.p50 - b_spl, diff_march_minus_standin=s.p50 - STANDIN_SPL))
            p = q[(q.subset == subset) & (q.quantity == "psd_1hz_db_re_1uPa2_per_Hz")].set_index("freq_hz")
            for lo, hi in ((5, 40), (40, 100), (5, 100)):
                ff = np.arange(lo, hi + 1) if hi < 100 else np.arange(lo, 100)
                ff = ff[(ff >= 3.5)]
                bc = np.interp(ff, fB, b_curve)
                d = p.loc[ff, "p50"].values - bc
                ref.append(dict(source=src, station=st, element=el, subset=subset, quantity="median PSD difference, mean over 1 Hz bins (dB)", band=f"{lo}-{hi} Hz",
                                march_p50=float(np.mean(p.loc[ff, "p50"])), blackman2003_median=float(np.mean(bc)),
                                standin_imos3376=STANDIN_PSD if hi <= 40 else np.nan,
                                diff_march_minus_blackman=float(np.mean(d)),
                                diff_march_minus_standin=float(np.mean(p.loc[ff, "p50"].values - STANDIN_PSD)) if hi <= 40 else np.nan))
            t = q[(q.subset == subset) & (q.quantity == "third_octave_mean_psd_db_re_1uPa2_per_Hz")].set_index("freq_hz")
            BS = json.load(open(BD / "blackman_noise_summary.json"))["stations"][st]["psd_R_band_db"]
            for c in (5, 6.3, 8, 10, 12.5, 16, 20, 25, 31.5, 40):
                bm = BS[str(c) if c != int(c) else str(int(c))]["median"]
                ref.append(dict(source=src, station=st, element=el, subset=subset, quantity="third-octave mean PSD (dB re 1 uPa^2/Hz)", band=f"{c} Hz",
                                march_p5=t.loc[c, "p5"], march_p25=t.loc[c, "p25"], march_p50=t.loc[c, "p50"], march_p75=t.loc[c, "p75"], march_p95=t.loc[c, "p95"],
                                blackman2003_median=bm, standin_imos3376=STANDIN_PSD,
                                diff_march_minus_blackman=t.loc[c, "p50"] - bm, diff_march_minus_standin=t.loc[c, "p50"] - STANDIN_PSD))
REF = pd.DataFrame(ref); REF.to_csv(OUT / "ims-march-noise-vs-references.csv", index=False)
np.savez(OUT / "blackman_curves_used.npz", f=fB, **{s: BL[s] for s in BL})

# ------------------------------------------------------------------ p-values
V = W[W.valid].copy()
nul = np.load(ROOT / "meta" / "null_3376.npz")
V["p_same"] = np.nan; V["p_standin"] = np.nan; V["n_null_same"] = 0; V["rank"] = 0
for (src, st, stat), g in V.groupby(["source", "station", "stat"]):
    s = g.score.values; n = len(s)
    srt = np.sort(s)
    k = n - np.searchsorted(srt, s, side="left")          # count of scores >= s, including itself
    V.loc[g.index, "p_same"] = k / n                     # (k-1 + 1)/((n-1) + 1): leave-one-out, floor 1/n
    V.loc[g.index, "n_null_same"] = n - 1
    V.loc[g.index, "rank"] = pd.Series(-s).rank(method="min").astype(int).values
    key = {"D1_540": "D1", "M1b": "M1b"}.get(stat)
    if key:
        ns = np.sort(nul[key]); kk = len(ns) - np.searchsorted(ns, s, side="left")
        V.loc[g.index, "p_standin"] = (kk + 1) / (len(ns) + 1)

# ------------------------------------------------------------------ catalogue association
E = pd.read_csv(ROOT / "cat" / "events_merged_m3.csv")
for st in ("H01W", "H08S"):
    E[f"{st}_tp"] = (pd.to_datetime(E[f"{st}_t_pred"], format="ISO8601", utc=True) - pd.Timestamp("1970-01-01", tz="UTC")).dt.total_seconds()
V["t_abs"] = (pd.to_datetime(V.day, utc=True) - pd.Timestamp("1970-01-01", tz="UTC")).dt.total_seconds() + V.t_max_s   # unit-safe (pandas 3 uses us)
V["t_utc"] = pd.to_datetime(V.t_abs, unit="s", utc=True).dt.strftime("%Y-%m-%dT%H:%M:%S.%f").str[:-5]
def associate(V):
    for c in ("cat_evid", "cat_src", "cat_mag", "cat_place", "cat_dist_km", "cat_dt_s", "cat_dbaz"):
        V[c] = np.nan
    V[["cat_evid", "cat_src", "cat_place"]] = V[["cat_evid", "cat_src", "cat_place"]].astype(object)
    for st in ("H01W", "H08S"):
        tp = E[f"{st}_tp"].values; o = np.argsort(tp); tp = tp[o]; Es = E.iloc[o].reset_index(drop=True)
        idx = V.index[(V.station == st) & V.good_bearing & (V.p_same < 0.3)]
        for i in idx:
            t = V.at[i, "t_abs"]; j0, j1 = np.searchsorted(tp, t - 120), np.searchsorted(tp, t + 120)
            if j1 <= j0: continue
            c = Es.iloc[j0:j1]
            db = np.abs((c[f"{st}_baz"].values - V.at[i, "baz"] + 180) % 360 - 180)
            m = db <= 15
            if not m.any(): continue
            c = c[m]; db = db[m]; dt = t - tp[j0:j1][m]; k = int(np.argmin(np.abs(dt)))
            V.loc[i, ["cat_evid", "cat_src", "cat_mag", "cat_place", "cat_dist_km", "cat_dt_s", "cat_dbaz"]] = [
                str(c.evid.iloc[k]), c.src.iloc[k], c.mag.iloc[k], c.place.iloc[k], c[f"{st}_dist_km"].iloc[k], dt[k], db[k]]


def set_good(V):
    V["good_bearing"] = (V.cc_min >= GOOD["cc_min"]) & (V.closure_s.abs() <= GOOD["closure_s"]) & V.v_app_kms.between(GOOD["vmin"], GOOD["vmax"])

# ---- empirical H01W array calibration (bearings at H01W are biased by up to ~12 deg on the FDSN geometry) ----
sys.path.insert(0, str(ROOT / "scripts")); import array_cal as AC
V["baz_raw"] = V.baz; V["v_app_raw"] = V.v_app_kms
CAL = {}
associate(V)
for it in range(2):
    for st in ("H01W",):
        x = V[(V.station == st) & V.cat_evid.notna() & (V.cc_min >= 0.5)].copy()
        x = x.merge(E[["evid", f"{st}_baz"]].astype({"evid": str}).rename(columns={f"{st}_baz": "baz_true"}), left_on="cat_evid", right_on="evid", how="left")
        x = x.sort_values("score", ascending=False).drop_duplicates("cat_evid")
        x["res"] = (x.baz - x.baz_true + 180) % 360 - 180; x = x[x.res.abs() < 15]
        p = AC.fit(st, x.baz_raw.values, x.v_app_raw.values, x.baz_true.values)
        loo = []
        for i in range(len(x)):
            pi = AC.fit(st, np.delete(x.baz_raw.values, i), np.delete(x.v_app_raw.values, i), np.delete(x.baz_true.values, i))
            b, _ = AC.apply(st, x.baz_raw.values[i:i + 1], x.v_app_raw.values[i:i + 1], pi); loo.append((b[0] - x.baz_true.values[i] + 180) % 360 - 180)
        loo = np.array(loo); raw = ((x.baz_raw - x.baz_true + 180) % 360 - 180).values
        CAL[st] = dict(iteration=it, n_events=len(x), params=dict(c_kms=p[0], dt2_s=p[1], dt3_s=p[2], dE2_m=p[3], dN2_m=p[4], dE3_m=p[5], dN3_m=p[6]),
                       raw_residual_median_deg=float(np.median(raw)), raw_residual_robust_sd_deg=float(1.4826 * np.median(np.abs(raw - np.median(raw)))),
                       loo_residual_median_deg=float(np.median(loo)), loo_residual_robust_sd_deg=float(1.4826 * np.median(np.abs(loo - np.median(loo)))),
                       loo_residual_max_abs_deg=float(np.abs(loo).max()), baz_true_range=[float(x.baz_true.min()), float(x.baz_true.max())],
                       events=x[["cat_evid", "cat_place", "baz_true", "baz_raw", "res"]].round(3).values.tolist())
        m = (V.station == st) & V.baz_raw.notna()
        b, vv = AC.apply(st, V.loc[m, "baz_raw"].values, V.loc[m, "v_app_raw"].values, p)
        # array scale and sound speed are degenerate: rescale so the fitted speed reads 1.48 km/s (bearing unchanged)
        V.loc[m, "baz"] = b; V.loc[m, "v_app_kms"] = vv * 1.48 / p[0]
    set_good(V); associate(V)
json.dump(CAL, open(OUT / "h01w-array-calibration.json", "w"), indent=1, default=float)

# chance-association control: the same rule with predicted times shifted by +-600 s and +-1200 s
ctl = []
for st in ("H01W", "H08S"):
    tp0 = np.sort(E[f"{st}_tp"].values); o = np.argsort(E[f"{st}_tp"].values); bz = E[f"{st}_baz"].values[o]
    for src in SRC:
        g = V[(V.source == src) & (V.station == st) & V.good_bearing & (V.p_same < 0.3)]
        for shift in (0, -1200, -600, 600, 1200):
            tp = tp0 + shift; n = 0
            for t, b in zip(g.t_abs.values, g.baz.values):
                j0, j1 = np.searchsorted(tp, t - 120), np.searchsorted(tp, t + 120)
                if j1 > j0 and (np.abs((bz[j0:j1] - b + 180) % 360 - 180) <= 15).any(): n += 1
            ctl.append(dict(source=src, station=st, shift_s=shift, n_windows=len(g), n_matched=n))
pd.DataFrame(ctl).to_csv(OUT / "catalogue-association-control.csv", index=False)

# ------------------------------------------------------------------ rough classes (labels, not exclusions)
# Periodicity consistency rule: within each (source, station, day, UTC hour, statistic), the modal lag bin (0.5 s for the
# 5-15 s search, 10 s for 40-200 s) must hold >= 30 % of the hour's windows; a window is periodic when its
# prominence is >= 0.3 and its lag is within one bin of the mode. A random lag would fill a bin with about 5-6 %.
V["hour"] = (V.t_max_s // 3600).astype(int)
V["periodic_10s"] = False; V["periodic_song"] = False
for key, col, bw, lo, hi in (("periodic_10s", "per_10s", 0.5, 5.0, 15.0), ("periodic_song", "per_song", 10.0, 40.0, 200.0)):
    for _, g in V.groupby(["source", "station", "day", "hour", "stat"]):
        lag = g[f"{col}_lag"].values; prom = g[f"{col}_prom"].values
        okl = np.isfinite(lag)
        if okl.sum() < 10: continue
        h, e = np.histogram(lag[okl], bins=np.arange(lo, hi + bw, bw))
        j = int(np.argmax(h))
        if h[j] < 0.3 * okl.sum(): continue
        c = 0.5 * (e[j] + e[j + 1])
        m = okl & (np.abs(lag - c) <= 1.5 * bw) & (prom >= 0.3)
        V.loc[g.index[m], key] = True
def classify(r):
    st = r.station
    per10 = bool(r.periodic_10s)
    song = bool(r.periodic_song) and not per10
    if isinstance(r.cat_evid, str): return "T-phase (catalogue match)"
    if per10: return "periodic 5-15 s (airgun train or fin whale)"
    if song: return "periodic 40-200 s (whale song or repeating source)"
    if r.good_bearing and in_sec(r.baz, ANT[st]) and not in_sec(r.baz, ARC[st]): return "Antarctic sector (ice likely)"
    if r.good_bearing and in_sec(r.baz, ANT[st]) and in_sec(r.baz, ARC[st]): return "Antarctic and arc sectors overlap"
    if r.good_bearing and r.dur_s >= 20 and r.fpk_hz < 15: return "T-phase-like (no catalogue match)"
    if not r.good_bearing: return "bearing not resolved"
    return "unknown"
V["class"] = [classify(r) for r in V.itertuples()]
V["in_arc_sector"] = V.good_bearing & np.array([in_sec(b, ARC[s]) if np.isfinite(b) else False for b, s in zip(V.baz, V.station)])
V["in_arc_sector_88_110E"] = V.good_bearing & np.array([in_sec(b, ARC_S[s]) if np.isfinite(b) else False for b, s in zip(V.baz, V.station)])
V["in_arc_20_35S"] = V.good_bearing & np.array([in_sec(b, A2035[s]) if np.isfinite(b) else False for b, s in zip(V.baz, V.station)])
V["in_arc_35_40S"] = V.good_bearing & np.array([in_sec(b, A3540[s]) if np.isfinite(b) else False for b, s in zip(V.baz, V.station)])
V["in_earlier_sector"] = V.good_bearing & np.array([in_sec(b, EARLIER[s]) if (s in EARLIER and np.isfinite(b)) else False for b, s in zip(V.baz, V.station)])
mins_of_win = (V.win_start_s / 60.0)
V["in_clock_window"] = [(m >= CLOCK[s][0]) & (m + 55 / 60 <= CLOCK[s][1]) for m, s in zip(mins_of_win, V.station)]

# bearing-only likelihood ratio (exploratory): impact bearing uniform over the arc sector, 2 deg Gaussian bearing
# error; background = smoothed histogram of all good bearings at that station.
V["lr_bearing"] = np.nan
grid = np.arange(0, 360, 1.0) + 0.5
for src, st in [(a, b) for a in SRC for b in ("H01W", "H08S")]:
    b = V[(V.source == src) & (V.station == st) & V.good_bearing].baz.values
    if len(b) == 0: continue
    h, _ = np.histogram(b, bins=np.arange(0, 361, 1.0)); h = h + 0.5
    k = np.exp(-0.5 * (np.arange(-10, 11) / 3.0) ** 2); hs = np.convolve(np.r_[h[-10:], h, h[:10]], k / k.sum(), "valid"); fbg = hs / hs.sum()
    a0, a1 = ARC[st]; u = ((grid >= a0) & (grid <= a1)).astype(float)
    kk = np.exp(-0.5 * (np.arange(-10, 11) / 2.0) ** 2); fi = np.convolve(np.r_[u[-10:], u, u[:10]], kk / kk.sum(), "valid"); fi = fi / fi.sum()
    m = (V.source == src) & (V.station == st) & V.good_bearing
    ib = np.clip(np.floor(V.loc[m, "baz"].values).astype(int), 0, 359)
    V.loc[m, "lr_bearing"] = fi[ib] / fbg[ib]

V.to_pickle(OUT / "windows_all_valid.pkl.gz")
cols = ["source", "station", "day", "stat", "win", "t_utc", "rank", "score", "p_same", "n_null_same", "p_standin", "snr_db", "lr_bearing",
        "baz", "v_app_kms", "closure_s", "cc_min", "good_bearing", "in_arc_sector", "in_arc_20_35S", "in_arc_35_40S", "in_arc_sector_88_110E", "in_earlier_sector", "in_clock_window",
        "dur_s", "fpk_hz", "fpk_excess_db", "per_10s_lag", "per_10s_prom", "per_song_lag", "per_song_prom", "class",
        "cat_src", "cat_evid", "cat_mag", "cat_place", "cat_dist_km", "cat_dt_s", "cat_dbaz", "ref"]
D = V[V.p_same < 0.1][cols].sort_values(["source", "station", "stat", "rank"])
D.to_csv(OUT / "ims-march-detections.csv", index=False, float_format="%.4g")
V[V.p_same < 0.3][cols].to_csv(OUT / "ims-march-detections-screen-level.csv.gz", index=False, float_format="%.4g")

# ------------------------------------------------------------------ false-alarm rates
def garwood(k, expo, cl=0.90):
    from scipy.stats import chi2
    a = (1 - cl) / 2
    lo = chi2.ppf(a, 2 * k) / 2 if k > 0 else 0.0; hi = chi2.ppf(1 - a, 2 * k + 2) / 2
    return lo / expo, hi / expo
R = []
WH = 55.0 / 3600.0
for (src, st, stat), g in V.groupby(["source", "station", "stat"]):
    for basis in ("same_season", "standin_2014"):
        pc = "p_same" if basis == "same_season" else "p_standin"
        if g[pc].isna().all(): continue
        for lvl, lname in LEVELS:
            for tsub in ("all_day", "clock_window"):
                gg = g if tsub == "all_day" else g[g.in_clock_window]
                for cond, mk in (("any_bearing", np.ones(len(gg), bool)),
                                 ("arc_sector_20_40S", gg.in_arc_sector.values),
                                 ("arc_sector_20_40S_88_110E", gg.in_arc_sector_88_110E.values),
                                 ("arc_sector_20_35S", gg.in_arc_20_35S.values),
                                 ("arc_sector_35_40S", gg.in_arc_35_40S.values),
                                 ("earlier_sector_248_298", gg.in_earlier_sector.values),
                                 ("arc_sector_or_bearing_unresolved", (gg.in_arc_sector | ~gg.good_bearing).values),
                                 ("coherent_any_bearing", gg.good_bearing.values)):
                    if cond == "earlier_sector_248_298" and st != "H01W": continue
                    hit = (gg[pc].values < lvl) & mk
                    dd = pd.DataFrame({"day": gg.day.values, "hit": hit}).groupby("day").agg(k=("hit", "sum"), n=("hit", "size"))
                    dd["rate"] = dd.k / (dd.n * WH)
                    dd["year"] = dd.index.str[:4]
                    yr = dd.groupby("year").apply(lambda x: x.k.sum() / (x.n.sum() * WH))
                    K, N = int(dd.k.sum()), int(dd.n.sum())
                    lo, hi = garwood(K, N * WH)
                    rng = np.random.default_rng(20261024); kk, nn = dd.k.values, dd.n.values
                    bi = rng.integers(0, len(dd), (2000, len(dd)))
                    bs = kk[bi].sum(1) / (nn[bi].sum(1) * WH); blo, bhi = np.percentile(bs, [5, 95])
                    R.append(dict(source=src, station=st, statistic=stat, p_basis=basis, level=lname, p_threshold=lvl, time_subset=tsub, bearing_condition=cond,
                                  n_days=len(dd), n_years=dd.year.nunique(), n_windows=N, hours=N * WH, n_pass=K,
                                  rate_per_h=K / (N * WH), rate_daybootstrap90_lo=blo, rate_daybootstrap90_hi=bhi, rate_poisson90_lo=lo, rate_poisson90_hi=hi,
                                  daily_rate_p5=np.percentile(dd.rate, 5), daily_rate_median=np.median(dd.rate), daily_rate_p95=np.percentile(dd.rate, 95),
                                  yearly_rate_min=yr.min(), yearly_rate_max=yr.max(), yearly_rates=";".join(f"{a}:{b:.3g}" for a, b in yr.items()),
                                  fraction_of_windows=K / N, p_floor=(1.0 / (g.n_null_same.iloc[0] + 1)) if basis == "same_season" else 1.0 / (len(nul["D1"]) + 1)))
FA = pd.DataFrame(R); FA.to_csv(OUT / "ims-march-false-alarm-rates.csv", index=False, float_format="%.5g")
cov = W.groupby(["source", "station", "year"]).agg(days=("day", "nunique")).reset_index()
cov.to_csv(OUT / "processed-coverage.csv", index=False)
print(cov.to_string()); print(len(V), len(D))
