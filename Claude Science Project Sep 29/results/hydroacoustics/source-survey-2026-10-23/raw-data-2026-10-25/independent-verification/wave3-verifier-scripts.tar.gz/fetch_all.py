from vlib import fetch
from concurrent.futures import ThreadPoolExecutor
H11=['H11N1','H11N2','H11N3','H11S1','H11S2','H11S3']; H10=['H10N1','H10N2','H10N3','H10S1','H10S2','H10S3']
H08S=['H08S1','H08S2','H08S3']; H01W=['H01W1','H01W2','H01W3']
jobs=[(H11,'2019-04-09T10:20','2019-04-09T11:45','f35a'),
      (H11,'2021-07-02T11:20','2021-07-02T13:00','ta810'),
      (H08S,'2021-01-09T07:30','2021-01-09T08:45','sj182'),
      (H08S,'2022-02-26T09:20','2022-02-26T10:30','ab1103'),
      (H01W,'2014-12-27T21:00','2014-12-28T01:00','qz8501'),
      (H10,'2017-11-15T14:40','2017-11-15T15:15','sjevent'),
      (H10,'2017-12-01T20:55','2017-12-01T21:25','sjcharge')]
with ThreadPoolExecutor(4) as ex:
    for j,r in zip(jobs, ex.map(lambda a: fetch(*a), jobs)):
        st,inv=r; print(j[3], len(st), [(t.id, str(t.stats.starttime)[:19], str(t.stats.endtime)[:19]) for t in st][:12])
