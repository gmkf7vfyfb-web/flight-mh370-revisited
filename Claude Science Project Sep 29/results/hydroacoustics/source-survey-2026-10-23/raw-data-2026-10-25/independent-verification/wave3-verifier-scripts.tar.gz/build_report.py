"""Assemble wave3-verifier-checks.csv and wave3-verifier-report.md from the out_*.json files written by my scripts."""
import json, csv
from obspy import UTCDateTime as U
F = json.load(open('out_f35a.json')); F4 = json.load(open('out_f4.json')); T = json.load(open('out_ta810.json'))
K = json.load(open('out_kadri.json')); R = json.load(open('out_routes.json')); P = json.load(open('out_prop.json')); P2 = json.load(open('out_p2.json'))
f1 = F['F1']; e = F['elements']; f2 = F['F2']; f3 = F['F3']; k3 = F['K3']
rng = lambda v: f'{min(v):.3f}-{max(v):.3f}'
d20 = [f2[s]['D20'] for s in f2]
sj_route = R['SJ182_40_16']['L_km']; ab_route = R['AB1103_1000_16']['L_km']
sj_pk = U(K['SJ182']['peak']); ab_pk = U(K['AB1103']['peak'])
sj_off = sj_pk - (U('2021-01-09T07:40:28') + sj_route*1e3/1482); ab_off = ab_pk - (U('2022-02-26T09:30:00') + ab_route*1e3/1482)
ab_off168 = K['AB1103']['offset_geo_plus168']
ta = [k for k in T if k.startswith('T2_H11S')]
rows = [
 dict(item='F1', claimed='Exposure 4-64 Hz, noise-subtracted: H11N 0.284, H11S 0.0955 Pa^2 s. 1-s RMS peaks 0.31-0.38 Pa (H11N), 0.20-0.27 Pa (H11S).',
      recomputed=f"Linear triad mean H11N {f1['H11N']['mean']:.4f}, H11S {f1['H11S']['mean']:.4f} Pa^2 s (median {f1['H11N']['median']:.4f} / {f1['H11S']['median']:.4f}). 1-s RMS peaks 4-40 Hz: H11N {rng(f1['H11N']['rms40'])}, H11S {rng(f1['H11S']['rms40'])} Pa; 4-64 Hz: {rng(f1['H11N']['rms64'])} / {rng(f1['H11S']['rms64'])} Pa.",
      difference='Exposure < 0.1 %. Peaks within rounding (4-40 Hz).', verdict='AGREE',
      reason='Claimed triad values are the linear mean of three elements (pre-registration R4), not the median; the median would be 0.2855 / 0.0789. The claimed peak ranges are the 4-40 Hz values; the note\'s own table is 4-64 Hz (0.333-0.394 / 0.211-0.291 Pa), which I also reproduce.'),
 dict(item='F2', claimed='18-24 Hz notch -7.2 to -12.0 dB; present at 6 of 6 elements.',
      recomputed=f"D20 {min(d20):.2f} to {max(d20):.2f} dB; " + ', '.join(f"{s} {f2[s]['D20']:.2f} (95 % upper {f2[s]['hi']:.2f})" for s in f2) + '; present at 6 of 6.',
      difference=f"Per element |diff| <= {max(abs(a-b) for a,b in zip(d20,[-12.0,-9.1,-9.5,-7.9,-11.9,-7.2])):.2f} dB (largest at H11S2).", verdict='MINOR',
      reason='Pre-registered G1 statistic (1-s Hann Welch over arrival window +/-2 s, noise PSD 10:45-11:01 subtracted; 18-24 Hz against 12-17 and 26-34 Hz). Verdict "present" at all six elements agrees. Values agree within 0.7 dB.'),
 dict(item='F3', claimed='Back-azimuth 323.7 deg (H11N), 325.7 deg (H11S); apparent velocity 1452-1456 m/s.',
      recomputed=f"4-64 Hz: H11N {f3['H11N_4-64']['baz']:.2f} deg ({f3['H11N_4-64']['vapp']:.0f} m/s), H11S {f3['H11S_4-64']['baz']:.2f} deg ({f3['H11S_4-64']['vapp']:.0f} m/s); 5-40 Hz: {f3['H11N_5-40']['baz']:.2f} / {f3['H11S_5-40']['baz']:.2f} deg.",
      difference='< 0.05 deg; < 1 m/s.', verdict='AGREE', reason='FDSN element coordinates, 6-s windows, 1-s step, closure <= 16 ms and 1430-1530 m/s gates, energy-weighted circular mean.'),
 dict(item='F4', claimed='eta(z = 10 m) = 2.40e-3; ratio 1.06 to 2.26e-3 (CV02).',
      recomputed=f"First pass (true one-pole spectrum 1/(1+(f/fc)^2)): {((F4['H11N']['KRAKEN_RAM']*F4['H11S']['KRAKEN_RAM'])**0.5):.3e}, ratio {((F4['H11N']['KRAKEN_RAM']*F4['H11S']['KRAKEN_RAM'])**0.5)/2.259e-3:.3f}. Module piecewise form (flat to fc, f^-2 above, 4000-point log grid): {F4['piecewise_grid']['pooled']:.4e}, ratio {F4['piecewise_grid']['pooled']/2.259e-3:.3f}.",
      difference='Piecewise form: < 0.1 %. One-pole form: -3.4 %.', verdict='AGREE',
      reason='Arithmetic from the track TL table (W path, 10 m), the note\'s module H11S RAM delta, my F1 exposures, E 900 MJ, rho c 1025 x 1500, W63 0.54. My first number was 3.4 % low; I then opened f35a_raw_analysis.py and the module band_fraction (GitHub) to diagnose. The difference is the spectrum form, not the data.'),
 dict(item='T1', claimed='Predicted arrivals 12:26:23.6 (H11N), 12:26:53.3 (H11S); no significant detection (module M1b p 0.079 / 0.095).',
      recomputed=f"Predicted {T['H11N']['pred'][11:22]} / {T['H11S']['pred'][11:22]} ({T['H11N']['dist_km']:.2f} / {T['H11S']['dist_km']:.2f} km). Envelope SNR (5-40 Hz, peak 1-s mean square in pred +/-45 s over median of the 600 s before): {T['H11N']['snr_dB']:.1f} / {T['H11S']['snr_dB']:.1f} dB; empirical p against 54 other 90-s windows of the same record {T['H11N']['null_p']:.2f} / {T['H11S']['null_p']:.2f}.",
      difference='Predictions < 0.1 s. No arrival above background.', verdict='AGREE',
      reason='Agrees with "no significant detection". M1b p-values not recomputed (a simple envelope SNR was used, as the task allows).'),
 dict(item='T2', claimed='Burst in Kadri box at H11S from about 152.6 deg (expected 79.2 deg).',
      recomputed='; '.join(f"pulse {k[8:]} UTC: {T[k]['baz']:.1f} deg ({T[k]['lo']:.1f}-{T[k]['hi']:.1f}), {T[k]['vapp']:.0f} m/s" for k in ta) + f"; expected {T['H11S']['baz_expected']:.2f} deg. H11N - H11S timing 73.3 s and 71.5 s; plane wave from 152.6 deg predicts +74.5 s at 1.482 km/s.",
      difference='< 0.1 deg.', verdict='AGREE', reason='8-s windows centred on the two 1-s RMS peaks (5-40 Hz), 7 offsets each; closure <= 3 ms.'),
 dict(item='K1', claimed='SJ182 (H08S): box peak -742 s from the water-path centre. AB1103: -1,594 s.',
      recomputed=f"SJ182: box peak {K['SJ182']['peak'][11:22]} (track 08:11:20.0); my smoothed all-water route at the 40 m maximin depth {sj_route:.1f} km; offset {sj_off:+.0f} s. AB1103: box peak {K['AB1103']['peak'][11:22]} (same as track); my route >= 1000 m {ab_route:.1f} km (+{ab_route-R['AB1103_1000_16']['geodesic_km']:.1f} km over geodesic); offset {ab_off:+.0f} s. With the track's +168.7 km on my geodesic: {ab_off168:+.0f} s.",
      difference=f"SJ182 {sj_off+742:+.0f} s ({abs(sj_off+742)/742*100:.1f} %); AB1103 {ab_off+1594:+.0f} s ({abs(ab_off+1594)/1594*100:.1f} %).", verdict='MINOR',
      reason='Peak times agree (0.0 s and 2.3 s). The offset difference comes from route length. The track route (water_route.py, opened after my number to diagnose) is an 8-neighbour grid path with its length summed over grid steps; my unsmoothed 8-neighbour grid route is 3,848 km (SJ182) and 3,365 km (AB1103), matching the track\'s implied 3,844 / 3,356 km. Grid-step length overstates the route by 1-4 %. The conclusion (both bursts are far too early for a water path) does not change. AB1103 position: ASN (2.5 km NW of Moheli airport), substituted for Kadri S1.'),
 dict(item='K2', claimed='QZ8501 H01W burst back-azimuth 219.8 deg (expected 351 deg); open data end 00:00 UTC 28 Dec 2014.',
      recomputed=f"Burst peak {K['QZ8501']['peak'][11:22]}; back-azimuth {K['QZ8501']['baz']['None'][0]:.1f} deg (2-40 Hz K chain), {K['QZ8501']['baz']['(5, 15)'][0]:.1f} deg (5-15 Hz), {K['QZ8501']['baz']['(15, 40)'][0]:.1f} deg (15-40 Hz); v_app {K['QZ8501']['baz']['None'][3]:.0f} m/s; expected {K['QZ8501']['expected']:.1f} deg. Data end 2014-12-28T00:00:00.73 at all 3 elements; HTTP 204 for 00:00:01-00:10, 00:02-00:07, 01:00-03:00, 06:00-08:00.",
      difference='0.0 deg.', verdict='AGREE', reason='Expected bearing from the KNKT wreck area (approx. 3.62 S 109.71 E).'),
 dict(item='K3', claimed='F-35A arrival within 2-3 s of the 1.482 km/s prediction and within about 3 deg of the expected bearing.',
      recomputed=f"Offsets {k3['H11N']['off']:+.1f} s (H11N), {k3['H11S']['off']:+.1f} s (H11S) from W (40.64 N 142.96 E) at 10:26:30; bearing offsets {f3['H11N_4-64']['baz']-f3['H11N_4-64']['geo']:+.2f} / {f3['H11S_4-64']['baz']-f3['H11S_4-64']['geo']:+.2f} deg.",
      difference='Track +3.3 / +2.3 s; < 0.2 s.', verdict='AGREE', reason='Kadri chain (HP 5 Hz + BP 2-40 Hz), triad-mean 1-s RMS peak. The H11S bearing offset is 3.4 deg.'),
 dict(item='P1', claimed='San Juan event H10N 1-60 Hz triad-median peak 8.11 Pa = 138.2 dB; charge 2.66 Pa = 128.5 dB; H10S1 about 30 dB low.',
      recomputed=f"Event {P['event']['H10N_median']:.3f} Pa = {P['event']['H10N_median_dB']:.1f} dB re 1 uPa; charge {P['charge']['H10N_median']:.3f} Pa = {P['charge']['H10N_median_dB']:.1f} dB. H10S1 relative to H10S2/S3: {P['event']['H10S1_minus_S23_dB']:.1f} dB (event), {P['charge']['H10S1_minus_S23_dB']:.1f} dB (charge).",
      difference='< 0.01 Pa.', verdict='AGREE', reason='Peak = max |p| (1-60 Hz, 4-pole zero-phase) in 60 s centred on the 2-40 Hz 1-s RMS peak inside [d/1.500 - 60 s, d/1.460 + 60 s]. At the charge, H10S1 shows no arrival; its value is a noise maximum, so -26.7 dB is a lower bound on the deficit.'),
 dict(item='P2', claimed='Implied PSD-to-energy window 38.6-70.7 s by band, median 49.6 s.',
      recomputed=f"Median {P2['median']:.1f} s, range {P2['lo']:.1f}-{P2['hi']:.1f} s (raw 60-s noise-subtracted band ESD, H10N triad mean, over Nielsen Fig. 5c digitised signal-minus-noise PSD, 5-40 Hz). Raw-Welch-only variants: median 24.5-75.5 s depending on segment length.",
      difference=f"{P2['median']-49.6:+.1f} s ({abs(P2['median']-49.6)/49.6*100:.1f} %).", verdict='MINOR',
      reason='The window is defined against Nielsen\'s digitised PSD, not a raw Welch PSD (found by opening s08_published.py after my raw-Welch numbers). With that definition the result reproduces within 3.4 %. The about-7 dB conclusion holds (10 log10(47.9/10) = 6.8 dB).'),
 dict(item='P3', claimed='CV26-CV31 from the D2 table; CV27 = 1.1483.',
      recomputed='; '.join(f"{v} median {P['P3'][v]['median']:.4f} [{P['P3'][v]['min']:.4f}-{P['P3'][v]['max']:.4f}] (n {P['P3'][v]['n']})" for v in P['P3']) + '. CV30/CV31 bounds from my own element peaks: 0.0831-0.1123 / 0.5803-0.6463.',
      difference='0 at 4 decimals.', verdict='AGREE', reason='Value = median over shots of the Arons ratio (1-60 Hz); Arons relation recomputed per row. CV27 = median of four 2016 H10S shots = 1.1483 (geometric mean would be 0.758).'),
]
with open('wave3-verifier-checks.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=['item','claimed','recomputed','difference','verdict','reason']); w.writeheader(); w.writerows(rows)
json.dump(rows, open('handoff_rows.json','w'), indent=1)
print('\n'.join(f"{r['item']}: {r['verdict']} | {r['recomputed'][:200]}" for r in rows))
