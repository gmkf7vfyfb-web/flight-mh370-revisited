"""P1-P3: ARA San Juan event and calibration charge at H10N/H10S (own implementation of note section 1 M1-M8), D2/CV arithmetic."""
import json, numpy as np, pandas as pd
from obspy import UTCDateTime as U
from scipy.signal import welch
from vlib import fetch, to_pa, bp, ms1, centroid, coords, G
fs = 250.; H10 = ['H10N1','H10N2','H10N3','H10S1','H10S2','H10S3']
cases = {'event': ('sjevent','2017-11-15T14:40','2017-11-15T15:15', U('2017-11-15T13:51:05'), (-45.950,-59.773)),
         'charge': ('sjcharge','2017-12-01T20:55','2017-12-01T21:25', U('2017-12-01T20:04:30'), (-45.666,-59.240))}
out = {}; keep = {}
for name, (tag, a, b, t0, src) in cases.items():
    st, inv = fetch(H10, a, b, tag); pa = to_pa(st, inv)
    out[name] = {}
    for tr in pa:
        s = tr.stats.station; x = tr.data.astype(float); T0 = tr.stats.starttime
        la, lo = coords(inv, s); d = G.inv(src[1], src[0], lo, la)[2]
        e = ms1(bp(x, fs, 2, 40), fs)
        i0 = int((t0 + d/1500 - 60 - T0)*fs); i1 = int((t0 + d/1460 + 60 - T0)*fs)
        k = i0 + np.argmax(e[i0:i1]); w0, w1 = k - int(30*fs), k + int(30*fs)
        p160 = np.abs(bp(x, fs, 1, 60)[w0:w1]).max()
        out[name][s] = dict(tpk=str(T0 + k/fs), p160=p160, dB=20*np.log10(p160/1e-6), rms1=np.sqrt(e[k]), range_km=d/1e3)
        keep[(name, s)] = (x, k, T0)
    for tri in ['H10N','H10S']:
        v = [out[name][s]['p160'] for s in H10 if s.startswith(tri) and s != 'H10S1']
        out[name][tri+'_median'] = float(np.median(v)); out[name][tri+'_median_dB'] = 20*np.log10(np.median(v)/1e-6)
    s23 = np.median([out[name][s]['p160'] for s in ['H10S2','H10S3']])
    out[name]['H10S1_minus_S23_dB'] = 20*np.log10(out[name]['H10S1']['p160']/s23)
    print(name, {s: (round(out[name][s]['p160'],3), out[name][s]['tpk'][11:22]) for s in H10})
    print(f"P1 {name}: H10N triad median 1-60 Hz peak {out[name]['H10N_median']:.3f} Pa = {out[name]['H10N_median_dB']:.1f} dB re 1 uPa; "
          f"H10S (S2,S3) median {out[name]['H10S_median']:.2f} Pa; H10S1 vs S2/S3 {out[name]['H10S1_minus_S23_dB']:.1f} dB")
# P2: effective PSD-to-energy window T_b = E_b / (PSD_b * bandwidth), charge, H10N elements, base-2 third octaves 5-40 Hz
bands = [5,6.3,8,10,12.5,16,20,25,31.5,40]
def band_int(f, P, fc):
    lo, hi = fc*2**(-1/6), fc*2**(1/6); m = (f>=lo)&(f<hi); return np.trapezoid(P[m], f[m]) if m.sum()>1 else P[m].sum()*(f[1]-f[0])
P2 = {}
for nper in [250, 1024, 4096, 15000]:
    for psd_sub in [False, True]:
        T = []
        for s in ['H10N1','H10N2','H10N3']:
            x, k, T0 = keep[('charge', s)]
            w0, w1 = k - int(30*fs), k + int(30*fs); sig = x[w0:w1]
            # noise: 10 x 60-s windows ending 60 s before the signal window
            nwin = [x[w0 - int(60*fs) - (j+1)*int(60*fs): w0 - int(60*fs) - j*int(60*fs)] for j in range(10)]
            # FFT ESD (Pa^2 s/Hz, one-sided) of signal window; noise ESD = median over 10 windows
            def esd(y): F = np.fft.rfft(y - y.mean()); return np.fft.rfftfreq(len(y), 1/fs), 2*np.abs(F)**2/fs**2
            f, Es = esd(sig); En = np.median([esd(y)[1] for y in nwin], axis=0)
            fw, Ps = welch(sig, fs, window='hann', nperseg=min(nper, len(sig)), noverlap=min(nper, len(sig))//2)
            Pn = np.median([welch(y, fs, window='hann', nperseg=min(nper, len(y)), noverlap=min(nper, len(y))//2)[1] for y in nwin], axis=0)
            for fc in bands:
                Eb = band_int(f, Es - En, fc); Pb = band_int(fw, Ps - Pn if psd_sub else Ps, fc)
                T.append(Eb / Pb)
        T = np.array(T); P2[f'nperseg{nper}_psdsub{psd_sub}'] = dict(median=float(np.median(T)), lo=float(T.min()), hi=float(T.max()))
        print(f'P2 Welch nperseg {nper/fs:.1f} s, PSD noise-subtracted={psd_sub}: T_eff median {np.median(T):.1f} s, range {T.min():.1f}-{T.max():.1f} s')
out['P2'] = P2
# P3: CV26-CV31 from the track's D2 table
d2 = pd.read_csv('../notes/d2.csv'); cv = pd.read_csv('../notes/cv_new.csv')
q = d2[d2.band_Hz=='1-60']
sel = [('CV26','fsst16','H10N'),('CV27','fsst16','H10S'),('CV28','fsst21','H10N'),('CV29','fsst21','H10S'),('CV30','sj_charge','H10N'),('CV31','sj_charge','H10S')]
P3 = {}
for vid, ev, tri in sel:
    v = q[q.event.str.startswith(ev) & (q.triad==tri)]
    # recompute D2 ratio from the Arons relation for each row: W = [R / (P/52.4e6)^(-1/1.13)]^3 kg; ratio = W / W_declared
    W = (v.range_km*1e3 / (v.peak_Pa/52.4e6)**(-1/1.13))**3
    r = (W / v.W_declared_kg).values
    row = cv[cv.value_id==vid].iloc[0]
    P3[vid] = dict(n=len(r), median=float(np.median(r)), min=float(r.min()), max=float(r.max()), gmean=float(np.exp(np.log(r).mean())),
                   table=float(row.value), table_low=float(row.value_low), table_high=float(row.value_high),
                   max_abs_diff_vs_d2col=float(np.max(np.abs(r - v.D2_ratio.values))))
    print(f"P3 {vid} {ev} {tri}: n {len(r)} median {np.median(r):.4f} [{r.min():.4f}-{r.max():.4f}] gmean {P3[vid]['gmean']:.4f} | rows file {row.value} [{row.value_low}-{row.value_high}] | Arons recompute vs D2 col max diff {P3[vid]['max_abs_diff_vs_d2col']:.1e}")
out['P3'] = P3
json.dump(out, open('out_prop.json','w'), indent=1, default=float)
