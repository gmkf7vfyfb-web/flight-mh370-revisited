"""F4: arithmetic check of eta(z=10 m), F2 family, KRAKEN + module H11S RAM delta, from the track's TL table and the
note's own inputs (E 900 MJ, rho c 1025*1500, tau 3.30 s, W63 0.54, bands 5-63 Hz) and my F1 exposures."""
import json, numpy as np, pandas as pd
from scipy.integrate import quad
tl = pd.read_csv('f35a_in_tl.csv'); tl = tl[tl.source_id=='W']
SE = json.load(open('out_f35a.json'))['F1']
bands = [5,6.3,8,10,12.5,16,20,25,31.5,40,50,63]
Wb = {b:1.0 for b in bands}; Wb[63] = 0.54
fc = 1/3.30
S = lambda f: 1/(1+(f/fc)**2)
norm = quad(S, 1, 500, limit=200)[0]
def Sb(b): return quad(S, b*2**(-1/6), b*2**(1/6))[0]/norm
# module H11S RAM delta at 10 m (note section 6 table): 5/10/20/40 Hz
rd_f = np.array([5,10,20,40.]); rd_v = np.array([0.80,3.52,3.09,3.80])
delta = lambda f: np.interp(np.log(np.clip(f,5,40)), np.log(rd_f), rd_v)
rho_c = 1025*1500.; E = 900e6
out = {}
for tri in ['H11N','H11S']:
    t = tl[(tl.receiver==tri)&(tl.src_depth_m==10.0)].set_index('fc_hz').tl_db
    den = {}
    for chain in ['KRAKEN_ONLY','KRAKEN_RAM']:
        s = 0
        for b in bands:
            TL = t.loc[b] + (delta(b) if chain=='KRAKEN_RAM' else 0)
            s += Wb[b]*Sb(b)*10**(-TL/10)
        den[chain] = E*rho_c/(2*np.pi)*s
    out[tri] = {c: SE[tri]['mean']/d for c,d in den.items()}
for c in ['KRAKEN_ONLY','KRAKEN_RAM']:
    eN, eS = out['H11N'][c], out['H11S'][c]; g = np.sqrt(eN*eS)
    print(c, 'eta_N %.3e eta_S %.3e pooled %.3e  ratio to 2.26e-3 (CV02) %.3f'%(eN, eS, g, g/2.259e-3))
json.dump(out, open('out_f4.json','w'), indent=1)

# --- Diagnosis (after opening the track's script and the module band_fraction): spectrum flat to fc, f^-2 above,
# normalised over 1-500 Hz. My own exact-integral implementation of that form, plus a 4000-point log-grid trapezoid variant.
def Sb_pw(b, grid=False):
    lo, hi = b*2**(-1/6), b*2**(1/6)
    if not grid:
        tot = fc**2*(1/1 - 1/500)            # fc < 1 Hz, so f^-2 throughout 1-500 Hz (scale fc^2 cancels)
        return fc**2*(1/lo - 1/hi)/tot
    f = np.logspace(0, np.log10(500), 4000); e = (f/fc)**-2.0; m = (f>=lo)&(f<=hi)
    return np.trapezoid(e[m], f[m])/np.trapezoid(e, f)
for grid in [False, True]:
    res2 = {}
    for tri in ['H11N','H11S']:
        t = tl[(tl.receiver==tri)&(tl.src_depth_m==10.0)].set_index('fc_hz').tl_db
        s = sum(Wb[b]*Sb_pw(b, grid)*10**(-(t.loc[b]+delta(b))/10) for b in bands)
        res2[tri] = SE[tri]['mean']/(E*rho_c/(2*np.pi)*s)
    g = np.sqrt(res2['H11N']*res2['H11S'])
    print('piecewise%s: eta_N %.4e eta_S %.4e pooled %.4e ratio to 2.259e-3 %.3f' % (' (log-grid trapz)' if grid else ' (exact)', res2['H11N'], res2['H11S'], g, g/2.259e-3))
    out['piecewise_grid' if grid else 'piecewise_exact'] = dict(res2, pooled=g)
json.dump(out, open('out_f4.json','w'), indent=1)
