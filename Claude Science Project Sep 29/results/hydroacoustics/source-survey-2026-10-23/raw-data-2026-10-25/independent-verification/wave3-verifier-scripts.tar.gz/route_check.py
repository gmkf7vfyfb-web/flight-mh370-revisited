"""Route-length robustness: 8- vs 16-connected Dijkstra on the 0.05-deg deepest-cell GEBCO blocks, each followed by
string-pulling on geodesics. Reuses kadri_check's grid and helpers by import-free copy (exec of the routing part)."""
import numpy as np, json
src = open('kadri_check.py').read()
head = src.split('# ---------------- SJ182 at H08S ----------------')[0]
exec(head)
from obspy import read_inventory
from vlib import DATA
inv = read_inventory(DATA+'/sj182.xml'); c08 = centroid(inv, ['H08S1','H08S2','H08S3'])
def route16(srcp, dstp, thr, conn=16):
    W = blk <= -thr; s, d = cell(*srcp), cell(*dstp); W[s] = True; W[d] = True
    n_a, n_o = W.shape; idn = np.arange(n_a*n_o).reshape(n_a, n_o); rows=[]; cols=[]; ws=[]
    moves = [(0,1,[]),(1,0,[]),(1,1,[]),(1,-1,[])]
    if conn == 16: moves += [(1,2,[(0,1),(1,1)]),(2,1,[(1,0),(1,1)]),(1,-2,[(0,-1),(1,-1)]),(2,-1,[(1,0),(1,-1)])]
    for da, do, mids in moves:
        ia = np.arange(n_a - da); io = np.arange(max(0,-do), n_o - max(0,do))
        IA, IO = np.meshgrid(ia, io, indexing='ij'); JA, JO = IA+da, IO+do
        ok = W[IA, IO] & W[JA, JO]
        for ma, mo in mids: ok &= W[IA+ma, IO+mo]
        IA, IO, JA, JO = IA[ok], IO[ok], JA[ok], JO[ok]
        _, _, dist = G.inv(blon[IO], blat[IA], blon[JO], blat[JA])
        rows += [idn[IA, IO], idn[JA, JO]]; cols += [idn[JA, JO], idn[IA, IO]]; ws += [dist, dist]
    M = coo_matrix((np.concatenate(ws), (np.concatenate(rows), np.concatenate(cols))), shape=(n_a*n_o,)*2).tocsr()
    dist, pred = dijkstra(M, indices=idn[s], return_predecessors=True)
    if not np.isfinite(dist[idn[d]]): return None
    path = [idn[d]]
    while path[-1] != idn[s]: path.append(pred[path[-1]])
    P = [(blat[p//n_o], blon[p % n_o]) for p in path[::-1]]
    def visible(p, q):
        npt = max(2, int(G.inv(p[1], p[0], q[1], q[0])[2]/1500)); pts = G.npts(p[1], p[0], q[1], q[0], npt)
        return all(W[cell(y, x)] for x, y in pts)
    pulled = [P[0]]; i = 0
    while i < len(P)-1:
        best = i+1
        while best+1 < len(P) and visible(P[i], P[best+1]): best += 1
        # look further ahead for later visible points (non-monotone visibility)
        for jj in range(len(P)-1, best, -5):
            if visible(P[i], P[jj]): best = jj; break
        pulled.append(P[best]); i = best
    L = sum(G.inv(pulled[k][1], pulled[k][0], pulled[k+1][1], pulled[k+1][0])[2] for k in range(len(pulled)-1))
    L += G.inv(srcp[1], srcp[0], P[0][1], P[0][0])[2] + G.inv(dstp[1], dstp[0], P[-1][1], P[-1][0])[2]
    return dict(L_km=L/1e3, grid_km=dist[idn[d]]/1e3, waypoints=[(round(float(a),2), round(float(b),2)) for a,b in pulled])
sj = (-(5+57/60+56.21/3600), 106+34/60+24.86/3600); ab = (-12.282, 43.750)
res = {}
for name, p, thrs in [('SJ182', sj, [30, 40]), ('AB1103', ab, [200, 1000])]:
    geo = G.inv(p[1], p[0], c08[1], c08[0])[2]/1e3
    for thr in thrs:
        for conn in [8, 16]:
            r = route16(p, c08, thr, conn)
            print(f'{name} thr {thr} m conn {conn}: pulled {r["L_km"]:.1f} km (+{r["L_km"]-geo:.1f}), grid {r["grid_km"]:.1f} km; waypoints {len(r["waypoints"])}: {r["waypoints"][:8]}')
            res[f'{name}_{thr}_{conn}'] = dict(r, geodesic_km=geo)
json.dump(res, open('out_routes.json','w'), indent=1, default=float)
