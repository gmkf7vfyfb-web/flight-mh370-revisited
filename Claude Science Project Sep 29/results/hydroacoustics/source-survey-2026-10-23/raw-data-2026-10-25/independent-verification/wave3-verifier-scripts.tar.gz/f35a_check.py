"""F1-F3, K3: F-35A 2019-04-09 at H11N/H11S, own implementation from pre-registration P2-P8, G1."""
import json, numpy as np
from obspy import UTCDateTime as U
from scipy.signal import welch
from vlib import fetch, to_pa, bp, ms1, plane_wave, centroid, G
H11=['H11N1','H11N2','H11N3','H11S1','H11S2','H11S3']
st, inv = fetch(H11,'2019-04-09T10:20','2019-04-09T11:45','f35a')
pa = to_pa(st, inv)
fs = 250.0; T0 = pa[0].stats.starttime
X = {tr.stats.station: tr.data.astype(float) for tr in pa}
for tr in pa: assert abs(tr.stats.starttime - T0) < 2e-3  # <= 1 ms across triads, 0 within a triad
idx = lambda t: int(round((U(t) - T0) * fs))
frames = {'H11N': ('2019-04-09T11:02:55','2019-04-09T11:03:25'), 'H11S': ('2019-04-09T11:03:55','2019-04-09T11:04:25')}
hop = 5; dt = hop / fs
res = {}
for s in H11:
    tri = s[:4]; a, b = idx(frames[tri][0]), idx(frames[tri][1])
    r = {}
    for band in [(4,64),(4,40)]:
        m = ms1(bp(X[s], fs, *band), fs)[a:b:hop]
        L = 10*np.log10(m/1e-12)
        k = np.argmax(L); tt = np.arange(len(L))*dt
        out = np.abs(tt - tt[k]) > 8
        Ln = np.median(L[out])
        i0 = k
        while i0 > 0 and L[i0-1] > Ln+1: i0 -= 1
        i1 = k
        while i1 < len(L)-1 and L[i1+1] > Ln+1: i1 += 1
        SE = np.sum(10**(L[i0:i1+1]/10)*1e-12 - 10**(Ln/10)*1e-12)*dt
        r[band] = dict(peak_rms=np.sqrt(m[k]), peak_dB=L[k], Ln=Ln, SE=SE, tpk=str(T0 + a/fs + tt[k]),
                       w0=a/fs + tt[i0], w1=a/fs + tt[i1])
    res[s] = r
# F1
print('F1 per element (4-64): SE, 1-s RMS peak Pa, peak time; (4-40) 1-s RMS peak')
for s in H11: print(s, round(res[s][(4,64)]['SE'],4), round(res[s][(4,64)]['peak_rms'],3), round(res[s][(4,64)]['peak_dB'],2), res[s][(4,64)]['tpk'][11:22], '| 4-40:', round(res[s][(4,40)]['peak_rms'],3))
F1 = {}
for tri in ['H11N','H11S']:
    v = np.array([res[s][(4,64)]['SE'] for s in H11 if s.startswith(tri)])
    F1[tri] = dict(mean=v.mean(), median=np.median(v), gmean=np.exp(np.log(v).mean()),
                   rms64=[res[s][(4,64)]['peak_rms'] for s in H11 if s.startswith(tri)],
                   rms40=[res[s][(4,40)]['peak_rms'] for s in H11 if s.startswith(tri)])
    print(tri, 'mean %.4f median %.4f gmean %.4f'%(v.mean(), np.median(v), F1[tri]['gmean']))
# F2: Welch 1-s Hann 50% over W_b = arrival +/-2 s (per element, own arrival window 4-64), noise 10:45-11:01
na, nb = idx('2019-04-09T10:45:00'), idx('2019-04-09T11:01:00')
F2 = {}
def d20(E, f):
    m = lambda lo, hi: np.mean(E[(f>=lo)&(f<=hi)])
    return 10*np.log10(m(18,24)) - 0.5*(10*np.log10(m(12,17)) + 10*np.log10(m(26,34)))
for s in H11:
    x = X[s]; r = res[s][(4,64)]
    w0 = int((r['w0']-2)*fs); w1 = int((r['w1']+2)*fs)
    W = (w1-w0)/fs
    f, Pw = welch(x[w0:w1], fs, window='hann', nperseg=250, noverlap=125, detrend='constant')
    f, Pn = welch(x[na:nb], fs, window='hann', nperseg=250, noverlap=125, detrend='constant')
    Eex = (Pw - Pn) * W
    raw = d20(Pw, f)
    # bootstrap over 1-s segments
    segs = np.array([welch(x[w0+i:w0+i+250], fs, window='hann', nperseg=250, noverlap=0, detrend='constant')[1] for i in range(0, w1-w0-250+1, 125)])
    rng = np.random.default_rng(20261025); bs = []
    for _ in range(2000):
        P = segs[rng.integers(0, len(segs), len(segs))].mean(0)
        with np.errstate(invalid='ignore'): bs.append(d20(np.clip((P-Pn)*W, 1e-30, None), f))
    lo, hi = np.percentile(bs, [2.5, 97.5])
    F2[s] = dict(D20=d20(Eex, f), lo=lo, hi=hi, D20_before_noise=raw, D20_noise=d20(Pn, f), W=W, nseg=len(segs))
    print('F2', s, 'D20 %.2f dB (95%% %.2f..%.2f) before-sub %.2f noise %.2f |W| %.1f s nseg %d'%(F2[s]['D20'], lo, hi, raw, F2[s]['D20_noise'], W, len(segs)))
# F3: back-azimuth, 6-s windows 1-s step over arrival window +/-3 s (union of the triad's elements), gates
F3 = {}
W_pt = (142.96, 40.64)
for tri in ['H11N','H11S']:
    els = [s for s in H11 if s.startswith(tri)]; a = idx(frames[tri][0])
    t0 = min(res[s][(4,64)]['w0'] for s in els) - 3; t1 = max(res[s][(4,64)]['w1'] for s in els) + 3
    for band in [(4,64),(5,40)]:
        y = [bp(X[s], fs, *band) for s in els]
        rows = []
        ws = t0
        while ws + 6 <= t1 + 1e-9:
            i0 = int(ws*fs); i1 = i0 + int(6*fs)
            seg = [v[i0:i1] for v in y]
            baz, vapp, clo, dts = plane_wave(inv, els, seg, fs, maxlag=2.0)
            rows.append((baz, vapp, abs(clo), sum(np.sum(v*v) for v in seg)))
            ws += 1
        rows = np.array(rows)
        ok = (rows[:,2] <= 0.016) & (rows[:,1] >= 1430) & (rows[:,1] <= 1530)
        w = rows[ok,3]; th = np.radians(rows[ok,0])
        mb = np.degrees(np.arctan2(np.sum(w*np.sin(th)), np.sum(w*np.cos(th)))) % 360
        sd = np.sqrt(np.sum(w*((rows[ok,0]-mb+180)%360-180)**2)/np.sum(w))
        vm = np.sum(w*rows[ok,1])/np.sum(w)
        lat, lon = centroid(inv, els)
        az_geo = G.inv(lon, lat, *W_pt)[0] % 360
        F3[(tri,band)] = dict(baz=mb, sd=sd, vapp=vm, n=len(rows), npass=int(ok.sum()), geo=az_geo, closure_ms=np.median(rows[ok,2])*1e3)
        print('F3', tri, band, 'baz %.2f sd %.2f vapp %.1f windows %d pass %d closure %.2f ms | geodesic from W %.2f'%(mb, sd, vm, len(rows), ok.sum(), F3[(tri,band)]['closure_ms'], az_geo))
# K3: Kadri processing (HP 5 Hz + BP 2-40 Hz, order 4, zero-phase), triad-mean 1-s RMS peak vs W + 10:26:30 at 1.482 km/s
from scipy.signal import butter, sosfiltfilt
hp = butter(4, 5, 'high', fs=fs, output='sos')
K3 = {}
for tri, (wa, wb) in {'H11N':('2019-04-09T11:01:00','2019-04-09T11:05:00'), 'H11S':('2019-04-09T11:02:00','2019-04-09T11:06:00')}.items():
    els = [s for s in H11 if s.startswith(tri)]
    m = np.mean([ms1(bp(sosfiltfilt(hp, X[s]), fs, 2, 40), fs) for s in els], axis=0)
    a, b = idx(wa), idx(wb); k = a + np.argmax(m[a:b])
    lat, lon = centroid(inv, els)
    az, _, d = G.inv(lon, lat, *W_pt)
    pred = U('2019-04-09T10:26:30') + d/1482.0
    tpk = T0 + k/fs
    K3[tri] = dict(tpk=str(tpk), pred=str(pred), off=tpk-pred, dist_km=d/1e3, rms=np.sqrt(m[k]))
    print('K3', tri, 'peak', str(tpk)[11:22], 'pred', str(pred)[11:22], 'offset %+.1f s'%(tpk-pred), 'dist %.1f km'%(d/1e3), 'triad-mean 1-s RMS %.3f Pa'%np.sqrt(m[k]))
json.dump(dict(F1=F1, F2=F2, F3={f'{k[0]}_{k[1][0]}-{k[1][1]}':v for k,v in F3.items()}, K3=K3,
               elements={s:{str(b):v for b,v in res[s].items()} for s in H11}), open('out_f35a.json','w'), indent=1, default=float)
