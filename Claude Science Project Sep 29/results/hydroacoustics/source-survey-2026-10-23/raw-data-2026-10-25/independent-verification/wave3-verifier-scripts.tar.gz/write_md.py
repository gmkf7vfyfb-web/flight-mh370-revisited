import json
rows = json.load(open('handoff_rows.json'))
dev = [
 "Independence: I opened track scripts only after I had my own number, and only to diagnose a difference. F4: f35a_raw_analysis.py, plus the module files prereg.py and imos_stageB_map.py fetched from GitHub (branch hypothesis/hydroacoustics). K1: water_route.py. P2: track3-scripts.tar.gz (s08_published.py). I did not open measure.py, analyse.py or any ta810_*.py.",
 "P2 definition changed from the task text. The task describes the window as raw Welch PSD against band exposure. The track defines it as the raw 60-s band ESD divided by Nielsen Fig. 5c digitised PSD. I report both. The verdict uses the track definition, with the digitised Nielsen bands (nielsen_fig5cd_bands.csv, repo results-data) as input.",
 "F4 is arithmetic from the track's TL table (f35a-raw-tl-kraken.csv) and the note's module RAM delta (section 6 table), with my own F1 exposures. I did not re-run KRAKEN or RAM.",
 "K1, AB1103: Kadri's S1 position is not available to me. I used the published crash location instead: 2.5 km NW of Moheli Bandar Es Eslam airport (Aviation Safety Network), taken as 12.282 S 43.750 E. Impact time 09:30:00 UTC, as in the track.",
 "K1: I computed my own all-water routes on GEBCO_2026 (0.05 deg blocks, deepest cell; 8- and 16-neighbour Dijkstra, then string-pulling on geodesics). They are not the track's routes. My maximin depth for SJ182 is 40 m (thresholds tested: 40 and 44 m; the track gives 44 m).",
 "K2: the expected bearing uses an approximate KNKT wreck-area position (3.62 S 109.71 E).",
 "T1: I used a simple envelope SNR with an empirical p against 54 other 90-s windows of the same 100-min record. I did not recompute the module M1b p-values (0.079 / 0.095).",
 "F2: noise PSD from 10:45-11:01 UTC only. The seven background windows were not downloaded, so I did not recompute the sigma_b band 'measured' flags. The G1 statistic does not use them.",
 "Compute: local, at most 4 download threads. Data from the EarthScope FDSN (anonymous). No mirror was used.",
]
tol = ("Verdict rule. AGREE: the difference is within the rounding of the claim, or below 0.5 dB, 5 %, 0.1 deg and 0.5 s, with the same qualitative conclusion. "
       "MINOR: the difference is at most 1 dB, 10 %, 1 deg or 2 s (any one of these). DISAGREE: larger than that. NOT VERIFIED: not recomputed.")
other = [
 "Wording (F1, task): the triad exposure is the linear mean of three elements (pre-registration R4), not the median. The median would be 0.2855 / 0.0789 Pa^2 s. The 1-s RMS peak ranges in the task (0.31-0.38 / 0.20-0.27 Pa) are 4-40 Hz values. The F-35A note's own table is 4-64 Hz (0.333-0.394 / 0.211-0.291 Pa).",
 "Spectral family wording (F-35A coupling rows CV26-CV107): the rows say 'one-pole f^-2'. The module band_fraction is piecewise: flat to the corner, then f^-2, normalised over 1-500 Hz on a 4000-point log grid. A true one-pole form 1/(1+(f/fc)^2) gives eta 3.4 % lower (2.315e-3 against 2.396e-3 at 10 m). Suggest 'flat to 1/tau, f^-2 above (module band_fraction)'.",
 "Route lengths (Kadri track, water_route.py): the length is the sum of 8-neighbour grid steps, with no path smoothing. This overstates the route by 1-4 %: SJ182 about +42 km and AB1103 about +125 km against my smoothed routes. The water-path centres are therefore late, and the reported offsets are too negative by about 26 s (SJ182) and 84 s (AB1103). The conclusions do not change.",
 "AB1103 expected bearing: the reconciliation table gives 254.56 deg at H08S, from Kadri's S1 position. The published crash location gives 258.40 deg, which is close to Kadri's own Fig. 2 value of 258.47 deg. The S1 position appears to be about 200 km off across the path, although its range is similar (my geodesic 3,190.4 km). This has no effect on the result, because the AB1103 burst has no coherent bearing.",
 "SJ182 box peak: my triad-mean 1-s RMS peak is at 08:11:17.73, 0.461 Pa. The track gives 08:11:20.0, 0.415 Pa: 2.3 s and 0.9 dB different. Not diagnosed. The likely cause is a difference in edge taper or envelope hop. This has no effect on any conclusion.",
 "H10S1 at the charge: the H10S1 'arrival' (21:09:42.97, implied 1.503 km/s) is a noise maximum, not the arrival. The -27 dB figure for the charge is therefore a lower bound on the H10S1 deficit. The event value (-31.9 dB) is a true arrival comparison.",
 "P2 wording (propagation note, section 3): the sentence on the implied window follows the raw Welch comparison. A reader could take it as raw Welch PSD against raw energy. It is raw ESD against Nielsen's digitised PSD. A raw 60-s Welch PSD gives medians of 24.5-75.5 s, depending on the segment length.",
 "Value-id collision: three tracks write coupling rows from CV26: F-35A (CV26-CV107), Transair 810 (CV26-CV35) and propagation (CV26-CV31). The importer must renumber. The F-35A note says this; the other two notes do not.",
 "Minor: the Transair note gives the H11N - H11S pulse lag as 72-73 s. I get 73.3 s and 71.5 s.",
]
L = ["# Wave-3 raw IMS analyses: independent verifier report", "",
     "Verifier session c764a583, 25 Oct 2026. Exploratory checks only. Nothing here enters any posterior. I did not edit or re-save any track file.", "",
     "## Deviations (read first)", ""] + [f"{i+1}. {d}" for i, d in enumerate(dev)] + ["", tol, "",
     "## Summary", "",
     f"Of 12 items, {sum(r['verdict']=='AGREE' for r in rows)} AGREE, {sum(r['verdict']=='MINOR' for r in rows)} MINOR, {sum(r['verdict']=='DISAGREE' for r in rows)} DISAGREE and {sum(r['verdict']=='NOT VERIFIED' for r in rows)} NOT VERIFIED. "
     "No finding is reversed. The MINOR items are as follows. F2: the gap depth agrees to within 0.7 dB. K1: the route-length method moves the offsets by 26 s and 84 s, and both bursts stay far too early for a water path. P2: the median window is 47.9 s against 49.6 s.", "",
     "## Checks", "", "| item | claimed | recomputed | difference | verdict | reason |", "|---|---|---|---|---|---|"]
for r in rows:
    L.append("| " + " | ".join(r[k].replace('|', '/') for k in ['item','claimed','recomputed','difference','verdict','reason']) + " |")
L += ["", "## Errors and issues found outside the check list", ""] + [f"{i+1}. {o}" for i, o in enumerate(other)]
L += ["", "## Scripts (in wave3-verifier-scripts.tar.gz)", "",
      "vlib.py (download with cache, response removal to Pa, filters, 1-s envelope, plane-wave fit); fetch_all.py; f35a_check.py (F1-F3, K3); f4_check.py (F4); "
      "ta810_check.py (T1, T2); kadri_check.py (K1, K2, T2 timing); route_check.py (route robustness); prop_check.py (P1, P2 variants, P3); p2_nielsen.py (P2 track definition); "
      "p3_ranges.py; build_report.py; write_md.py. The out_*.json files hold every recomputed value. Raw MiniSEED is not archived. It is re-downloadable with fetch_all.py."]
open('wave3-verifier-report.md','w').write('\n'.join(L) + '\n')
json.dump(dict(deviations=dev, other=other), open('handoff_meta.json','w'), indent=1)
print(len(L))
