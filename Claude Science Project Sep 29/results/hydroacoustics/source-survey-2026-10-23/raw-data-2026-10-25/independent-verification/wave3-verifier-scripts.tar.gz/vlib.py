"""Independent verifier library (wave-3 raw IMS checks). Written from the notes' definitions only."""
import os, numpy as np, obspy
from obspy import UTCDateTime as U
from obspy.clients.fdsn import Client
from scipy.signal import butter, sosfiltfilt
from pyproj import Geod
G = Geod(ellps='WGS84')
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def client(): return Client('EARTHSCOPE', timeout=120)

def fetch(stas, t0, t1, tag):
    """Raw MiniSEED + StationXML, cached. Returns (Stream counts, Inventory)."""
    t0, t1 = U(t0), U(t1)
    fm = os.path.join(DATA, f'{tag}.mseed'); fx = os.path.join(DATA, f'{tag}.xml')
    c = None
    if not os.path.exists(fm):
        c = client()
        st = obspy.Stream()
        for s in stas:
            try: st += c.get_waveforms('IM', s, '*', 'EDH', t0, t1)
            except Exception as e: print('no data', s, tag, type(e).__name__)
        st.write(fm, format='MSEED')
    if not os.path.exists(fx):
        c = c or client()
        inv = c.get_stations(network='IM', station=','.join(stas), channel='EDH', level='response', starttime=t0, endtime=t1)
        inv.write(fx, format='STATIONXML')
    return obspy.read(fm), obspy.read_inventory(fx)

def to_pa(st, inv, taper_s=30.0):
    """Merge (interpolate small gaps), full response removal to Pa, pre_filt 0.5/1/110/120 Hz."""
    st = st.copy(); st.merge(method=1, fill_value='interpolate')
    out = obspy.Stream()
    for tr in st:
        tr = tr.copy(); tr.detrend('demean')
        frac = min(0.5, taper_s / (tr.stats.npts / tr.stats.sampling_rate))
        tr.taper(max_percentage=frac, type='cosine')
        tr.remove_response(inventory=inv, output='DEF', pre_filt=(0.5, 1, 110, 120), water_level=None, taper=False)
        out += tr
    return out

def bp(x, fs, f1, f2, order=4):
    sos = butter(order, [f1, f2], btype='band', fs=fs, output='sos')
    return sosfiltfilt(sos, x)

def ms1(x, fs, win=1.0):
    """Centred 1-s boxcar mean square."""
    n = int(round(win * fs)); k = np.ones(n) / n
    return np.convolve(x * x, k, mode='same')

def coords(inv, sta):
    ch = inv.select(station=sta)[0][0][0]
    return ch.latitude, ch.longitude

def plane_wave(inv, stas, traces, fs, maxlag=2.0):
    """Delays by cross-correlation (parabolic sub-sample) on given equal-length arrays; LSQ slowness in local ENU.
    Returns back-azimuth (deg, toward source), apparent speed (m/s), closure (s)."""
    lat0 = np.mean([coords(inv, s)[0] for s in stas]); lon0 = np.mean([coords(inv, s)[1] for s in stas])
    xy = []
    for s in stas:
        la, lo = coords(inv, s)
        az, _, d = G.inv(lon0, lat0, lo, la)
        xy.append([d * np.sin(np.radians(az)), d * np.cos(np.radians(az))])
    xy = np.array(xy)
    pairs = [(0, 1), (0, 2), (1, 2)]; dt = []
    m = int(maxlag * fs)
    for i, j in pairs:
        a, b = traces[i] - traces[i].mean(), traces[j] - traces[j].mean()
        cc = np.correlate(b, a, mode='full'); mid = len(a) - 1
        seg = cc[mid - m: mid + m + 1]; k = np.argmax(seg)
        if 0 < k < len(seg) - 1:
            y0, y1, y2 = seg[k - 1], seg[k], seg[k + 1]; dk = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2)
        else: dk = 0
        dt.append((k - m + dk) / fs)   # t_j - t_i
    dt = np.array(dt)
    A = np.array([xy[j] - xy[i] for i, j in pairs])
    p, *_ = np.linalg.lstsq(A, dt, rcond=None)
    baz = (np.degrees(np.arctan2(-p[0], -p[1]))) % 360
    closure = dt[0] + dt[2] - dt[1]
    return baz, 1 / np.hypot(*p), closure, dt

def centroid(inv, stas):
    return np.mean([coords(inv, s)[0] for s in stas]), np.mean([coords(inv, s)[1] for s in stas])
