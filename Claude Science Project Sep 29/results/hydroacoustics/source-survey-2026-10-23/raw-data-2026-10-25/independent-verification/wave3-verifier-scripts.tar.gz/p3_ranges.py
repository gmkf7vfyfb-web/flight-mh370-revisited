"""P3 supplement: CV30/CV31 low/high from my own per-element charge peaks (1-60 Hz) and ranges, Arons relation, W_declared 108 kg."""
import json
o = json.load(open('out_prop.json'))['charge']
for tri, els in [('H10N',['H10N1','H10N2','H10N3']),('H10S',['H10S2','H10S3'])]:
    r = [((o[s]['range_km']*1e3)/(o[s]['p160']/52.4e6)**(-1/1.13))**3/108.0 for s in els]
    print(tri, [round(x,4) for x in r], 'min %.4f max %.4f' % (min(r), max(r)))
