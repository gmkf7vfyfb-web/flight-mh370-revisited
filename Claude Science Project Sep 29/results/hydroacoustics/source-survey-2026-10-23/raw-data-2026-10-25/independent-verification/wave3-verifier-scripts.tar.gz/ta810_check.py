"""T1, T2: Transair 810 (2021-07-02) at H11N/H11S. Own implementation."""
import json, numpy as np
from obspy import UTCDateTime as U
from vlib import fetch, to_pa, bp, ms1, plane_wave, centroid, G
H11=['H11N1','H11N2','H11N3','H11S1','H11S2','H11S3']
st, inv = fetch(H11,'2021-07-02T11:20','2021-07-02T13:00','ta810')
pa = to_pa(st, inv); fs = 250.; T0 = pa[0].stats.starttime
X = {tr.stats.station: bp(tr.data.astype(float), fs, 5, 40) for tr in pa}
idx = lambda t: int(round((U(t)-T0)*fs))
site = (-158.02565, 21.27616); t_imp = U('2021-07-02T11:45:17')
out = {}
for tri in ['H11N','H11S']:
    els = [s for s in H11 if s.startswith(tri)]
    lat, lon = centroid(inv, els)
    az_s, baz, d = G.inv(site[0], site[1], lon, lat)   # baz = azimuth from receiver to site
    pred = t_imp + d/1482.
    m = np.mean([ms1(X[s], fs) for s in els], axis=0)
    # predicted window: pred +/- 45 s (90 s, ~4.5 sigma); SNR = peak 1-s ms over median of the 600 s before the window
    a, b = idx(pred-45), idx(pred+45)
    pk = m[a:b].max(); tpk = T0 + (a+np.argmax(m[a:b]))/fs
    bg = np.median(m[idx(pred-45-600):a])
    snr = 10*np.log10(pk/bg)
    # null: same statistic for all non-overlapping 90-s windows 11:40-13:00 excluding the predicted window and Kadri box region
    stats = []
    t = U('2021-07-02T11:35:00')
    while t + 90 <= U('2021-07-02T12:59:00'):
        if abs(t+45-pred) > 90:
            i0, i1 = idx(t), idx(t+90); b0 = np.median(m[max(0,i0-int(600*fs)):i0])
            stats.append(10*np.log10(m[i0:i1].max()/b0))
        t += 90
    stats = np.array(stats); p = (np.sum(stats >= snr)+1)/(len(stats)+1)
    out[tri] = dict(dist_km=d/1e3, baz_expected=baz % 360, pred=str(pred), peak_time=str(tpk), peak_rms=np.sqrt(pk), snr_dB=snr,
                    null_n=len(stats), null_median_snr=float(np.median(stats)), null_p=p)
    print(f'T1 {tri}: dist {d/1e3:.2f} km baz {baz%360:.2f} pred {str(pred)[11:22]} | window peak {np.sqrt(pk):.3f} Pa at {str(tpk)[11:22]} SNR {snr:.1f} dB; null n={len(stats)} median {np.median(stats):.1f} dB; p={p:.3f}')
# T2: bearing of the bursts at H11S (around 12:31:42 and 12:32:24) and H11N peaks; 8-s windows centred on 1-s RMS peaks
for tri, (wa, wb) in {'H11S':('2021-07-02T12:31:12','2021-07-02T12:32:39'), 'H11N':('2021-07-02T12:32:14','2021-07-02T12:33:40')}.items():
    els = [s for s in H11 if s.startswith(tri)]
    m = np.mean([ms1(X[s], fs) for s in els], axis=0); a, b = idx(wa), idx(wb)
    # two largest separated peaks
    seg = m[a:b].copy(); pks = []
    for _ in range(2):
        k = np.argmax(seg); pks.append(a+k); seg[max(0,k-int(15*fs)):k+int(15*fs)] = 0
    for k in sorted(pks):
        res = []
        for off in [-4,-3,-2,-1,0,1,2]:
            i0 = k + int((off-3)*fs); i1 = i0 + int(8*fs)
            baz_, v, clo, _ = plane_wave(inv, els, [X[s][i0:i1] for s in els], fs, maxlag=2.0)
            res.append((baz_, v, clo))
        r = np.array(res)
        print(f'T2 {tri} pulse at {str(T0+k/fs)[11:22]} 1-s RMS {np.sqrt(m[k]):.3f} Pa: baz median {np.median(r[:,0]):.1f} (range {r[:,0].min():.1f}-{r[:,0].max():.1f}) vapp median {np.median(r[:,1]):.0f} m/s, |closure| max {np.abs(r[:,2]).max()*1e3:.1f} ms')
        out[f'T2_{tri}_{str(T0+k/fs)[11:19]}'] = dict(baz=float(np.median(r[:,0])), lo=float(r[:,0].min()), hi=float(r[:,0].max()), vapp=float(np.median(r[:,1])))
# inter-triad timing check for the pulses (H11N minus H11S)
json.dump(out, open('out_ta810.json','w'), indent=1, default=float)
