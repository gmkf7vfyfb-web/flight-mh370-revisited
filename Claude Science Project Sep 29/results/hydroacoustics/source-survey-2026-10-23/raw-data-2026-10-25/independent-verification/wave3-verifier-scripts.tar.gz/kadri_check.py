"""K1, K2 (+T2 inter-triad timing): Kadri boxes on raw data (processing K: HP 5 Hz + BP 2-40 Hz, order 4, zero-phase),
triad-mean 1-s RMS peak; plane-wave bearings; own shortest all-water route on GEBCO_2026 (0.05 deg blocks, deepest cell)."""
import json, numpy as np, netCDF4
from obspy import UTCDateTime as U
from scipy.signal import butter, sosfiltfilt
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from scipy import ndimage
from vlib import fetch, to_pa, bp, ms1, plane_wave, centroid, G
fs = 250.; hp = butter(4, 5, 'high', fs=fs, output='sos')
def procK(tag, stas, t0, t1):
    st, inv = fetch(stas, t0, t1, tag); pa = to_pa(st, inv); T0 = pa[0].stats.starttime
    X = {tr.stats.station: bp(sosfiltfilt(hp, tr.data.astype(float)), fs, 2, 40) for tr in pa}
    return X, inv, T0, pa
def box_peak(X, els, T0, a, b):
    m = np.mean([ms1(X[s], fs) for s in els], axis=0)
    i0, i1 = int((U(a)-T0)*fs), int((U(b)-T0)*fs); k = i0 + np.argmax(m[i0:i1])
    return T0 + k/fs, np.sqrt(m[k]), k, m
def bearing(X, inv, els, k, band=None, win=8, offs=(-3,-2,-1,0,1,2,3)):
    r = []
    for off in offs:
        i0 = k + int((off - win/2)*fs); i1 = i0 + int(win*fs)
        segs = [X[s][i0:i1] if band is None else bp(X[s][i0-2500:i1+2500], fs, *band)[2500:-2500] for s in els]
        b_, v, c, _ = plane_wave(inv, els, segs, fs, maxlag=2.0); r.append((b_, v, abs(c)))
    r = np.array(r); return float(np.median(r[:,0])), float(r[:,0].min()), float(r[:,0].max()), float(np.median(r[:,1])), float(r[:,2].max())
out = {}
# ---------------- GEBCO routing ----------------
nc = netCDF4.Dataset('/Users/pete/Downloads/mh370-ocean-data/gebco/GEBCO_2026.nc')
LAT0, LAT1, LON0, LON1 = -16.0, 2.0, 38.0, 117.0
la = nc['lat'][:]; lo = nc['lon'][:]
ia0, ia1 = np.searchsorted(la, LAT0), np.searchsorted(la, LAT1); io0, io1 = np.searchsorted(lo, LON0), np.searchsorted(lo, LON1)
el = nc['elevation'][ia0:ia1, io0:io1].astype(np.int16)
nb_a, nb_o = el.shape[0]//12, el.shape[1]//12
blk = el[:nb_a*12, :nb_o*12].reshape(nb_a, 12, nb_o, 12).min(axis=(1,3)).astype(float)   # deepest cell per 0.05 deg block
blat = la[ia0] + (np.arange(nb_a)+0.5)*0.05 - 1/480; blon = lo[io0] + (np.arange(nb_o)+0.5)*0.05 - 1/480
print('GEBCO blocks', blk.shape)
def cell(lat, lon): return int(np.argmin(np.abs(blat-lat))), int(np.argmin(np.abs(blon-lon)))
def route(src, dst, thr):
    """Shortest path through blocks with depth >= thr (src/dst cells forced open), 8-connected, then string-pulled on geodesics."""
    W = blk <= -thr; s, d = cell(*src), cell(*dst); W[s] = True; W[d] = True
    lab, _ = ndimage.label(W, structure=np.ones((3,3)))
    if lab[s] != lab[d]: return None
    n_a, n_o = W.shape; idn = np.arange(n_a*n_o).reshape(n_a, n_o); rows=[]; cols=[]; ws=[]
    for da, do in [(0,1),(1,0),(1,1),(1,-1)]:
        A = W[max(0,-da):n_a-max(0,da), max(0,-do):n_o-max(0,do)]
        B = W[max(0,da):, max(0,do):][:A.shape[0], :A.shape[1]] if do>=0 else W[da:, :n_o+do][:A.shape[0], :A.shape[1]]
        # explicit index arrays
        ia = np.arange(n_a - da); io = np.arange(max(0,-do), n_o - max(0,do))
        IA, IO = np.meshgrid(ia, io, indexing='ij'); JA, JO = IA+da, IO+do
        ok = W[IA, IO] & W[JA, JO]
        IA, IO, JA, JO = IA[ok], IO[ok], JA[ok], JO[ok]
        _, _, dist = G.inv(blon[IO], blat[IA], blon[JO], blat[JA])
        rows += [idn[IA, IO], idn[JA, JO]]; cols += [idn[JA, JO], idn[IA, IO]]; ws += [dist, dist]
    M = coo_matrix((np.concatenate(ws), (np.concatenate(rows), np.concatenate(cols))), shape=(n_a*n_o,)*2).tocsr()
    dist, pred = dijkstra(M, indices=idn[s], return_predecessors=True)
    path = [idn[d]]
    while path[-1] != idn[s]: path.append(pred[path[-1]])
    path = path[::-1]; P = [(blat[p//n_o], blon[p % n_o]) for p in path]
    def visible(p, q):
        npt = max(2, int(G.inv(p[1], p[0], q[1], q[0])[2]/2000))
        pts = G.npts(p[1], p[0], q[1], q[0], npt)
        return all(W[cell(y, x)] for x, y in pts)
    # string pulling (greedy farthest-visible)
    pulled = [P[0]]; i = 0
    while i < len(P)-1:
        j = len(P)-1
        lo_, hi_ = i+1, len(P)-1; best = i+1
        # binary-ish search for farthest visible then linear refine
        for jj in range(len(P)-1, i, -max(1, (len(P)-i)//40)):
            if visible(P[i], P[jj]): best = jj; break
        while best+1 < len(P) and visible(P[i], P[best+1]): best += 1
        pulled.append(P[best]); i = best
    L = sum(G.inv(pulled[k][1], pulled[k][0], pulled[k+1][1], pulled[k+1][0])[2] for k in range(len(pulled)-1))
    # replace end points by the true src/dst
    L += G.inv(src[1], src[0], P[0][1], P[0][0])[2] + G.inv(dst[1], dst[0], P[-1][1], P[-1][0])[2]
    return dict(L_km=L/1e3, grid_km=dist[idn[d]]/1e3, nseg=len(pulled)-1)
def maximin(src, dst, grid=(1,10,20,25,30,35,40,44,45,50,60,80,100,150,200,500,1000)):
    ok = [t for t in grid if route_conn(src, dst, t)]; return max(ok) if ok else None
def route_conn(src, dst, thr):
    W = blk <= -thr; s, d = cell(*src), cell(*dst); W[s] = True; W[d] = True
    lab, _ = ndimage.label(W, structure=np.ones((3,3))); return lab[s] == lab[d]
# ---------------- SJ182 at H08S ----------------
H08S = ['H08S1','H08S2','H08S3']
X, inv, T0, _ = procK('sj182', H08S, '2021-01-09T07:30', '2021-01-09T08:45')
tp, rms, k, m = box_peak(X, H08S, T0, '2021-01-09T08:10:35', '2021-01-09T08:12:00')
c08 = centroid(inv, H08S)
sj = (-(5+57/60+56.21/3600), 106+34/60+24.86/3600); t_sj = U('2021-01-09T07:40:28')
geo = G.inv(sj[1], sj[0], c08[1], c08[0])[2]/1e3
mm = maximin(sj, c08); print('SJ182 maximin threshold (m):', mm)
rt = {t: route(sj, c08, t) for t in sorted(set([1, 10, 30, mm]))}
for t, r in rt.items():
    if r: print(f'  SJ182 route depth>={t} m: {r["L_km"]:.1f} km (8-conn grid {r["grid_km"]:.1f}); centre {str(t_sj + r["L_km"]*1e3/1482)[11:21]}; offset {tp - (t_sj + r["L_km"]*1e3/1482):+.0f} s')
print(f'K1 SJ182 box peak {str(tp)[11:22]} triad-mean 1-s RMS {rms:.3f} Pa; geodesic {geo:.1f} km; geodesic-only offset {tp-(t_sj+geo*1e3/1482):+.0f} s')
out['SJ182'] = dict(peak=str(tp), rms=rms, geodesic_km=geo, maximin_m=mm, routes={str(t): r for t, r in rt.items()},
                    offset_geodesic=tp-(t_sj+geo*1e3/1482), offsets={str(t): (tp-(t_sj+r['L_km']*1e3/1482)) if r else None for t, r in rt.items()})
# ---------------- AB1103 at H08S ----------------
X, inv, T0, _ = procK('ab1103', H08S, '2022-02-26T09:20', '2022-02-26T10:30')
tp, rms, k, m = box_peak(X, H08S, T0, '2022-02-26T09:40:37', '2022-02-26T09:42:05')
ab = (-12.282, 43.750)   # ~2.5 km NW of Moheli Bandar Es Eslam airport (ASN); substitute for Kadri S1 position
t_ab = U('2022-02-26T09:30:00')
g = G.inv(c08[1], c08[0], ab[1], ab[0]); geo = g[2]/1e3
print(f'AB1103 geodesic {geo:.1f} km, expected baz {g[0]%360:.2f}')
rt = {}
for t in [200, 1000]:
    r = route(ab, c08, t); rt[t] = r
    if r: print(f'  AB1103 route depth>={t} m: {r["L_km"]:.1f} km (+{r["L_km"]-geo:.1f} km over geodesic); offset {tp-(t_ab+r["L_km"]*1e3/1482):+.0f} s')
    else: print('  AB1103 route', t, 'none (source cell isolated at this threshold)')
print(f'K1 AB1103 box peak {str(tp)[11:22]} 1-s RMS {rms:.3f} Pa; offset vs geodesic {tp-(t_ab+geo*1e3/1482):+.0f} s; vs geodesic+168.7 km {tp-(t_ab+(geo+168.7)*1e3/1482):+.0f} s')
out['AB1103'] = dict(peak=str(tp), rms=rms, geodesic_km=geo, baz_expected=g[0]%360, routes={str(t): r for t, r in rt.items()},
                     offset_geo=tp-(t_ab+geo*1e3/1482), offset_geo_plus168=tp-(t_ab+(geo+168.7)*1e3/1482),
                     offsets={str(t): (tp-(t_ab+r['L_km']*1e3/1482)) if r else None for t, r in rt.items()})
# ---------------- QZ8501 at H01W ----------------
H01W = ['H01W1','H01W2','H01W3']
X, inv, T0, pa = procK('qz8501', H01W, '2014-12-27T21:00', '2014-12-28T01:00')
print('QZ8501 data end per element:', [str(tr.stats.endtime) for tr in pa])
tp, rms, k, m = box_peak(X, H01W, T0, '2014-12-27T23:55:06', '2014-12-27T23:56:44')
cW = centroid(inv, H01W)
qz_site = (-(3+37/60+22/3600), 109+42/60+43/3600)   # KNKT wreck area (approx 3.62 S 109.71 E)
gq = G.inv(cW[1], cW[0], qz_site[1], qz_site[0])
bz = {b: bearing(X, inv, H01W, k, band=b) for b in [None, (5,15), (15,40)]}
for b, v in bz.items(): print(f'K2 QZ8501 H01W peak {str(tp)[11:22]} band {b or "2-40 (K)"}: baz {v[0]:.1f} ({v[1]:.1f}-{v[2]:.1f}) vapp {v[3]:.0f} m/s, |closure| max {v[4]*1e3:.1f} ms; expected {gq[0]%360:.1f}')
out['QZ8501'] = dict(peak=str(tp), rms=rms, baz={str(b): v for b, v in bz.items()}, expected=gq[0]%360, data_end=[str(tr.stats.endtime) for tr in pa])
# ---------------- TA810 inter-triad timing (T2 support) ----------------
H11 = ['H11N1','H11N2','H11N3','H11S1','H11S2','H11S3']
st, inv11 = fetch(H11, '2021-07-02T11:20', '2021-07-02T13:00', 'ta810')
cN, cS = centroid(inv11, H11[:3]), centroid(inv11, H11[3:])
az, _, dd = G.inv(cS[1], cS[0], cN[1], cN[0])
for baz_, c in [(152.6, 1440.), (152.6, 1482.)]:
    prop = (baz_ + 180) % 360
    print(f'T2 plane wave from {baz_} deg at {c:.0f} m/s: H11N - H11S delay {dd*np.cos(np.radians(az-prop))/c:+.1f} s (baseline {dd/1e3:.1f} km)')
out['TA810_baseline_km'] = dd/1e3
json.dump(out, open('out_kadri.json','w'), indent=1, default=float)
