"""P2 (as defined in the track, found on diagnosis): T_b = raw band-average ESD (60-s window centred on the 2-40 Hz 1-s RMS
peak, FFT, noise-subtracted with the median of 10 x 60-s windows ending 60 s before; H10N triad mean, linear) divided by
Nielsen 2021 Fig. 5c digitised H10N PSD (signal minus noise, linear). Own code; reuses my P1 peak picking."""
import json, numpy as np, pandas as pd
from obspy import UTCDateTime as U
from vlib import fetch, to_pa, bp, ms1, coords, G
fs = 250.; ni = pd.read_csv('in_nielsen_fig5cd_bands.csv'); ni = ni[ni.station=='H10N'].set_index('fc_hz')
ni_lin = 10**(ni.signal_db/10) - 10**(ni.noise_db/10)        # uPa^2/Hz
st, inv = fetch(['H10N1','H10N2','H10N3'], '2017-12-01T20:55', '2017-12-01T21:25', 'sjcharge')
pa = to_pa(st.select(station='H10N*'), inv)
t0 = U('2017-12-01T20:04:30'); src = (-45.666, -59.240)
E = []
for tr in pa:
    x = tr.data.astype(float); T0 = tr.stats.starttime; la, lo = coords(inv, tr.stats.station); d = G.inv(src[1], src[0], lo, la)[2]
    e = ms1(bp(x, fs, 2, 40), fs); i0 = int((t0 + d/1500 - 60 - T0)*fs); i1 = int((t0 + d/1460 + 60 - T0)*fs)
    k = i0 + np.argmax(e[i0:i1]); w0, w1 = k - int(30*fs), k + int(30*fs)
    def esd(y): F = np.fft.rfft(y - y.mean()); return np.fft.rfftfreq(len(y), 1/fs), 2*np.abs(F)**2/fs**2
    f, Es = esd(x[w0:w1])
    En = np.median([esd(x[w0 - int(60*fs) - (j+1)*int(60*fs): w0 - int(60*fs) - j*int(60*fs)])[1] for j in range(10)], axis=0)
    E.append(Es - En)
Em = np.mean(E, axis=0)
rows = []
for fc in ni.index:
    m = (f >= fc*2**(-1/6)) & (f < fc*2**(1/6))
    esd_b = Em[m].mean()*1e12                                   # uPa^2 s/Hz
    rows.append(dict(fc=fc, esd_dB=10*np.log10(esd_b), nielsen_sig_minus_noise_dB=10*np.log10(ni_lin[fc]), T_s=esd_b/ni_lin[fc]))
r = pd.DataFrame(rows); print(r.round(2).to_string(index=False))
print(f'P2 implied window: median {r.T_s.median():.1f} s, range {r.T_s.min():.1f}-{r.T_s.max():.1f} s; 10log10(median/10 s) = {10*np.log10(r.T_s.median()/10):.1f} dB')
json.dump(dict(median=float(r.T_s.median()), lo=float(r.T_s.min()), hi=float(r.T_s.max()), bands=r.to_dict('records')), open('out_p2.json','w'), indent=1)
